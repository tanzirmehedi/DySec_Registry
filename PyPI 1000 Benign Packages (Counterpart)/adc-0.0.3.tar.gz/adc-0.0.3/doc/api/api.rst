.. _api:

genesis-client API
##################

.. toctree::
    :maxdepth: 2

    streaming
