=========
History
=========


0.1.0 (2018-09-19)
*******************************


* Released option pricing
* Released portfolio analysis
* Added testing for Options and Portfolios

