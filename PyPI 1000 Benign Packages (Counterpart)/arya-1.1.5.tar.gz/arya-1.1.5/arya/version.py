# Set this to the version of arya for the distribution.
__version__ = '1.1.5'
