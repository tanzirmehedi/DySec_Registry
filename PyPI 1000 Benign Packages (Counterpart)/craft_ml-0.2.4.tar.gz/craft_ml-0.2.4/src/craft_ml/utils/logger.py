import typing as t


class Logger:
    pass
