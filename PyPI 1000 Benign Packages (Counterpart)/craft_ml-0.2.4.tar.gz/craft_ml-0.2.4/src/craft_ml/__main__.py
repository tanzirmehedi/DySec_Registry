import craft_ml


if __name__ == '__main__':
    craft_ml.default_pipeline()
    print('OK')
