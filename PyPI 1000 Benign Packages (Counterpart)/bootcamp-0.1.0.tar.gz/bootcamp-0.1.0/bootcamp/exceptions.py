class StopTraining(ValueError): pass
