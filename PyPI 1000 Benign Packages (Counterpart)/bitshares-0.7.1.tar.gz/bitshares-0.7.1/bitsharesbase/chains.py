# -*- coding: utf-8 -*-
known_chains = {
    "BTS": {
        "chain_id": "4018d7844c78f6a6c41c6a552b898022310fc5dec06da467ee7905a8dad512c8",
        "core_symbol": "BTS",
        "prefix": "BTS",
    },
    "TEST": {
        "chain_id": "39f5e2ede1f8bc1a3a54a7914414e3779e33193f1f5693510e73cb7a87617447",
        "core_symbol": "TEST",
        "prefix": "TEST",
    },
}
