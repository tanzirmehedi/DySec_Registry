# amazontrends
![python_version](https://img.shields.io/static/v1?label=Python&message=3.5%20|%203.6%20|%203.7&color=blue) [![PyPI downloads/month](https://img.shields.io/pypi/dm/amazontrends?logo=pypi&logoColor=white)](https://pypi.python.org/pypi/amazontrends)

## Description
amazontrends

## Install
~~~~bash
pip install amazontrends
# or
pip3 install amazontrends
~~~~