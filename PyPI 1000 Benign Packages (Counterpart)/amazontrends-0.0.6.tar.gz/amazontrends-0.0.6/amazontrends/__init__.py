from .amazontrends import AmazonTrends
from .category import Category