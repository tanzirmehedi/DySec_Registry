from setuptools import setup  # type: ignore[import-untyped]

setup()
