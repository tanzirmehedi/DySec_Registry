__all__ = ["load_breakfast_events"]

from aroma.datasets.breakfast import load_event_data as load_breakfast_events
