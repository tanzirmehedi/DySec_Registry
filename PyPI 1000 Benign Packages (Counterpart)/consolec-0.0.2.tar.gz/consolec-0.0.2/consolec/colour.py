from termcolor import *


def colour(text, color):

    return colored(text=text, color=color)




def colourprint(text="", color="white"):

    cprint(text=text, color=color)




def colours():

    return COLORS
