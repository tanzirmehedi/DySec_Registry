from candinfo.client import Code, Candidate

__title__ = 'candinfo'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2021 kangyoolee'
__version__ = '1.0.2'