==================================
django-pyc |release| documentation
==================================

.. toctree::
    :maxdepth: 2

    installation
    commands
    license
