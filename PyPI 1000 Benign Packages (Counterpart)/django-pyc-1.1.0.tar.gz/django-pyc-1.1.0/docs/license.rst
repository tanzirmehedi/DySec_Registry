License
=======

Copyright © 2014, 2019, Piotr Roszatycki

This software is distributed under the GNU Lesser General Public License (LGPL 3
or greater).
