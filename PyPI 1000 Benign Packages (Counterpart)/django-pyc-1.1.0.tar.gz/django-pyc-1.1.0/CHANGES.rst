Changes
=======

1.1.0 (2019-04-23)
------------------

- Options ``--noinput``, ``--force`` and ``--with-pythonpath`` should not
  accept any parameters.

1.0.4 (2019-04-11)
------------------

- Minor clean up.

1.0.3 (2019-04-10)
------------------

- Minor clean up.

1.0.2 (2019-04-09)
------------------

- Works with Python 2.x and Django 1.1x too.

1.0.1 (2019-04-01)
------------------

- Minor bugfixes for documentation and build process.

1.0.0 (2019-04-01)
------------------

- Requires Python 3.x and Django 2.x.

- New parameter ``path`` with a list of directories to scan. Still the
  ``sys.path[0]`` is a default value.

0.2 (2014-09-11)
------------------

- Requires Django >= 1.5.

0.1 (2014-09-11)
------------------

- First release.
