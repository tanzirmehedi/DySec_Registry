# Crafting tool for your ML/RL experiments with Docker

## Installation 

Just install from PyPI:

```pip install crafting```
