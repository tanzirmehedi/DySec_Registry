# -*- coding: utf-8 -*-
# bypass: Copyright (c) 2017, Richard Berry

from setuptools import setup

setup(
    setup_requires=['pbr', 'setuptools'],
    pbr=True,
)
