from deposit_gui.dgui.dconnect_tabs.abstract_tab_file import AbstractTabFile

class DConnectTabJSON(AbstractTabFile):
	
	EXTENSION = "json"
