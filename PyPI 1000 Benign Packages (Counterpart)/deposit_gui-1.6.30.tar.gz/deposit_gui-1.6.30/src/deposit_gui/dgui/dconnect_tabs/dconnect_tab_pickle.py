from deposit_gui.dgui.dconnect_tabs.abstract_tab_file import AbstractTabFile

class DConnectTabPickle(AbstractTabFile):
	
	EXTENSION = "pickle"
