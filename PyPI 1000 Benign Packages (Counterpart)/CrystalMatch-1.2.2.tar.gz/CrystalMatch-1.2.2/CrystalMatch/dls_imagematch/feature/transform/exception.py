class TransformCalculationError(Exception):
    pass
