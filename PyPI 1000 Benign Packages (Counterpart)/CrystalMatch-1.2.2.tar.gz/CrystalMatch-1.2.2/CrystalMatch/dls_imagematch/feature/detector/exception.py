class FeatureDetectorError(Exception):
    pass


class OpenCvVersionError(Exception):
    pass
