class ImageAlignmentError(Exception):
    pass
