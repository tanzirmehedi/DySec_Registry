

------------------------------------------------------------------
pyspec - python tools for the SPEC experiment control package 
------------------------------------------------------------------

This is a test README file for pyspec

