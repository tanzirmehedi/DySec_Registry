===========================================
 ``celery.backends.couchdb``
===========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.couchdb

.. automodule:: celery.backends.couchdb
    :members:
    :undoc-members:
