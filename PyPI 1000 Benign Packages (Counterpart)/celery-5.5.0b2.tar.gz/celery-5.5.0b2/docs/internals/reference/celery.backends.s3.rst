==========================================
 ``celery.backends.s3``
==========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.s3

.. automodule:: celery.backends.s3
    :members:
    :undoc-members:
