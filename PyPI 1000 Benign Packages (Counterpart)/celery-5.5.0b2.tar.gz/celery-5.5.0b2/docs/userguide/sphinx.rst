.. _sphinx:

==============================
 Documenting Tasks with Sphinx
==============================

This document describes how auto-generate documentation for Tasks using Sphinx.


--------------------------------
 celery.contrib.sphinx
--------------------------------

.. automodule:: celery.contrib.sphinx
    :members:
    :noindex:
