====================================
 ``celery.contrib.django.task``
====================================

.. versionadded:: 5.4

.. contents::
    :local:

API Reference
=============

.. currentmodule:: celery.contrib.django.task

.. automodule:: celery.contrib.django.task
    :members:
    :undoc-members:
