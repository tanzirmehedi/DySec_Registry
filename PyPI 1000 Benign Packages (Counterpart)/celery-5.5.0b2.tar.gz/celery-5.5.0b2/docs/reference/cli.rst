=======================
 Command Line Interface
=======================

.. NOTE:: The prefix `CELERY_` must be added to the names of the environment
   variables described below. E.g., `APP` becomes `CELERY_APP`.

.. click:: celery.bin.celery:celery
   :prog: celery
   :nested: full
