==================================================
 ``celery.worker.consumer.events``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.events

.. automodule:: celery.worker.consumer.events
    :members:
    :undoc-members:
