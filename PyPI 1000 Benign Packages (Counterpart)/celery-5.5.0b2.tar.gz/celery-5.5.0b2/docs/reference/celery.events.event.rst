=================================================================
 ``celery.events.event``
=================================================================

.. contents::
    :local:
.. currentmodule:: celery.events.event

.. automodule:: celery.events.event
    :members:
    :undoc-members:
