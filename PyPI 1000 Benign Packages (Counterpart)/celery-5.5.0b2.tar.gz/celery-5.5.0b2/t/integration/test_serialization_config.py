event_serializer = "pickle"
result_serializer = "pickle"
accept_content = ["pickle", "json"]
worker_redirect_stdouts = False
worker_log_color = False
