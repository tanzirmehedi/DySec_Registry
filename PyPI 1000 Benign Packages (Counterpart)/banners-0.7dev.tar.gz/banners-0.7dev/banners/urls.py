from django.conf.urls.defaults import *

# URL patterns for banners

urlpatterns = patterns('banners.views',
  # Add url patterns here
)
