from django.conf.urls.defaults import *

# URL test patterns for banners. Use this file to ensure a consistent
# set of URL patterns are used when running unit tests. This test_urls
# module should be referred to by your test class.

urlpatterns = patterns('banners.views',
  # Add url patterns here
)
