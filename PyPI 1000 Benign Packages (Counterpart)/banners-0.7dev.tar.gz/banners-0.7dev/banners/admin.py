from django.contrib import admin
from banners.models import Banner
# Add your admin site registrations here, eg.
# from banners.models import Author
admin.site.register(Banner)
