from django.test import TestCase

class AppTestCase(TestCase):
    """
    Populate this class with unit tests for your application
    """
    
    urls = 'banners.test_urls'
    
    def testApp():
        pass