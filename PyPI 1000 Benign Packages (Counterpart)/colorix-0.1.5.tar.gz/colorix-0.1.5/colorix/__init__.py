from .colormodes import *
from .utils import *

__title__ = 'colorix'
__author__ = 'Tekgar'
__license__ = 'MIT'
__version__ = '0.1.5'
