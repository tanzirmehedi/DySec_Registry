def bucket():
    return "ds-analysis-jobs"


def submit_prefix():
    return "submit"


def job_prefix():
    return "jobs"
