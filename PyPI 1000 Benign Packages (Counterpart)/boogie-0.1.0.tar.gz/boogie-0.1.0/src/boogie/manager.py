from django.db.models.manager import Manager
from .query import QuerySet


QuerySetManager = QuerySet