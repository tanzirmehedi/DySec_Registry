Simple usage
This can only get data about an user if you want to make more complex stuff you need to make your own