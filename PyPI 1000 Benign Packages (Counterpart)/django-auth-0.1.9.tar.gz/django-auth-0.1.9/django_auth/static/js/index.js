var app = new Vue({
    el: '#app',
    data: {
    },
    created: function () {
    },
    methods: {
    }
});