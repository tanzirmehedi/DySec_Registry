from distutils.core import setup

setup(
    name='aadhaar',
    version='1.0.0.dev1',
    packages=['aadhaar'],
    url='https://github.com/pupattan/aadhaar.git',
    license='MIT',
    author='pulakpattanayak',
    author_email='pulak.pattanayak@gmail.com',
    description='Api for aadhaar'
)
