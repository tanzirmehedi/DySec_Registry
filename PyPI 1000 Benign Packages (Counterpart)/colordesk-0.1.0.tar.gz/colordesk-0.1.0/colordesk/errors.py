

class ColordeskError(Exception):
    """Base exception for colrodesk"""


class ParseYAMLError(Exception):
    """Failed to parse the YAML file"""
