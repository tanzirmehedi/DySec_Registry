import dreq

# Ensure initialized.
dreq.initialize()
