Beautiful Soup4
================

This is the Beautiful Soup4 document in chinese.

这是Beautiful Soup 4 的中文文档.

官方网站: http://www.crummy.com/software/BeautifulSoup/

原版文档: http://www.crummy.com/software/BeautifulSoup/bs4/doc/
