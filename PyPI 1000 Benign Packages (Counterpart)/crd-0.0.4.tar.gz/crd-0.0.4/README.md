# crd

Your private secret storage, with a familiar dict API
