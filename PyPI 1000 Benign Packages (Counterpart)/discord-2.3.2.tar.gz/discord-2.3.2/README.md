### This is a mirror package!

It is recommended to install `discord.py` instead.
