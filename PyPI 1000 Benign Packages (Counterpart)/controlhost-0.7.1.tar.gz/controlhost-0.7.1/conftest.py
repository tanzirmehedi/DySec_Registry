# coding=utf-8
# Filename: contest.py
"""
Configuration file for py.tests.

"""
__author__ = 'tamasgal'

collect_ignore = ["setup.py"]
