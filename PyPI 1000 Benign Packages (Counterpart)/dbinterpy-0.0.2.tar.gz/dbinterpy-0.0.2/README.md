# dbinterpy
Basic sqlite3 wrapper class for simple database interaction in python. Created to teach myself about dynamic databases, SQL and publishing python packages.

Tested with python 3.6-3.10

![Tests](https://github.com/Hitham2496/DatabaseInterface/actions/workflows/python-package.yml/badge.svg)
