# croma
A simple scientific visualization and animation library for Python
