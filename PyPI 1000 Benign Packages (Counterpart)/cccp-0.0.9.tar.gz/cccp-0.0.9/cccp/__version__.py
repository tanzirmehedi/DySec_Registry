__version__ = "0.0.9"
__author__ = ("sloev",)
__email__ = "johannes.valbjorn@gmail.com"
