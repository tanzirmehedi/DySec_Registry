### 0.0.1

* implement simple javascript functions for DOM manipulations
* create example using flask

### 0.0.2

* fix bugs
* introduce more js snippets

### 0.0.3

* fix css snippet

### 0.0.4

* add xkcd line chart snippet

### 0.0.9

* drop xkcd chart and use chartjs