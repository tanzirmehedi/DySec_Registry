from bip_utils.utils.conf.coin_names import CoinNames
