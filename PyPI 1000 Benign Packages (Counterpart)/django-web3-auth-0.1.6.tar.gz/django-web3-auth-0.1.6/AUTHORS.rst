=======
Credits
=======

Development Lead
----------------

* Denis Bobrov <tech@bearle.ru>

Contributors
------------

* Alexander Tereshkin <atereshkin@y-node.com>
