.. :changelog:
0.1.6 (2021-09-06)
++++++++++++++++++

* Update from PR#6 by @hiporox
* Resolve's issue #4 -  Example app has missing url configuration


0.1.5 (2021-09-06)
++++++++++++++++++

* Update from PR#5 by @hiporox
* Updated .gitignore to include missing file types
* Added script tag to the base.html that imports web3 since MetaMask no longer auto imports (https://docs.metamask.io/guide/provider-migration.html#replacing-window-web3)

History
-------

0.1.4 (2021-05-06)
++++++++++++++++++

* Try fix rlp


0.1.3 (2021-03-23)
++++++++++++++++++

* Try fix ethereum


0.1.2 (2021-03-16)
++++++++++++++++++

* Flake8, tox fixes in PR#2 by SukiCZ

0.1.1 (2021-03-16)
++++++++++++++++++

* Bump 'rlp' - PR#1 by SukiCZ

0.1.0 (2018-06-29)
++++++++++++++++++

* First release on PyPi
