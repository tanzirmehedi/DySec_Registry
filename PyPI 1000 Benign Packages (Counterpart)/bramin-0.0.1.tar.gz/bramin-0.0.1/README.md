# Bramin

![braminus](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Davidraju_Worm_Snake.jpg/320px-Davidraju_Worm_Snake.jpg)

[Indotyphlops **bramin**us](https://en.wikipedia.org/wiki/Indotyphlops_braminus) is a kind of snake, they like digging(make pipe!).

## Features

Work In Progress.

+ [x] Piping(composing) functions.
+ [x] Placeholder.
+ [x] Unix like output redirection.
+ [x] Subprocess communication.
+ [ ] Automatic currying.
+ [ ] Branching and merging.
+ [ ] Parallel execution of branches.

## Usage

See more:

+ [example.ipynb](./example.ipynb)

## Development

### Test

Run `pytest` in project directory:

```bash
bramin$ pytest --doctest-modules -s
```
