from distutils.core import setup

setup(
    name='caonester',
    version='1.2.0',
    py_modules=['printf_fun'],
    author='jinn',
    author_email='jinnsblog@gmail.com',
    url='http://www.jinnsblog.com',
    description='simple demo'
)
