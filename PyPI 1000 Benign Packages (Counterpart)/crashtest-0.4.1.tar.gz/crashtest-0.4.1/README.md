# Crashtest

[![Tests](https://github.com/sdispater/crashtest/actions/workflows/main.yml/badge.svg)](https://github.com/sdispater/crashtest/actions/workflows/main.yml)
[![PyPI version](https://img.shields.io/pypi/v/crashtest)](https://pypi.org/project/crashtest/)

Crashtest is a Python library that makes exceptions handling and inspection easier.
