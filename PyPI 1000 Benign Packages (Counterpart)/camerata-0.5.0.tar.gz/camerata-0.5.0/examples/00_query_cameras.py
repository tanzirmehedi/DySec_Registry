"""
Query a list of available cameras
"""
import camerata
print(*camerata.query(), sep='\n')
