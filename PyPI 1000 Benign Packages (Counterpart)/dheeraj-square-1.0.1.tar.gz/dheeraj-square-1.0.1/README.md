Dheeraj Square

It takes an integer as an input and prints it square.
Installation

pip install dheeraj-square
How to use it?
##how to use it 
Open terminal and type square and then input the integer
##License

© 2021 dheeraj rajput

This repository is licensed under the MIT license. See LICENSE for details.