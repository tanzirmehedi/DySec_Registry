def main():
    number=int(input("enter the number,(only positive number allowed)"))
    print(f"{number} squares is: {number**2}")
if __name__=='__main__':
    main()

