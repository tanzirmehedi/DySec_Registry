# Contribution

No contribution is too small, please add your name if you've helped
`consolmd` along.

See [github](https://github.com/kneufeld/consolemd/graphs/contributors)
for some pretty graphs.

## Contributors

* kneufeld, original author
* zmarouf, doc fix
* tek, python3 migration
* kseistrup, python3 migration
* fboender, filed great bug report showing a bad deploy to pypi
* vext01, pointed out version bug
* ap8322, changed setup.py from CommonMark to commonmark
* pmiddend, asked about click 7, prompted pyinstaller freezing
* igalic, idea for --width
* lordmauve, pointed out width and spaces bug
