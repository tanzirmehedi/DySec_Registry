from django.apps import AppConfig


class DjangoRequestingOsAnalyzerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_requesting_os_analyzer'
