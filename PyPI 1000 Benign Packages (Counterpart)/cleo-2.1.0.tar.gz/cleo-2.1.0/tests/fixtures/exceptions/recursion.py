def recursion_error() -> None:
    recursion_error()
