def simple_exception() -> None:
    raise Exception("Failed")
