# Arcane snapchat README

## Credentials

The access token for production environnement has been generated with: snapchat@arcane.run
The access token for staging environnement has been generated with: billel@arcane.run

The access token can be be expired, we receive a 401 if it is the case. We need to use the refresh token located in the credentials, this token is generated through a one time life 'code'. For more information :
https://marketingapi.snapchat.com/docs/#receive-the-redirected-user 

## Release history
To see changes, please see CHANGELOG.md
