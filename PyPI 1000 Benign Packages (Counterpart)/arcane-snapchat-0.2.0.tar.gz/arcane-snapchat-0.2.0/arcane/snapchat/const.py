SNAPCHAT_SERVER_URL_LOGIN = 'https://accounts.snapchat.com/login/oauth2'
SNAPCHAT_SERVER_URL_API = 'https://adsapi.snapchat.com/v1'
