# Examples

Some example botafar bots.

Divided into simple examples without no dependencies, Respberry Pi examples, which require gpiozero library.

Check [Get started](https://docs.botafar.com/get_started) and [Raspberry Pi tutorial](https://docs.botafar.com/raspi) for more info.
