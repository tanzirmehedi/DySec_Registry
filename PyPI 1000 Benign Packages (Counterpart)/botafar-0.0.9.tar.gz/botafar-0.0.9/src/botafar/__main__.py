from ._internal.main.cli import _cli

if __name__ == "__main__":
    _cli()  # This enables `python -m botafar` from cli
