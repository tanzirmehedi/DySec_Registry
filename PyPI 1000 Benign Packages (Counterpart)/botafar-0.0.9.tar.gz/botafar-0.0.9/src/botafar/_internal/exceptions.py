class SleepCancelledError(Exception):
    pass
