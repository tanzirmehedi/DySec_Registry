# botafar

```{include} ../../README.md
:start-after: <!-- start intro -->
:end-before: <!-- end intro -->
```

```{toctree}
:hidden:

get_started
basics
raspi
arduino
twitch_and_youtube
advanced
advanced_arduino_raspi
reference
changelog
```

<!--

```{toctree}
:hidden:
:caption: Advanced

controls
bot_lifecycle
```

-->

<!--

```{toctree}
:hidden:
:caption: Other

reference
development
```

-->