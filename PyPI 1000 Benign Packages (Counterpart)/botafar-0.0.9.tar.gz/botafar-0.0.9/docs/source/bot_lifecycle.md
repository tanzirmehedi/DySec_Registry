# Bot lifecycle

Coming soon

Other topics:

- cli
- terminal controls
