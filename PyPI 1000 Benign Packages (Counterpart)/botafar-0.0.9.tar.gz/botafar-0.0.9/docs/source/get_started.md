# Get started

```{include} ../../README.md
:start-after: <!-- start get_started -->
:end-before: <!-- end get_started -->
```
