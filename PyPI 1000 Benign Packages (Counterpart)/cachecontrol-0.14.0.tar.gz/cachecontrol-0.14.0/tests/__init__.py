"""Tests for CacheControl."""
