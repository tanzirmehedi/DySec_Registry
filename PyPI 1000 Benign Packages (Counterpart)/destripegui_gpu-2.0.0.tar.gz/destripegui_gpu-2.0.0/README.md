
Live Destriping GUI with GPU-accelerated destriping
==============

**Installation instructions**
Instructions for installing GPU Live Destriping GUI:
0. Ensure Anaconda is installed on the computer.
1. Go to Go to https://github.com/LifeCanvas-Technologies/destripegui/tree/gpu-destripe and click the green "<> Code" button. 
2. Download it by clicking "Download Zip"
3. Extract the folder somewhere
4. Navigate to the folder (named "destripegui") in File Explorer, and then double click "install.bat". This will do all the necessary installations
5. Run the GUI by opening a command line and typing ``conda activate destripegui`` followed by ``destripegui``
