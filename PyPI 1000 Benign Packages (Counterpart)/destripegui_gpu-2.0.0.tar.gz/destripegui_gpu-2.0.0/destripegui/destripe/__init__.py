supported_extensions = ['.tif', '.tiff', '.raw', '.png']
supported_output_extensions = ['.tif', '.tiff']
