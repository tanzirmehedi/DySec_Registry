testedit
Lib: colours_library

Lead dev: Eryk Malczyk

INSTALLATION

pip install colours_library


----------------------------

USAGE

python3

------------>

from colours_library import MostCommonColor
c = MostCommonColor('path_to_image', N(number of colors))

------------->

c.produce()

-----------------------------
OUTPUT

List of N colours sorted by frequency.
