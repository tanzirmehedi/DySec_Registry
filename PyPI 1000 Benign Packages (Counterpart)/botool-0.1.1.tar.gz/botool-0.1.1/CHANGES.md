CHANGES
=======

Next Release (TBD)
------------------

 - TBD

0.1 (2014-02-10)
----------------

- Initial release
- IAM basics for creating roles, groups and users. Manages user roles, but everything else is add only right now.


