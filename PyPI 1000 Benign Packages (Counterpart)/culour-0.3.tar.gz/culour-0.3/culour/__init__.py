from .culour import addstr

__all__ = ["addstr"]
