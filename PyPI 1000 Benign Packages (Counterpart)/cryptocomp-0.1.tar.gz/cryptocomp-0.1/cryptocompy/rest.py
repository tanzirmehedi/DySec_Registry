# rest.py
# other get functions, temporary file


def AllExchanges:
	pass
	