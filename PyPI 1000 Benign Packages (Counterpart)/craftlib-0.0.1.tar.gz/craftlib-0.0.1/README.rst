# craftlib

This package is an implementation of common data structures in Python. The package is a light-weighted, simplified implementation.

Therefore, it is called craftlib.

Reference for implementation:

**邓俊辉，《数据结构（C++版）》**

**侯捷，《STL 源码剖析》**

