a  =    3
# fmt: off
b,    c = 1, 2
d =    6  # fmt: skip
e = 5
# fmt: on
f = ["This is a very long line that should be formatted into a clearer line ", "by rearranging."]

# output

a = 3
# fmt: off
b,    c = 1, 2
d =    6  # fmt: skip
e = 5
# fmt: on
f = [
    "This is a very long line that should be formatted into a clearer line ",
    "by rearranging.",
]
