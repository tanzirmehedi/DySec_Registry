async def func() -> (int):
    return 0


@decorated
async def func() -> (int):
    return 0


async for (item) in async_iter:
    pass


# output


async def func() -> int:
    return 0


@decorated
async def func() -> int:
    return 0


async for item in async_iter:
    pass
