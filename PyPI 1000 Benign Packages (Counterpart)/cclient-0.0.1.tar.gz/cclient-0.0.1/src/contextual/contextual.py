def contextual():
    return "Hello World!"

