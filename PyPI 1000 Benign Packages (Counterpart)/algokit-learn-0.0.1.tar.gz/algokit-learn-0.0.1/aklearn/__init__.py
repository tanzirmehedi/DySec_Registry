# algokit-learn/aklearn/__init__.py

def test():
    print("aklearn is working!")