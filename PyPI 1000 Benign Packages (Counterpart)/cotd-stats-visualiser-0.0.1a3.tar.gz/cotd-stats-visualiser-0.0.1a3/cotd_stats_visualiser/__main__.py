import sys

from . import main

main(sys.argv[1:])
