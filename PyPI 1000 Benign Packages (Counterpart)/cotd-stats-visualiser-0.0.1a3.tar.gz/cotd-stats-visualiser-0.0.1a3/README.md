# THIS IS A WIP

soon more information, but basically this will give you a plot for COTD stats for you (or other players) from the game
Trackmania 2020.
