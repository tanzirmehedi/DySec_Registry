# coding: utf8

from .cprint import cprint
from .myprint import Cprint

ccprint = Cprint().cprint



"""
    This module give to possibility to print in color.
"""
