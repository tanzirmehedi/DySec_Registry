from django.apps import AppConfig


class PushHttp2Config(AppConfig):
    name = "django_http2_push"
