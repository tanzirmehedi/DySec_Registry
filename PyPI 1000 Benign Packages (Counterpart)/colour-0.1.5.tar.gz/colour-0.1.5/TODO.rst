TODO
====

- ANSI 16-color and 256-color escape sequence generation
- YUV, HSV, CMYK support


