import fire

from .captchasolver import solve

def main():
    fire.Fire(solve)
