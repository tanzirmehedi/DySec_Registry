# Depend�ncias Externas #

sox(win32) - https://sourceforge.net/projects/sox/files/latest/download?source=files  
sox(posix) - sudo apt-get sox
