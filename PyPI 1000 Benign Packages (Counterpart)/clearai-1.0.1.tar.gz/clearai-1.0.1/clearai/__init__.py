"""
:authors: NullGuy
:copyright: (c) 2023 NullGuy
"""

from .clearai import ClearAI