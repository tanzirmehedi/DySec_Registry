from setuptools import setup, find_packages

setup(
    name='dfadsfsfasdfa',
    version='0.1.0',
    description='A brief description of your package',
    author='hrewew',
)
