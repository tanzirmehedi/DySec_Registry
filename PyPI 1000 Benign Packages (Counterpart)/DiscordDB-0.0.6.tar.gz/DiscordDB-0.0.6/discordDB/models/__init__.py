from .types import Data


__all__ = [
    "Data",
]
