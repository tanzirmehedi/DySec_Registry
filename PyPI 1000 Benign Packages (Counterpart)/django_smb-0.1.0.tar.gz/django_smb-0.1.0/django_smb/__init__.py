default_app_config = 'django_smb.apps.DjangoSmbConfig'
