"""clip-video-encode dataset."""

from .dataset_reader import EmbeddingWebDatasetReader
