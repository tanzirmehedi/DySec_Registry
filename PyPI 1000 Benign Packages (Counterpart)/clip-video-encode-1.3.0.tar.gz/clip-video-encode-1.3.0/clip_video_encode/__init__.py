"""clip video encode"""

from .clip_video_encode import clip_video_encode
