"""
discord_port is a simple way to make auth with the Discord API!
"""
from auth import AuthClient as AuthClient
from user import UserAPI as UserAPI

__name__ = "discord_port"
__version__ = '1.3'