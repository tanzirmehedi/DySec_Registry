from .app_constants import LOADING_GIF
from .misc import COCO_INSTANCE_CATEGORY_NAMES
