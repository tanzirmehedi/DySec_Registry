import os

LOADING_GIF = os.path.abspath("./assets/icons/dark/loading.gif")
