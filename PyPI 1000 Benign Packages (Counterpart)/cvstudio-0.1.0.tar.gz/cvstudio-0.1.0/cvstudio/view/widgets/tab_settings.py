from PyQt5.QtWidgets import QWidget


class SettingsTabWidget(QWidget):
    def __init__(self, parent=None):
        super(SettingsTabWidget, self).__init__(parent)
