from .lateral_menu import LateralMenu, LateralMenuItemLoc
