from enum import auto


class Framework:
    PyTorch = auto()
    TensorFlow = auto()
