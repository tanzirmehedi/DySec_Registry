__author__ = 'Farsheed Ashouri'
from auth.CAS.authorization import Authorization
from auth.CAS.REST.service import api
#from auth.CAS.REST.client import Client
from werkzeug.serving import run_simple as serve
