=====
Usage
=====

To use @model in a project::

    import atmodel
