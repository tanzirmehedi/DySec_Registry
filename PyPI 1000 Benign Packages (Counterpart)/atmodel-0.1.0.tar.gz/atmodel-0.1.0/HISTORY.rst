=======
History
=======

0.1.0 (2019-10-01)
------------------

* First release on PyPI.
