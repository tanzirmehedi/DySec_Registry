=======
Credits
=======

Development Lead
----------------

* Alexandr Mansurov <alex@eghuro.cz>

Contributors
------------

None yet. Why not be the first?
