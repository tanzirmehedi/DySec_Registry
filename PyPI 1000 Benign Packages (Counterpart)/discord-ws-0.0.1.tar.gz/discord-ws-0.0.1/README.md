# Discord Websockets
### An asynchronous wrapper for the Discord websocket gateway api