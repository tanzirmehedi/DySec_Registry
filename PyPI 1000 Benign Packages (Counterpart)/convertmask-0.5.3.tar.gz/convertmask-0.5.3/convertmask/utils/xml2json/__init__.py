'''
lanhuage: python
Descripttion: this script(method) is only support convert xml to json with "polygon" tag and need the origin img(maybe not if you want a black-white img in labelme)
version: beta
Author: xiaoshuyui
Date: 2020-09-24 08:58:35
LastEditors: xiaoshuyui
LastEditTime: 2020-09-24 09:31:55
'''