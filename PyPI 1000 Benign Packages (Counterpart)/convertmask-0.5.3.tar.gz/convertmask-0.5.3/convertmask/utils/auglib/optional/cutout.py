'''
lanhuage: python
Descripttion: 
version: beta
Author: xiaoshuyui
Date: 2020-11-18 10:09:21
LastEditors: xiaoshuyui
LastEditTime: 2021-01-05 10:16:39
'''

from convertmask import baseDecorate

@baseDecorate()
def cutout():
    print('please use convertmask.utils.auglib.optional.crop instead')