'''
lanhuage: python
Descripttion: 
version: beta
Author: xiaoshuyui
Date: 2020-08-14 17:01:39
LastEditors: xiaoshuyui
LastEditTime: 2021-02-19 17:03:37
'''

"""
This script may be deleted and all codes will be moved to __init__.py
"""
# class Ori_Pro(object):
#     def __init__(self, oriImg, processedImg):
#         self.oriImg = oriImg
#         self.processedImg = processedImg


# def do_nothing():
#     pass


# class Img_clasId(object):
#     def __init__(self, img, clasId: int):
#         self.img = img
#         self.clasId = clasId