
H2_PROTOCOLS = ["h2", "h2-16", "h2-14", "h2c", "h2-12", "h2-13", "h2-04"]
MAX_HTTP2_CONCURRENT_STREAMS = 1
