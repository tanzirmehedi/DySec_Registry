from setuptools import setup

with open("README.md", "r") as fh:
    readme = fh.read()

setup(name='diffuser',
    version='0.0.1',
    license='MIT License',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='',
    keywords='',
    description=u'',)
