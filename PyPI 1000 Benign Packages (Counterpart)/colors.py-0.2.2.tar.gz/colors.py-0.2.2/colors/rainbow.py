"""
colors.rainbow
==============
ROYGBIV!
"""
from .base import rgb

red = rgb(255, 0, 0)
orange = rgb(255, 165, 0)
yellow = rgb(255, 255, 0)
green = rgb(0, 128, 0)
blue = rgb(0, 0, 255)
indigo = rgb(75, 0, 130)
violet = rgb(238, 130, 238)
