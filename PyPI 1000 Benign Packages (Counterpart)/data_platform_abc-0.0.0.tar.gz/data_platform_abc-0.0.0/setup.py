from setuptools import setup

setup(
    name="data-platform-abc",
    version="0.0.0",
)
