"""cputils - Utilities for Competitive Programming"""

__version__ = '0.2.0'
__author__ = 'Dih5 <dihedralfive@gmail.com>'
