Contributing
============

Patches and suggestions are strongly encouraged! GitHub pull requests are
preferred, but other mechanisms of feedback are welcome.
