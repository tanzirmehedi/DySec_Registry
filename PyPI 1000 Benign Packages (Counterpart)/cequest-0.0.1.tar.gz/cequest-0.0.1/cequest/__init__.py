from .req import get, options, head, post, put, patch, delete
from .sess import Session
from . import exceptions

__author__ = "ecriminals"
__version__ = "0.0.1"