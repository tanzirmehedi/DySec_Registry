#
# this function concatenates  str2 to str1 and this is for testing
#
def appendString(str1, str2):
    return str1 + str2

if __name__ == "__main__":
    print(appendString("kim", "park"))
    