
# bips
bips is a Python library to play out beeping sounds to trigger audio alerts.

## Installation
Use the package manager "pip install" to install bips.

```bash
pip install bips
```

## Contributing
Pull requests are welcome.

## Contributor/s
mose_tucker_0159 -- mose.tucker.0159@gmail.com

## License
[MIT]( https://choosealicense.com/licenses/mit )
