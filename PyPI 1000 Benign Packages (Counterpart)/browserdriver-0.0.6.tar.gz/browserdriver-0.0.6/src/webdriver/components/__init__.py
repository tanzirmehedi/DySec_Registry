from webdriver.components.element import Element

__all__ = ['Element']
