from setuptools import setup, find_packages

setup(
    name="Colorfully",
    version='',
    author="Suzuya",
    author_email="suzuyagvng@protobmail.com",
    description='To make a beautiful script in python',
    long_description_content_type="text/markdown",
    long_description='To make a beautiful script in python',
    packages=find_packages(),
    install_requires=[],
    keywords=['python', 'color', 'colorama'],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)
