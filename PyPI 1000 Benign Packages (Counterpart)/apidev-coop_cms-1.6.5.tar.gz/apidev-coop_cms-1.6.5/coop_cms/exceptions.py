# -*- coding: utf-8 -*-
"""
"""


class ArticleNotAllowed(Exception):
    pass
