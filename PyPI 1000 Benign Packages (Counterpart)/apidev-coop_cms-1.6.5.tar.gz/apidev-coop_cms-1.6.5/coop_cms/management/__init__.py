# -*- coding: utf-8 -*-
"""management package"""
