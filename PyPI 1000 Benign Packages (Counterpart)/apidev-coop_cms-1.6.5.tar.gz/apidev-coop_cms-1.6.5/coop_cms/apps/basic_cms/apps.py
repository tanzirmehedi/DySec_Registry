# -*- coding: utf-8 -*-
"""
Basic app for article
"""

from django.apps import AppConfig


class BasicCmsAppConfig(AppConfig):
    name = 'coop_cms.apps.basic_cms'
    verbose_name = "coop CMS > Basic CMS"
