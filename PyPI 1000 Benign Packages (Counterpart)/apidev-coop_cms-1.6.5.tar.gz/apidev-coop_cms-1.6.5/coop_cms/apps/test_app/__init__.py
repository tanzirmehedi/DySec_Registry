# -*- coding: utf-8 -*-
"""this app is meant for unit testing some parts of coop_cms"""

default_app_config = 'coop_cms.apps.test_app.apps.CoopCmsTestAppConfig'