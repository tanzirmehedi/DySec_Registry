# -*- coding: utf-8 -*-
"""
Demo
"""

from django.apps import AppConfig


class DemoCmsAppConfig(AppConfig):
    name = 'coop_cms.apps.demo_cms'
    verbose_name = "coop CMS > Demo CMS"
