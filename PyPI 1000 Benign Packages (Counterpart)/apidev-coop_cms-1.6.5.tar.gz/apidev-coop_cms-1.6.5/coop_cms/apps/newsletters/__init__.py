# -*- coding: utf-8 -*-

default_app_config = 'coop_cms.apps.newsletters.apps.AppConfig'
