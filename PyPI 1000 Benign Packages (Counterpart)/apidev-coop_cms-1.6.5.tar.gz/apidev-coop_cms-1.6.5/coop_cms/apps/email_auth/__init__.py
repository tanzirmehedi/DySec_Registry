# -*- coding: utf-8 -*-
"""Use email rather than username for user authentication"""

default_app_config = 'coop_cms.apps.email_auth.apps.EmailAuthAppConfig'
