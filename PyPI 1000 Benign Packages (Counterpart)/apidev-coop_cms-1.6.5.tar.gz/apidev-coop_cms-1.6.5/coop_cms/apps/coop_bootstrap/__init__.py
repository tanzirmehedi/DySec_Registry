# -*- coding: utf-8 -*-
"""
coop_bootstrap : bootstrap integration in coop_cms
"""

default_app_config = 'coop_cms.apps.coop_bootstrap.apps.CoopBootstrapAppConfig'
