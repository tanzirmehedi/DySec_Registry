# -*- coding: utf-8 -*-
"""
Default CMS application : It define a simple Article  # Just for compatibility
"""

from ...bs_forms import Form, ModelForm


class BootstrapForm(Form):  # pylint: disable=R0901
    """Deprecated: Just for compatibility"""
    pass


class BootstrapModelForm(ModelForm):  # pylint: disable=R0901
    """Deprecated: Just for compatibility"""
    pass
