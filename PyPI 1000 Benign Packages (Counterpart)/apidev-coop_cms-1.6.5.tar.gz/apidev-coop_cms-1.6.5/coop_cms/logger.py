# -*- coding: utf-8 -*-
"""logger"""

import logging

logger = logging.getLogger("coop_cms")