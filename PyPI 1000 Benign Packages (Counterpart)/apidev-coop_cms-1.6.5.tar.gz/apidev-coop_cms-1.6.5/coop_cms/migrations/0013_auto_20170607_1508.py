# -*- coding: utf-8 -*-

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('coop_cms', '0012_auto_20170502_1125'),
    ]

    operations = [

    ]
