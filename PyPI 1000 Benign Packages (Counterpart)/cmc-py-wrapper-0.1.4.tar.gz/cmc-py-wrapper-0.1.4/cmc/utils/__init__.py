#!/usr/bin/env python

"""Utility modules used by `cmc-py` library."""
