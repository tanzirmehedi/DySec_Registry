#!/usr/bin/env python

"""Resource modules used by `cmc-py` library."""
