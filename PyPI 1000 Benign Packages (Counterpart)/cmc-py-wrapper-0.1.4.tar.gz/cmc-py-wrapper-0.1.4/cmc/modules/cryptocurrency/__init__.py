#!/usr/bin/env python

"""Module for classes fetching data related to CryptoCurrencies."""
