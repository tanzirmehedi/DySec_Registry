import colorsapyto


def ma_fonction():
    print("Bonjour!")