from setuptools import setup

setup(name='colorsapyto',
      version='1.0',
      description='test',
      packages=['colorsapyto'],
      author_email='nicolastecasselecrane@gmail.com',
      zip_safe=False)