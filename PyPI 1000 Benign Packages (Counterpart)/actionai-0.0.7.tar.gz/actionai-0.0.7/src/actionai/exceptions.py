class ActionAIException(Exception):
    pass
