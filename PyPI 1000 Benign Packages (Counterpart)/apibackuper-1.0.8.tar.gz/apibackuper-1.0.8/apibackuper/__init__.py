"""
apibackuper: a command-line tool and python library for API backuping

"""
__version__ = "1.0.8"
__author__ = "Ivan Begtin"
__licence__ = "MIT"
