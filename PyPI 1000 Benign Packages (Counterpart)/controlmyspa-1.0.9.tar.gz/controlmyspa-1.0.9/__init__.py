"""
Import class from file
"""

from controlmyspa.controlmyspa import ControlMySpa

__all__ = ["ControlMySpa"]
