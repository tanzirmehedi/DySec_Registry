__version__ = '0.0.9'
__description__ = 'Base node for creaturecast'
__author__ = 'Paxton Gerrish'
__email__ = 'creaturecastlabs@gmail.com'
__url__ = 'https://github.com/Paxtongerrish/creaturecast_node.git'

