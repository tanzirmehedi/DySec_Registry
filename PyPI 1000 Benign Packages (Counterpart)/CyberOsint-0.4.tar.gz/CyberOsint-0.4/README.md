
# CyberOsint

CyberOsint is a tool for OSINT (Open Source Intelligence).

## Installation

You can install the package via pip:

```sh
pip install CyberOsint
```

## Usage

To use the tool, simply run:

```sh
cyberosint
```
