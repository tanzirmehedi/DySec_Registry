from distutils.core import setup

setup(
    name = 'diony_test',
    version = '1.0.0',
    py_modules = ['diony_test'],
    author = 'diony',
    author_email = 'dionysus11@naver.com',
    url = 'http://dionysus11.iptime.org',
    description = 'test',
    )
