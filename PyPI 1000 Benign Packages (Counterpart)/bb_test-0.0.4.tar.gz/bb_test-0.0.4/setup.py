
from setuptools import setup
setup(
    name='bb_test',
    version='0.0.4',
    description='Brandon\'s test package',
    long_description='There\'s not a lot to say about it',
    #url='https://bb-ai.net/KARaML/KARaML_Tools.html',
    author='brandonb',
    author_email='B.Bennett@leeds.ac.uk',
    packages=['bb_test'],
    classifiers=['Development Status :: 1 - Planning'],
)
