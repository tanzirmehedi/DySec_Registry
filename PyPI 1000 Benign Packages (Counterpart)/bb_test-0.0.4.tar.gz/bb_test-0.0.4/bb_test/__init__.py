
print( "Yey! Running __init__.py in bb_test package!")

from .bb_module import *
