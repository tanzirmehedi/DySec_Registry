# bytetrack-pip
packaged version of ifzhang/ByteTrack
