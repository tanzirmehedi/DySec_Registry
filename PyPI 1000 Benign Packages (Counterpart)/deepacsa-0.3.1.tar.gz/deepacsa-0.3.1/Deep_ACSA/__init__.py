""" Container for all our package modules."""

__version__ = "0.3.1"

_author__ = ["Paul Ritsche"]

__all__ = ["deep_acsa_gui"]

from Deep_ACSA.deep_acsa_gui import *
