"""This modules contains code to allow usage of the GUI from the command line"""

from Deep_ACSA.deep_acsa_gui import runMain

if __name__ == "__main__":
    runMain()
