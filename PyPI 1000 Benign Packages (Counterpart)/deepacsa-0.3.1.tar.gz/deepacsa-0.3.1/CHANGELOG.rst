
2023-10-04
==========

Fixed
-----

- GUI interaction with matplotlib figures updated for better UX

2023-10-01
==========

Fixed
-----

- GUI functionalities due to changes in layout.

2023-10-01
==========

Added
-----

- Figures to documentation for model training workflow.

Changed
-------

- Updated docs for image labelling and inspection.

2023-09-24
==========

Removed
-------

- Filetype widget in GUI.

Changed
-------

- GUI layout

2023-09-24
==========

Removed
-------

- Filetype widget in GUI.

Changed
-------

- GUI layout

2023-08-30
==========

Added
-----

- Mask creation inside of GUI
- Mask analysis inside of GUI

2023-06-04
==========

Added
-----

- Documentation
- Model training window
- Image saving in PDF now as overlay instead of binary
- Image augmentation option
- Loss function dropdown list to include models trained with different losses

Changed
-------

- Import statements
- Code documentation
- Documentation start page and usage description
- Image saving in PDF now includes overlay
- EXE update
- Model training to allow training with different loss functions
