__title__ = "ControlManual"
__authors__ = __author__ = "ZeroIntensity and 2231puppy"
__license__ = "MIT"
__version__ = "0.0.4.0"

if __name__ == "__main__":
    print(f"""Title: {__title__}
Authors: {__authors__}
License: {__license__}
Version: {__version__}""")