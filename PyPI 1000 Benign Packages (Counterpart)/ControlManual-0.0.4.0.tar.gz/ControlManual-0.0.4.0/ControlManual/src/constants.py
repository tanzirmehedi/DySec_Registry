import os

cm_dir: str = os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))