from ..console import console

def error(message: str) -> None:
    console.error(message)
