from ..console import console

def success(message: str) -> None:
    console.success(message)
