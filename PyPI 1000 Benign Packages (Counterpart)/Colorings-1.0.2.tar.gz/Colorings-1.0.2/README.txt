#Colorings
## All infos on https://github.com/antjules27/Colorings