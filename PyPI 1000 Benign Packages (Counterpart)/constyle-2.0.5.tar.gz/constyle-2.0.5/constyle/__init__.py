"""
.. include:: ../README.md
"""

from ._style import Style, style
from ._attributes import Attributes

__all__ = ["Style", "Attributes", "style"]
