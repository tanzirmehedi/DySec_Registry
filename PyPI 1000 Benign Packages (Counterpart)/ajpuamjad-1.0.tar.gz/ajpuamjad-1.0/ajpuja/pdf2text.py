""" This module provides"""


def convert(path):
    """
    convert the given pdf to text.

    Parameter:
    path (str): the path to a pdf file

    Returns:
    str: The content of the pdf
    """
    print("pdf2text")