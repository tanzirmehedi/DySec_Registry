class BrawlType:
    def __init__(self, client):
        self.client = client
        self.request = client.request