from setuptools import setup

setup(name='calculator_313bbd7c19bfc98a',
      version='1',
      packages=['calculator_313bbd7c19bfc98a'])

