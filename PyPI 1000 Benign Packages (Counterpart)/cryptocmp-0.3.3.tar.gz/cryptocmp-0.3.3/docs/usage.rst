=====
Usage
=====

To use cryptocmp in a project::

    import cryptocmp
