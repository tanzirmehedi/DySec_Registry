# -*- coding: utf-8 -*-

"""Top-level package for cryptocmp."""

URL_BASE = 'https://min-api.cryptocompare.com/'
__author__ = 'Ivan Bogush'
__email__ = 'bogush.vano@gmail.com'
__version__ = '0.3.3'
