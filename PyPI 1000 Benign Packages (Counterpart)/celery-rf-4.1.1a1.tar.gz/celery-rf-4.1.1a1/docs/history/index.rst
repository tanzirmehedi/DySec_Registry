.. _history:

=========
 History
=========

This section contains historical change histories, for the latest
version please visit :ref:`changelog`.

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    changelog-4.0
    changelog-3.1
    whatsnew-3.0
    changelog-3.0
    whatsnew-2.5
    changelog-2.5
    changelog-2.4
    changelog-2.3
    changelog-2.2
    changelog-2.1
    changelog-2.0
    changelog-1.0
