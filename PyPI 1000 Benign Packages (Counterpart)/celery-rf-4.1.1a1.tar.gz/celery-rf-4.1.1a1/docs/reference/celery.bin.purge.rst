=====================================================
 ``celery.bin.purge``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.purge

.. automodule:: celery.bin.purge
    :members:
    :undoc-members:
