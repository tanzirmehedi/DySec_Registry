from setuptools import setup

setup(name='botingram',
      version='0.1',
      license='MIT',
      author='Arseniy Puzikov',
      author_email='puars09@gmail.com',
      description='New python library for telegram bots',
      packages=['botingram'],
      zip_safe=False)