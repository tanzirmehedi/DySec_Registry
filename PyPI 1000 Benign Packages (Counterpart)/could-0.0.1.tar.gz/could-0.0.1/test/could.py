import unittest


class CouldTest(unittest.TestCase):
    pass

if __name__ == "__main__":
    unittest.main()
