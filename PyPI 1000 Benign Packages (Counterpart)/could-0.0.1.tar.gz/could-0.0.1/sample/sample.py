from could.could import Could


class Could(object):
    pass
