from cli.shared.types.evaluation.evaluation import AdversarialEvaluationCliConfigType

__all__ = [
    "AdversarialEvaluationCliConfigType",
]
