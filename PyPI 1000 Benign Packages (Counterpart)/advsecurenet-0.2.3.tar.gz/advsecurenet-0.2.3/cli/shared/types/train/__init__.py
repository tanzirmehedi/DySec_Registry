from cli.shared.types.train.training import TrainingCliConfigType

__all__ = [
    "TrainingCliConfigType",
]
