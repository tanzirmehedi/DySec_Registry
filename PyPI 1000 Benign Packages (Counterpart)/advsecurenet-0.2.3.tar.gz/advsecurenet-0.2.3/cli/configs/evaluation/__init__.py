# Title of the module
MODULE_TITLE = "Evaluation Configurations"

# Description of the module
MODULE_DESCRIPTION = """
    This module contains the configurations for the evaluation of the models.
"""

# Flag to include this module in CLI configurations
INCLUDE_IN_CLI_CONFIGS = True
