# Flag to include this module in CLI configurations
INCLUDE_IN_CLI_CONFIGS = False
