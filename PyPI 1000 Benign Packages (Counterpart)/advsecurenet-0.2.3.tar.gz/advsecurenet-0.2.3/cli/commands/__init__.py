"""
This folder contains the CLI commands for the application. It is divided into subfolders based on the functionality of the commands.
"""
