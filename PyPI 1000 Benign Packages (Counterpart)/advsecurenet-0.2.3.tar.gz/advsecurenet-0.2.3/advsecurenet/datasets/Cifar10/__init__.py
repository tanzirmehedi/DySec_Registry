from advsecurenet.datasets.Cifar10.cifar10_dataset import (
    CIFAR10Dataset,
    CIFAR100Dataset,
)
