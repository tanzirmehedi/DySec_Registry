# __init__.py

from .logging import setup_logging

# Initialize logging
setup_logging()
