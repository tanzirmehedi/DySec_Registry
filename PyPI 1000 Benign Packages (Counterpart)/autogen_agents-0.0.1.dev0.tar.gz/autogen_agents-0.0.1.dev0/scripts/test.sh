#!/bin/bash

coverage run -m pytest --ff "$@"
