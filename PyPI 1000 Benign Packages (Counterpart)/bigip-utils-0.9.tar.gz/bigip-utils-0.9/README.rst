

BigIP Utils:
===============
Various classes and function to help talk to F5 devices using their Rest API.

Installing
============
.. code-block:: bash

    pip install bigip-utils

Usage
=====

.. code-block:: bash

    >>> from bigip-utils import *
    >>> bigip-utils.__version__
    '0.2'
