from setuptools import setup

setup(
    name='connection',
    version='2021.7.20',
    install_requires=[
        'requests'
    ],
    packages=[
        'connection'
    ]
)
