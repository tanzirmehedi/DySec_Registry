# coding: utf-8
from __future__ import unicode_literals

from .base import Dehydrator
from .shortcuts import dehydrate
from .spec import S
