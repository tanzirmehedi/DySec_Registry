Changelog
=========
0.3 (2013-07-07)
----------------
* New syntax for nested dehydration

0.2 (2013-06-19)
----------------
* fields parameter renamed to specs
* improved README

