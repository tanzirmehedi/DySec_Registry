from senthil.helper import sleep, help_other
from interns.utils import ask_for_help