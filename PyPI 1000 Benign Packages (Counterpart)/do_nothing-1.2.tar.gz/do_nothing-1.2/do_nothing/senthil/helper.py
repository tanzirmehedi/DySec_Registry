def sleep():
    return "I am sleeping"

def help_other():
    return "I know nothing"