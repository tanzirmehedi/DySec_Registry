from senthil.helper import help_other

def ask_for_help():
    print(help_other())
    return "I did my work"
