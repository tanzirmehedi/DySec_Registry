# discord-ext-bot version 0.0.6
An package for discord.py

# How to install

`pip install discord-ext-bot`

## Development version:
`pip install git+https://github.com/FrostiiWeeb/discord-ext-bot`

## Example:
from discord.ext import bot

bot = bot.Bot(command_prefix='!')

### Made by:
FrostiiWeeb
