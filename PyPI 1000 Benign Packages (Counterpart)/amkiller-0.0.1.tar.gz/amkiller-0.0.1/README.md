# PC KILLER WITH PYTHON
## this python script has only one File: **killer** and inside ther's just one funcion: **start**
## the script will use the **pyautogui**, **time**, **random** libraries and, the ONLY way to stop it is by shuting down the computer..
## by the way the program will start in a dramatic way