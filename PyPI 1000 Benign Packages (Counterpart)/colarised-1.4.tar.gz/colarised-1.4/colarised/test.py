#https://github.com/kittyplot/hexcolurs
#from hexcolurs import *
#u can use it like this

#red,blue,orange,etc

#from hexcolurs import Colors, Colorate

#print(Colorate.Horizontal(Colors.yellow_to_red, "Hello", 1))

#from hexcolurs import Colors, Colorate

#text = "Hello world!"

#print(Colors.blue + text)




#from hexcolurs import Write, Colors

#name = Write.Input("Enter your name -> ", Colors.red_to_purple, interval=0.0025)
#Write.Print(f"Nice to meet you, {name}!", Colors.blue_to_green, interval=0.05)

































































