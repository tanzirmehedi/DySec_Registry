
class ProjectsBaseNotSetException(Exception):
    pass
