# ai-supporter

https://pypi.org/project/ai-supporter
<pre>
pip install ai-supporter
</pre>

```
from ai_supporter.tts import tts

text = "this is text"
file = "speak.mp3"
tts(text, file)
```

```
from ai_supporter.tts import speak

text = "this is text"
speak(text)
```
