class Model:
    def __init__(self):
        pass
    def show(self):
        print("Testing model class")