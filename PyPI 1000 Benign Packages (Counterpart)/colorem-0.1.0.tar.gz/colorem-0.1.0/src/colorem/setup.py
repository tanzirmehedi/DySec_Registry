from setuptools import setup

exec(open("colorem/_version.py").read())

setup(
    version=__version__)