# colorem

# Description

COLOR mEets Munsell or colorem (from latin word for color), is an open-source toolbox programmed in Python for soil color applications.

# Installation

The colorem package can be installed directly from [PyPi](https://pypi.org/) running the pip command 
on the system shell:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Python 
>>> pip install colorem
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
