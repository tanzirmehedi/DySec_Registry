=====
Usage
=====

To use Artifact Management Tool in a project::

    import amt
