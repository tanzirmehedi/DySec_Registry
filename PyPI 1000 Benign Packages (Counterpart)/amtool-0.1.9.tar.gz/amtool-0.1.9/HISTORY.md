# History


## 0.1.9 (2019-07-02)

* Adding short descriptions to commands.

## 0.1.8 (2019-07-02)

* Package cleanup.

## 0.1.7 (2019-07-02)

* Documentation cleanup.

## 0.1.6 (2019-06-24)

* Debugging automated deployment to pypi.

## 0.1.5 (2019-06-24)

* Added uid command.

## 0.1.4 (2019-06-06)

* Debugging build issues.

## 0.1.3 (2019-05-12)

* Testing release automation.

## 0.1.2 (2019-05-12)

* Adding code coverage.

## 0.1.1 (2019-05-12)

* Automated deployment from travis.

## 0.1.0 (2019-04-23)

* First release on PyPI.
