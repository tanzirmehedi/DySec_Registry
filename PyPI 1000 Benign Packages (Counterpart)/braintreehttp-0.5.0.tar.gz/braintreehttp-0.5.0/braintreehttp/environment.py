class Environment(object):
    def __init__(self, base_url):
        self.base_url = base_url

