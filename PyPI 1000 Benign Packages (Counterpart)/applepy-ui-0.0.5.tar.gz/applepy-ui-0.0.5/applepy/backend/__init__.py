import sys

PLATFORM = sys.platform

_MACOS = PLATFORM == 'darwin'
_IOS = PLATFORM == 'ios'
