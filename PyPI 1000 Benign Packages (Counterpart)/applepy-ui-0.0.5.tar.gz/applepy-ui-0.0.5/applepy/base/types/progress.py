from enum import Enum


class ProgressStyle(Enum):
    bar = 0
    spinner = 1
