API
===

.. automodule:: copier_example

    ``copier_example``
    -----------------------------------

This is the internal API reference for copier_example

.. data:: copier_example.__version__
    :type: str

    Version number as calculated by https://github.com/pypa/setuptools_scm
