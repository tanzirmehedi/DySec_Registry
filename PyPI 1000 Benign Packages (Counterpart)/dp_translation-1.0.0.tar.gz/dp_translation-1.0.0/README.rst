.. image:: https://github.com/dataPuzzler/dp_translation/actions/workflows/test.yml/badge.svg?branch=master&event=workflow_dispatch
	:target: https://github.com/dataPuzzler/dp_translation/actions/workflows/test.yml/badge.svg?branch=master&event=workflow_dispatch
	:alt: Unit-tests Badge

dp_translation
==============

A python package that prepares the setup of a translation database in conjunction with sqlalchemy and dp_sqlalchemy_wrapper
