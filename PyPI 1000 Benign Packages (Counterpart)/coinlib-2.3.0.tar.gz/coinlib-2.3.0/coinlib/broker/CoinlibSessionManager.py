from coinlib.Registrar import Registrar


class CoinlibSessionManager:

    def __init__(self, sessionData=None):
        self.registrar = Registrar()
        pass
