from coinlib.logics.LogicOnlineWorker import LogicOnlineWorker

class LogicOnlineTraderWorker(LogicOnlineWorker):

    def initialize(self):
        super().initialize()
