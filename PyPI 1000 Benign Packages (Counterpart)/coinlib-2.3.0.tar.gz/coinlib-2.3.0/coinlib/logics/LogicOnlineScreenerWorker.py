from coinlib.logics.LogicOnlineWorker import LogicOnlineWorker


class LogicOnlineScreenerWorker(LogicOnlineWorker):

    def initialize(self):
        super().initialize()
