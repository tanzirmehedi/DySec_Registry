from coinlib.logics.LogicOnlineWorker import LogicOnlineWorker


class LogicOnlineDataWorker(LogicOnlineWorker):

    def initialize(self):
        super().initialize()
