from coinlib.helper import pip_install_or_ignore

def main():
    pass

if __name__ == '__main__':
    main()