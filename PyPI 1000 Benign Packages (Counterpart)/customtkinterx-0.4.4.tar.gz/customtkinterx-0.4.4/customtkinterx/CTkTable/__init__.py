"""
CustomTkinter Table widget
Author: Akash Bora
License: MIT
This is a custom table widget for customtkinter.
Homepage: https://github.com/Akascape/CTkTable
"""

__version__ = '0.2'

from .ctktable import CTkTable
