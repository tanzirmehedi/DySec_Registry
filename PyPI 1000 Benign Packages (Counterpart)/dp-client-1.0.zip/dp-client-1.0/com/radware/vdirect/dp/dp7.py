#
# Generated - DO not Modify
#
class DP7Meta(object):
    def __init__(self):
        self.rdwrClientsViewEntry = self.RdwrClientsViewEntry()
        self.rsIDSNewRulesEntryOne = self.RsIDSNewRulesEntryOne()
        self.rsStatefulPolicyEntry = self.RsStatefulPolicyEntry()
        self.rsNetFloodBypassIgmpEntry = self.RsNetFloodBypassIgmpEntry()
        self.rsIDSNewRulesEntryThree = self.RsIDSNewRulesEntryThree()
        self.rsMLBDNS = self.RsMLBDNS()
        self.rsWhiteList = self.RsWhiteList()
        self.rdwrDPPacketReport = self.RdwrDPPacketReport()
        self.vacmSecurityToGroupEntry = self.VacmSecurityToGroupEntry()
        self.rdwrVersionIdentifierEntry = self.RdwrVersionIdentifierEntry()
        self.rsIDSScanningPolicyEntry = self.RsIDSScanningPolicyEntry()
        self.rsMLBRemoteNatGlobalCnfg = self.RsMLBRemoteNatGlobalCnfg()
        self.rsIDSMemoryReservedTuning = self.RsIDSMemoryReservedTuning()
        self.rsFileSystem = self.RsFileSystem()
        self.rsSmtpParameters = self.RsSmtpParameters()
        self.rsBWMFarmRulesEntry = self.RsBWMFarmRulesEntry()
        self.rsWSDHttpsParams = self.RsWSDHttpsParams()
        self.rsIDSNetforensics = self.RsIDSNetforensics()
        self.rsREStateCounters = self.RsREStateCounters()
        self.rsWSDIfEntry = self.RsWSDIfEntry()
        self.dpsPendingTableTuning = self.DpsPendingTableTuning()
        self.rdwrMirroring = self.RdwrMirroring()
        self.rsSESSIONL3SynFloodReportTuning = self.RsSESSIONL3SynFloodReportTuning()
        self.rdwrDPJumboFrames = self.RdwrDPJumboFrames()
        self.rsIDSNewRulesEntryTwo = self.RsIDSNewRulesEntryTwo()
        self.rsAPMTuning = self.RsAPMTuning()
        self.rsIDSSignaturesAttackAttributeStaticEntry = self.RsIDSSignaturesAttackAttributeStaticEntry()
        self.lagMIBObjects = self.LagMIBObjects()
        self.rsIDS = self.RsIDS()
        self.rsBWM = self.RsBWM()
        self.rsMLBSrcSbntGroupEntry = self.RsMLBSrcSbntGroupEntry()
        self.rsNetFloodBypassIcmpEntry = self.RsNetFloodBypassIcmpEntry()
        self.rsMLBRemoteStationEntry = self.RsMLBRemoteStationEntry()
        self.rdwrDPRouting = self.RdwrDPRouting()
        self.rndDeviceParams = self.RndDeviceParams()
        self.rsStatisticsDiscoveryEntry = self.RsStatisticsDiscoveryEntry()
        self.rsMaxDspClntEntriesTuning = self.RsMaxDspClntEntriesTuning()
        self.rsMLB = self.RsMLB()
        self.vrrpAssoIpAddrEntry = self.VrrpAssoIpAddrEntry()
        self.rsIDSProfilesEntry = self.RsIDSProfilesEntry()
        self.rsBWMACLSummaryReportsEntry = self.RsBWMACLSummaryReportsEntry()
        self.rsSESSIONSynTriggerEntry = self.RsSESSIONSynTriggerEntry()
        self.rsIDSGroupEntry = self.RsIDSGroupEntry()
        self.rsIDSSynServersEntry = self.RsIDSSynServersEntry()
        self.rsNetFloodBypassUdpEntry = self.RsNetFloodBypassUdpEntry()
        self.rsBWMGroupNetworksListEntry = self.RsBWMGroupNetworksListEntry()
        self.sysOREntry = self.SysOREntry()
        self.rdwrApplicationFileEntry = self.RdwrApplicationFileEntry()
        self.rsBWMBwmVLANOperationEntry = self.RsBWMBwmVLANOperationEntry()
        self.rsIDSMPLSRDGroupEntry = self.RsIDSMPLSRDGroupEntry()
        self.rsIDSDOSOverloadEvent = self.RsIDSDOSOverloadEvent()
        self.rsCPCIDRPeerProhibitedMatchEntry = self.RsCPCIDRPeerProhibitedMatchEntry()
        self.rsIDSSLTACTtrackingEntry = self.RsIDSSLTACTtrackingEntry()
        self.rsNetFlood = self.RsNetFlood()
        self.rsMLBApplPortGroupEntry = self.RsMLBApplPortGroupEntry()
        self.rsBWMRulesIPObjectEntry = self.RsBWMRulesIPObjectEntry()
        self.rsIDSStatsEntry = self.RsIDSStatsEntry()
        self.rsIDSServerTableEntry = self.RsIDSServerTableEntry()
        self.rsStatefulStatisticsEntry = self.RsStatefulStatisticsEntry()
        self.rsBWMCurrentRulesIPObjectEntry = self.RsBWMCurrentRulesIPObjectEntry()
        self.rdwrDP = self.RdwrDP()
        self.rsIDSPPS = self.RsIDSPPS()
        self.rsIDSConnectionLimit = self.RsIDSConnectionLimit()
        self.rsNewBlackListEntryTwo = self.RsNewBlackListEntryTwo()
        self.rsBWMCurrentPolicyEntry = self.RsBWMCurrentPolicyEntry()
        self.rsDnsProtProfileEntry = self.RsDnsProtProfileEntry()
        self.ifStackEntry = self.IfStackEntry()
        self.rsMLBLinkEntry = self.RsMLBLinkEntry()
        self.rsIDSSynProfilesEntry = self.RsIDSSynProfilesEntry()
        self.ndSpec = self.NdSpec()
        self.rsIDSSignaturesProfileAttackListEntry = self.RsIDSSignaturesProfileAttackListEntry()
        self.rsMLBRemoteNat = self.RsMLBRemoteNat()
        self.rsAPMCurrentPolicyEntry = self.RsAPMCurrentPolicyEntry()
        self.rdwrSyslogServerEntry = self.RdwrSyslogServerEntry()
        self.rsIfEntry = self.RsIfEntry()
        self.rdwrSnmpParameters = self.RdwrSnmpParameters()
        self.rndCommunityEntry = self.RndCommunityEntry()
        self.rsBWMCurrentExtPolicyEntry = self.RsBWMCurrentExtPolicyEntry()
        self.rsStateful = self.RsStateful()
        self.usmUserEntry = self.UsmUserEntry()
        self.stpSpec = self.StpSpec()
        self.virtualLanProtocolVlan = self.VirtualLanProtocolVlan()
        self.dpsSIPCallTableTuning = self.DpsSIPCallTableTuning()
        self.rsIDSSLTNCPFEntry = self.RsIDSSLTNCPFEntry()
        self.rsMLBNHRDailyStatisticsEntry = self.RsMLBNHRDailyStatisticsEntry()
        self.rsIDSNewerSuspendTableEntry = self.RsIDSNewerSuspendTableEntry()
        self.vacmMIBViews = self.VacmMIBViews()
        self.rsBWMAppPortGroupEntry = self.RsBWMAppPortGroupEntry()
        self.reaIpxFftEntry = self.ReaIpxFftEntry()
        self.rsWSDSNMPPortsEntry = self.RsWSDSNMPPortsEntry()
        self.ipRedundRoutersEntry = self.IpRedundRoutersEntry()
        self.rsSESSIONSessionResetsTableTuning = self.RsSESSIONSessionResetsTableTuning()
        self.rsIDSOOPTableEntry = self.RsIDSOOPTableEntry()
        self.rsIDSSynProfilesParamsEntry = self.RsIDSSynProfilesParamsEntry()
        self.rndDeleteValuesEntry = self.RndDeleteValuesEntry()
        self.rdwrVrrpAssoIpV6AddrEntry = self.RdwrVrrpAssoIpV6AddrEntry()
        self.tftp = self.Tftp()
        self.rspRadiusParameters = self.RspRadiusParameters()
        self.rsIDSQuarantineFileSend = self.RsIDSQuarantineFileSend()
        self.rsDebugTraceApplEntryInternal = self.RsDebugTraceApplEntryInternal()
        self.rsNetFloodBypassTcpEntry = self.RsNetFloodBypassTcpEntry()
        self.dot3adAggPortDebugEntry = self.Dot3adAggPortDebugEntry()
        self.rsWSDManagementPortsEntry = self.RsWSDManagementPortsEntry()
        self.rsStatistics = self.RsStatistics()
        self.rsDebugFileRamEntry = self.RsDebugFileRamEntry()
        self.rsMLBNatEntry = self.RsMLBNatEntry()
        self.rsIDSReportDataAddressEntry = self.RsIDSReportDataAddressEntry()
        self.rsIpZeroHopRouting = self.RsIpZeroHopRouting()
        self.virtualLanPortEntry = self.VirtualLanPortEntry()
        self.rsStpPortEntry = self.RsStpPortEntry()
        self.rsBWMPhysicalPortGroupEntry = self.RsBWMPhysicalPortGroupEntry()
        self.rsBWMPolicyGroupCurrentEntry = self.RsBWMPolicyGroupCurrentEntry()
        self.snmpTargetObjects = self.SnmpTargetObjects()
        self.rsDnsProtDynamicStateTwoEntry = self.RsDnsProtDynamicStateTwoEntry()
        self.rsNetPortUtilizationEntry = self.RsNetPortUtilizationEntry()
        self.rspRadiusNasEntry = self.RspRadiusNasEntry()
        self.rsWSDNTCheckEntry = self.RsWSDNTCheckEntry()
        self.rsNewBlackListEntry = self.RsNewBlackListEntry()
        self.rsStatisticsProtocolPortsTuning = self.RsStatisticsProtocolPortsTuning()
        self.rsSESSIONSynProtectionRqstsTuning = self.RsSESSIONSynProtectionRqstsTuning()
        self.rsStatefulProfileEntry = self.RsStatefulProfileEntry()
        self.rsWSDStaticForwardingEntry = self.RsWSDStaticForwardingEntry()
        self.rsIDSSignaturesProfilesEntry = self.RsIDSSignaturesProfilesEntry()
        self.rsWSDApplicationMirrorEntry = self.RsWSDApplicationMirrorEntry()
        self.rsBWMContentTuning = self.RsBWMContentTuning()
        self.rsBWMACLActualPolicyEntry = self.RsBWMACLActualPolicyEntry()
        self.rdwrDPPassiveSSLPortEntry = self.RdwrDPPassiveSSLPortEntry()
        self.rsMLBMaxAllNatEntriesTuning = self.RsMLBMaxAllNatEntriesTuning()
        self.rsCPUserNamePromptEntry = self.RsCPUserNamePromptEntry()
        self.rndFACS = self.RndFACS()
        self.rsMLBPhysicalIDSServerEntry = self.RsMLBPhysicalIDSServerEntry()
        self.snmpTrap = self.SnmpTrap()
        self.rsWSDWebParams = self.RsWSDWebParams()
        self.snmpNotifyFilterEntry = self.SnmpNotifyFilterEntry()
        self.snmpMPDStats = self.SnmpMPDStats()
        self.rndMibFileEntry = self.RndMibFileEntry()
        self.rdwrConfigurationSyncMonitor = self.RdwrConfigurationSyncMonitor()
        self.rsSESSIONSynStatisticsEntry = self.RsSESSIONSynStatisticsEntry()
        self.rsMLBMaxTrackNHRTableEntriesTuning = self.RsMLBMaxTrackNHRTableEntriesTuning()
        self.rsIDSServProtection = self.RsIDSServProtection()
        self.rsExportPolicyEntry = self.RsExportPolicyEntry()
        self.rsAPMCurrentMonitorEntry = self.RsAPMCurrentMonitorEntry()
        self.rsMLBPriceEntry = self.RsMLBPriceEntry()
        self.ifRcvAddressEntry = self.IfRcvAddressEntry()
        self.rsMLBPrxyCheckFPIPEntry = self.RsMLBPrxyCheckFPIPEntry()
        self.ipCidrRouteEntry = self.IpCidrRouteEntry()
        self.rsMaxIpxForwardingEntriesTuning = self.RsMaxIpxForwardingEntriesTuning()
        self.rsMLBNoNatEntry = self.RsMLBNoNatEntry()
        self.rsIDSSLTProfilesEntry = self.RsIDSSLTProfilesEntry()
        self.rsSSLCertificateImportExport = self.RsSSLCertificateImportExport()
        self.snmpTargetAddrEntry = self.SnmpTargetAddrEntry()
        self.ipRedundancy = self.IpRedundancy()
        self.rsMLBNHRPriceDailyStatisticsEntry = self.RsMLBNHRPriceDailyStatisticsEntry()
        self.rsIDSynSSLMitigationAlteonPortsEntry = self.RsIDSynSSLMitigationAlteonPortsEntry()
        self.rsDeletePolicyEntry = self.RsDeletePolicyEntry()
        self.rdwrDefCfg = self.RdwrDefCfg()
        self.rsBWMCurrentRulesEntry = self.RsBWMCurrentRulesEntry()
        self.rsIDSAsAttackEntry = self.RsIDSAsAttackEntry()
        self.rsWSDTelnetParams = self.RsWSDTelnetParams()
        self.rsMaxBridgeForwardingEntriesTuning = self.RsMaxBridgeForwardingEntriesTuning()
        self.rsSSDvirtualLanPortEntry = self.RsSSDvirtualLanPortEntry()
        self.rdwrDPTunnelMonEntry = self.RdwrDPTunnelMonEntry()
        self.rsNetFloodBypassTcpSynEntry = self.RsNetFloodBypassTcpSynEntry()
        self.rdwrDPRoutingVifEntry = self.RdwrDPRoutingVifEntry()
        self.rsDebugFileFlashEntry = self.RsDebugFileFlashEntry()
        self.rdwrConfigurationSyncConf = self.RdwrConfigurationSyncConf()
        self.rsDebugPoliciesTuning = self.RsDebugPoliciesTuning()
        self.icmpSpec = self.IcmpSpec()
        self.rdwrDayLightSaving = self.RdwrDayLightSaving()
        self.rsIDSSLTtrackingEntry = self.RsIDSSLTtrackingEntry()
        self.rsAPMCurrentLegFarmEntry = self.RsAPMCurrentLegFarmEntry()
        self.rsIDSFPRiskAttackEntry = self.RsIDSFPRiskAttackEntry()
        self.rdwrDPOverload = self.RdwrDPOverload()
        self.rsMLBChainActionEntry = self.RsMLBChainActionEntry()
        self.rdwrConfigurationFileEntry = self.RdwrConfigurationFileEntry()
        self.rsSESSIONDisplayFilterEntry = self.RsSESSIONDisplayFilterEntry()
        self.dot3adAggPortListEntry = self.Dot3adAggPortListEntry()
        self.rsIcmpRdEntry = self.RsIcmpRdEntry()
        self.rsDnsServerStaticResEntry = self.RsDnsServerStaticResEntry()
        self.rsSESSIONFilterEntry = self.RsSESSIONFilterEntry()
        self.rsHWCoreUtilizationEntry = self.RsHWCoreUtilizationEntry()
        self.rsExportServerEntry = self.RsExportServerEntry()
        self.rsBWMCurrentChainRulesEntry = self.RsBWMCurrentChainRulesEntry()
        self.rsErrMailParams = self.RsErrMailParams()
        self.rsMaxArpEntriesTuning = self.RsMaxArpEntriesTuning()
        self.rsIDSSignaturesRuleAttackListEntry = self.RsIDSSignaturesRuleAttackListEntry()
        self.rsBWMSessionTuning = self.RsBWMSessionTuning()
        self.rsIDSSynPolicyEntry = self.RsIDSSynPolicyEntry()
        self.rsIDSQuarantineTableAction = self.RsIDSQuarantineTableAction()
        self.rsTacacsServer = self.RsTacacsServer()
        self.dot3adAggPortEntry = self.Dot3adAggPortEntry()
        self.rsServerDispatcher = self.RsServerDispatcher()
        self.rsBWMFarmsClassifyListsTuning = self.RsBWMFarmsClassifyListsTuning()
        self.rsBWMMacGroupTuning = self.RsBWMMacGroupTuning()
        self.rsBWMCurrentVLANTagGroupEntry = self.RsBWMCurrentVLANTagGroupEntry()
        self.rsBWMParallelStringSearchMemoryTuning = self.RsBWMParallelStringSearchMemoryTuning()
        self.rsCCK = self.RsCCK()
        self.rsBWMCurrentExtRulesEntry = self.RsBWMCurrentExtRulesEntry()
        self.rdwrDPTunnel = self.RdwrDPTunnel()
        self.rsCPCIDREntry = self.RsCPCIDREntry()
        self.rsIDSDosAttackEntry = self.RsIDSDosAttackEntry()
        self.rsImportExport = self.RsImportExport()
        self.rsBWMPolicyTuning = self.RsBWMPolicyTuning()
        self.rsIDSLogEntry = self.RsIDSLogEntry()
        self.rsIDSGenericSignatureParams = self.RsIDSGenericSignatureParams()
        self.rsTrafficUtilizationPerPolicyEntryOTHER = self.RsTrafficUtilizationPerPolicyEntryOTHER()
        self.rsIDSSuspendTableEntry = self.RsIDSSuspendTableEntry()
        self.rsBWMNetworkEntry = self.RsBWMNetworkEntry()
        self.dot3adAggPortStatsEntry = self.Dot3adAggPortStatsEntry()
        self.rsDEBUGPolicyEntry = self.RsDEBUGPolicyEntry()
        self.rndMonitoringEntry = self.RndMonitoringEntry()
        self.rsIDSSuspendTableParams = self.RsIDSSuspendTableParams()
        self.rsCPPeerEntry = self.RsCPPeerEntry()
        self.rsSSLCertificateDefaultValues = self.RsSSLCertificateDefaultValues()
        self.rsBWMMacGroupEntry = self.RsBWMMacGroupEntry()
        self.rsSession = self.RsSession()
        self.rsACCSMEStatisticsEntry = self.RsACCSMEStatisticsEntry()
        self.rsWSDServerStatEntry = self.RsWSDServerStatEntry()
        self.rsServiceDiscovery = self.RsServiceDiscovery()
        self.rsCPRouterConnectionEntry = self.RsCPRouterConnectionEntry()
        self.rsMLBAcceptableHTTPCodeEntry = self.RsMLBAcceptableHTTPCodeEntry()
        self.rdwrTerminalAliasEntry = self.RdwrTerminalAliasEntry()
        self.rsCCKHealthChkEntry = self.RsCCKHealthChkEntry()
        self.rsSESSIONNewSynTriggerEntry = self.RsSESSIONNewSynTriggerEntry()
        self.rsSystemFansEntry = self.RsSystemFansEntry()
        self.snmp = self.Snmp()
        self.rsMLBProximity = self.RsMLBProximity()
        self.rsIDSSignaturesRuleAttackNumberEntry = self.RsIDSSignaturesRuleAttackNumberEntry()
        self.rndBootP = self.RndBootP()
        self.rsIDSSynAttackEntry = self.RsIDSSynAttackEntry()
        self.rsWSDSysParams = self.RsWSDSysParams()
        self.rsACCStatEntry = self.RsACCStatEntry()
        self.rsBWMCurrentDSCPEntry = self.RsBWMCurrentDSCPEntry()
        self.vacmContextEntry = self.VacmContextEntry()
        self.rsIDSScanningProfilesEntry = self.RsIDSScanningProfilesEntry()
        self.rsBWMStatisticsNewEntry = self.RsBWMStatisticsNewEntry()
        self.snmpEngine = self.SnmpEngine()
        self.rsIpAddrEntry = self.RsIpAddrEntry()
        self.rsIDSServProtProfilesEntry = self.RsIDSServProtProfilesEntry()
        self.rsBWMPriorityEntry = self.RsBWMPriorityEntry()
        self.rsMLBMaxURLtoIPTableEntriesTuning = self.RsMLBMaxURLtoIPTableEntriesTuning()
        self.dpsTCPSegmentsTableTuning = self.DpsTCPSegmentsTableTuning()
        self.rsACCResourceEntry = self.RsACCResourceEntry()
        self.rsIDSPPSAttackEntry = self.RsIDSPPSAttackEntry()
        self.rdwrBgpPeerEntry = self.RdwrBgpPeerEntry()
        self.rsTrafficUtilizationPerPortEntryIGMP = self.RsTrafficUtilizationPerPortEntryIGMP()
        self.rsBWMRulesTreeManager = self.RsBWMRulesTreeManager()
        self.rdwrPortsTagEntry = self.RdwrPortsTagEntry()
        self.rsIDSLoop = self.RsIDSLoop()
        self.rndSmartFan = self.RndSmartFan()
        self.rsBWMBwmPortOperationEntry = self.RsBWMBwmPortOperationEntry()
        self.rsNetFloodBypassEntry = self.RsNetFloodBypassEntry()
        self.rsNetFloodDynamicStateFpEntry = self.RsNetFloodDynamicStateFpEntry()
        self.rsBWMFilterGroup = self.RsBWMFilterGroup()
        self.rsMLBCost = self.RsMLBCost()
        self.rsHttpFloodLearnedStatEntry = self.RsHttpFloodLearnedStatEntry()
        self.rsSESSIONTableSynFloodTriggersTuning = self.RsSESSIONTableSynFloodTriggersTuning()
        self.rsIDSHwPoliciesTableEntry = self.RsIDSHwPoliciesTableEntry()
        self.rsImportBaselineHttpEntry = self.RsImportBaselineHttpEntry()
        self.rsIDSConnectionLimitProfileEntry = self.RsIDSConnectionLimitProfileEntry()
        self.rsBWMStatisticsEntry = self.RsBWMStatisticsEntry()
        self.rdwrCdbParameters = self.RdwrCdbParameters()
        self.rsImportBaselineDnsEntry = self.RsImportBaselineDnsEntry()
        self.rsWSDNTP = self.RsWSDNTP()
        self.rsDnsrParameters = self.RsDnsrParameters()
        self.rsIDSOutOfPathFootPrintEvent = self.RsIDSOutOfPathFootPrintEvent()
        self.rsSignalingReportHttpEntry = self.RsSignalingReportHttpEntry()
        self.rsIDSUserAttacksDBEntriesTuning = self.RsIDSUserAttacksDBEntriesTuning()
        self.rsNetFloodProfileEntry = self.RsNetFloodProfileEntry()
        self.rsMaxZeroHopRoutEntriesTuning = self.RsMaxZeroHopRoutEntriesTuning()
        self.rsMLBVIPReservedPortsEntry = self.RsMLBVIPReservedPortsEntry()
        self.rsMLBLogicalIDSServerEntry = self.RsMLBLogicalIDSServerEntry()
        self.rsImportServerEntry = self.RsImportServerEntry()
        self.vacmAccessEntry = self.VacmAccessEntry()
        self.rsIDStrackingEntry = self.RsIDStrackingEntry()
        self.rdwrVrrp = self.RdwrVrrp()
        self.rsIDSRulesEntry = self.RsIDSRulesEntry()
        self.rsBWMVLANTagGroupEntry = self.RsBWMVLANTagGroupEntry()
        self.rsIpRipFilterLclEntry = self.RsIpRipFilterLclEntry()
        self.rsBWMFilterPolicyEntry = self.RsBWMFilterPolicyEntry()
        self.rsTrafficUtilizationPerPolicyEntryIGMP = self.RsTrafficUtilizationPerPolicyEntryIGMP()
        self.vrrpOperEntry = self.VrrpOperEntry()
        self.rsBWMCurrentFilterGroup = self.RsBWMCurrentFilterGroup()
        self.rsMLBChainEntry = self.RsMLBChainEntry()
        self.rsMLBMappedIPEntry = self.RsMLBMappedIPEntry()
        self.arpSpec = self.ArpSpec()
        self.rsMLBClientEntry = self.RsMLBClientEntry()
        self.rsSESSIONSynProtectionStatisticsEntry = self.RsSESSIONSynProtectionStatisticsEntry()
        self.rdwrClientsTypeEntry = self.RdwrClientsTypeEntry()
        self.rsNetFloodBypassTcpFragEntry = self.RsNetFloodBypassTcpFragEntry()
        self.rsBWMCurrentFilterPolicyEntry = self.RsBWMCurrentFilterPolicyEntry()
        self.rsIDSMemoryQuarantineTuning = self.RsIDSMemoryQuarantineTuning()
        self.rsSignalingNwSrcGroupEntry = self.RsSignalingNwSrcGroupEntry()
        self.rndFACSActEntry = self.RndFACSActEntry()
        self.rsDnsProt = self.RsDnsProt()
        self.rdwrDPPassiveSSLTcpPortEntry = self.RdwrDPPassiveSSLTcpPortEntry()
        self.ip6NetToMediaEntry = self.Ip6NetToMediaEntry()
        self.rsMLBMaxStaticNatEntriesTuning = self.RsMLBMaxStaticNatEntriesTuning()
        self.rsPortStatsEntry = self.RsPortStatsEntry()
        self.rsCPPeriodStartTimeEntry = self.RsCPPeriodStartTimeEntry()
        self.rsHttpFlood = self.RsHttpFlood()
        self.rsSignalingPolicyEntry = self.RsSignalingPolicyEntry()
        self.interfaces = self.Interfaces()
        self.rsCPTerminalHostnameEntry = self.RsCPTerminalHostnameEntry()
        self.rdwrSnmpErrorTbEntry = self.RdwrSnmpErrorTbEntry()
        self.rsAPMGlobalParameters = self.RsAPMGlobalParameters()
        self.rsAPMAlertVariables = self.RsAPMAlertVariables()
        self.lreVnResposibilityEntry = self.LreVnResposibilityEntry()
        self.rsBWMRulesEntry = self.RsBWMRulesEntry()
        self.rsDnsrStaticResEntry = self.RsDnsrStaticResEntry()
        self.rndMng = self.RndMng()
        self.rsIDSSignaturesAttributeAttackListEntry = self.RsIDSSignaturesAttributeAttackListEntry()
        self.snmpTargetAddrExtEntry = self.SnmpTargetAddrExtEntry()
        self.rsWSDPingPortsEntry = self.RsWSDPingPortsEntry()
        self.rsIDSFilterEntry = self.RsIDSFilterEntry()
        self.rsIDSSignaturesProfileParamsEntry = self.RsIDSSignaturesProfileParamsEntry()
        self.rsBWMCurrentAppPortGroupEntry = self.RsBWMCurrentAppPortGroupEntry()
        self.rsTrafficUtilizationPerPortEntrySCTP = self.RsTrafficUtilizationPerPortEntrySCTP()
        self.rsSESSIONSynProtectionTuning = self.RsSESSIONSynProtectionTuning()
        self.rsScheduleEntry = self.RsScheduleEntry()
        self.rsMLBRemoteConnectivityEntry = self.RsMLBRemoteConnectivityEntry()
        self.rsBWMGroupTuning = self.RsBWMGroupTuning()
        self.virtualLan = self.VirtualLan()
        self.rsIDSFPRisk = self.RsIDSFPRisk()
        self.rsMLBStaticNatEntry = self.RsMLBStaticNatEntry()
        self.rsAPMPolicyEntry = self.RsAPMPolicyEntry()
        self.rsSignalingReportBdosEntry = self.RsSignalingReportBdosEntry()
        self.rsMaxIpxSapEntriesTuning = self.RsMaxIpxSapEntriesTuning()
        self.rsIDSMPLSRDTableEntry = self.RsIDSMPLSRDTableEntry()
        self.rsAPMMonitorEntry = self.RsAPMMonitorEntry()
        self.rsBWMPolicyEntry = self.RsBWMPolicyEntry()
        self.rndIfEntry = self.RndIfEntry()
        self.rsMLBDailyStatisticsEntry = self.RsMLBDailyStatisticsEntry()
        self.dot3adAggEntry = self.Dot3adAggEntry()
        self.rsIDSFootprintEvent = self.RsIDSFootprintEvent()
        self.rsSmeEngineUtilizationEntry = self.RsSmeEngineUtilizationEntry()
        self.rspRadiusRuleEntry = self.RspRadiusRuleEntry()
        self.rsIDSNetfloodWarningEvent = self.RsIDSNetfloodWarningEvent()
        self.rsIDSSignaturesAttributeTypesEntry = self.RsIDSSignaturesAttributeTypesEntry()
        self.rsMLBSubnetGroupEntry = self.RsMLBSubnetGroupEntry()
        self.rdwrMasterInterfaceGroupingPortsEntry = self.RdwrMasterInterfaceGroupingPortsEntry()
        self.reaBridgeFftEntry = self.ReaBridgeFftEntry()
        self.rdwrLastConfigurationChangesEntry = self.RdwrLastConfigurationChangesEntry()
        self.rsBWMTrafficFlowBWTuning = self.RsBWMTrafficFlowBWTuning()
        self.rsMaxRoutingEntriesTuning = self.RsMaxRoutingEntriesTuning()
        self.rsWSDSshParams = self.RsWSDSshParams()
        self.rsSESSIONSynActivationEntry = self.RsSESSIONSynActivationEntry()
        self.rsSignalingServerSrcGroupEntry = self.RsSignalingServerSrcGroupEntry()
        self.rsVWSDDataPermissionsTableEntry = self.RsVWSDDataPermissionsTableEntry()
        self.rsBWMExtRulesEntry = self.RsBWMExtRulesEntry()
        self.rsWhiteListEntry = self.RsWhiteListEntry()
        self.rsStatisticsProtocolReportTuning = self.RsStatisticsProtocolReportTuning()
        self.rsIDSynSSLMitigationEntry = self.RsIDSynSSLMitigationEntry()
        self.vnsPacketEntry = self.VnsPacketEntry()
        self.rsSignalingReportDnsEntry = self.RsSignalingReportDnsEntry()
        self.rdwrDPTunnelEntry = self.RdwrDPTunnelEntry()
        self.rsStatisticsDiscoveryProtocolEntry = self.RsStatisticsDiscoveryProtocolEntry()
        self.rndIpHost = self.RndIpHost()
        self.rsMLBRemoteVIPEntry = self.RsMLBRemoteVIPEntry()
        self.rsIdsDeployment = self.RsIdsDeployment()
        self.rsMLBLocalStationEntry = self.RsMLBLocalStationEntry()
        self.rsBWMDynamicNetworkTuning = self.RsBWMDynamicNetworkTuning()
        self.rsIDSConnectionLimitPolicyEntry = self.RsIDSConnectionLimitPolicyEntry()
        self.rsIDSCountersReportInfoTuning = self.RsIDSCountersReportInfoTuning()
        self.rsAPMLegFarmEntry = self.RsAPMLegFarmEntry()
        self.ifEntry = self.IfEntry()
        self.rsTrafficUtilizationPerPolicyEntryUDP = self.RsTrafficUtilizationPerPolicyEntryUDP()
        self.rsDebugFileEntry = self.RsDebugFileEntry()
        self.rsExcludeIpEntry = self.RsExcludeIpEntry()
        self.snmpTargetParamsEntry = self.SnmpTargetParamsEntry()
        self.rsStatisticsProtocolPolicyTuning = self.RsStatisticsProtocolPolicyTuning()
        self.rsBWMFilterTuning = self.RsBWMFilterTuning()
        self.rsIDSSynProtection = self.RsIDSSynProtection()
        self.rndVisionDriver = self.RndVisionDriver()
        self.rsBWMPPCInboundPortOnlyEntry = self.RsBWMPPCInboundPortOnlyEntry()
        self.rsIDSNonTuneableMemory = self.RsIDSNonTuneableMemory()
        self.rsTrafficUtilizationPerPortEntryUDP = self.RsTrafficUtilizationPerPortEntryUDP()
        self.rsWSDThresholdWarnings = self.RsWSDThresholdWarnings()
        self.rsCPPeerPhysicalInterfaceEntry = self.RsCPPeerPhysicalInterfaceEntry()
        self.rdwrFtpParameters = self.RdwrFtpParameters()
        self.rndBridgeAlarm = self.RndBridgeAlarm()
        self.rdwrDualPowerSupplyParams = self.RdwrDualPowerSupplyParams()
        self.rsTrafficUtilizationPerPortEntryICMP = self.RsTrafficUtilizationPerPortEntryICMP()
        self.rsMLBRemoteNatEntriesTuning = self.RsMLBRemoteNatEntriesTuning()
        self.rsIDSLoopConfigurationTableEntry = self.RsIDSLoopConfigurationTableEntry()
        self.rsHWCPUTemperatureEntry = self.RsHWCPUTemperatureEntry()
        self.rndFACSEntry = self.RndFACSEntry()
        self.rsIDSStaticGroupEntry = self.RsIDSStaticGroupEntry()
        self.rsBWMDynamicNetworkIPTuning = self.RsBWMDynamicNetworkIPTuning()
        self.rsIDSSignaturesAttackAttributesEntry = self.RsIDSSignaturesAttackAttributesEntry()
        self.rsCP = self.RsCP()
        self.rsHTTPFServerEntry = self.RsHTTPFServerEntry()
        self.rsMLBRemoteServiceEntry = self.RsMLBRemoteServiceEntry()
        self.snmpSet = self.SnmpSet()
        self.rsTrafficUtilizationPerPortEntryTCP = self.RsTrafficUtilizationPerPortEntryTCP()
        self.rsIDSIntrusionEvent = self.RsIDSIntrusionEvent()
        self.rsWSDPrivateCheckEntry = self.RsWSDPrivateCheckEntry()
        self.vrrpOperations = self.VrrpOperations()
        self.rsGeneric = self.RsGeneric()
        self.eventMessageEntry = self.EventMessageEntry()
        self.rsHttpFloodUriBypassEntry = self.RsHttpFloodUriBypassEntry()
        self.rsBWMAppPortGroupTuning = self.RsBWMAppPortGroupTuning()
        self.rdwrTerminalParams = self.RdwrTerminalParams()
        self.rsMaxIpForwardingEntriesTuning = self.RsMaxIpForwardingEntriesTuning()
        self.rsMaxRadiusEntriesTuning = self.RsMaxRadiusEntriesTuning()
        self.rsBWMExtPolicyEntry = self.RsBWMExtPolicyEntry()
        self.wsdRedundEntry = self.WsdRedundEntry()
        self.rsTrafficUtilizationPerPolicyEntryICMP = self.RsTrafficUtilizationPerPolicyEntryICMP()
        self.rsMLBStaticProximityEntry = self.RsMLBStaticProximityEntry()
        self.rsMLBDNSIPAddressEntry = self.RsMLBDNSIPAddressEntry()
        self.rsIDSSLTNewRulesEntry = self.RsIDSSLTNewRulesEntry()
        self.rsIDSPPSProfileEntry = self.RsIDSPPSProfileEntry()
        self.rsBlackList = self.RsBlackList()
        self.rsBlackListEntry = self.RsBlackListEntry()
        self.ipSpecRouteEntry = self.IpSpecRouteEntry()
        self.rsPacketReportData = self.RsPacketReportData()
        self.system = self.System()
        self.rsCPPriceEntry = self.RsCPPriceEntry()
        self.rsHttpFloodUriBinDistEntry = self.RsHttpFloodUriBinDistEntry()
        self.rsMLBAgingTimeEntry = self.RsMLBAgingTimeEntry()
        self.rsBWMNetworkIPTuning = self.RsBWMNetworkIPTuning()
        self.rsSESSIONSynProtectionTriggerTuning = self.RsSESSIONSynProtectionTriggerTuning()
        self.rsIDSIpFragments = self.RsIDSIpFragments()
        self.rsACC = self.RsACC()
        self.rsBWMCurrentPhysicalPortGroupEntry = self.RsBWMCurrentPhysicalPortGroupEntry()
        self.rsSESSIONSessionTableEntry = self.RsSESSIONSessionTableEntry()
        self.rsCCKDiameterArgsEntry = self.RsCCKDiameterArgsEntry()
        self.rdwrIkeEntry = self.RdwrIkeEntry()
        self.rsTrafficUtilizationPerPolicyEntryTCP = self.RsTrafficUtilizationPerPolicyEntryTCP()
        self.rsMLBServiceLinkBindEntry = self.RsMLBServiceLinkBindEntry()
        self.rsStpInstanceEntry = self.RsStpInstanceEntry()
        self.rsHTTPFReportsContinuousLearningStatisticsEntry = self.RsHTTPFReportsContinuousLearningStatisticsEntry()
        self.rsIDSScanning = self.RsIDSScanning()
        self.rsNewWhiteListEntryTwo = self.RsNewWhiteListEntryTwo()
        self.rdwrDPHighAvailability = self.RdwrDPHighAvailability()
        self.rsSESSIONSynProtectionPolicyTuning = self.RsSESSIONSynProtectionPolicyTuning()
        self.rsIpFragmentTuning = self.RsIpFragmentTuning()
        self.rsIDSPacketTrace = self.RsIDSPacketTrace()
        self.rsIDSServAttackEntry = self.RsIDSServAttackEntry()
        self.rsTrafficUtilization = self.RsTrafficUtilization()
        self.rsStatefulProtocolAgingEntry = self.RsStatefulProtocolAgingEntry()
        self.rsSESSIONAckReflectionTableTuning = self.RsSESSIONAckReflectionTableTuning()
        self.rsUpdatePolicies = self.RsUpdatePolicies()
        self.rsDnsProtDynamicStateFpEntry = self.RsDnsProtDynamicStateFpEntry()
        self.rsSESSIONTableEntry = self.RsSESSIONTableEntry()
        self.rsStatisticsProbePostVariablesEntry = self.RsStatisticsProbePostVariablesEntry()
        self.rsBWMChainRulesEntry = self.RsBWMChainRulesEntry()
        self.rsIDSNCPNFTableSizeTuning = self.RsIDSNCPNFTableSizeTuning()
        self.rsLinkAggregationHash = self.RsLinkAggregationHash()
        self.rsMLBPrxyStatisticsEntry = self.RsMLBPrxyStatisticsEntry()
        self.rsFSapplEntry = self.RsFSapplEntry()
        self.usmUser = self.UsmUser()
        self.rsIDSLoopConfigurationDeviceTableEntry = self.RsIDSLoopConfigurationDeviceTableEntry()
        self.rsIDSGroupCategoryEntry = self.RsIDSGroupCategoryEntry()
        self.rsCCKElementEntry = self.RsCCKElementEntry()
        self.rsNetFloodPolicyEntry = self.RsNetFloodPolicyEntry()
        self.rdwrBgpPeerDestRouteEntry = self.RdwrBgpPeerDestRouteEntry()
        self.rsMaxDspFrmEntriesTuning = self.RsMaxDspFrmEntriesTuning()
        self.rsIpZhrVirtAddressEntry = self.RsIpZhrVirtAddressEntry()
        self.rsNetFloodDynamicStateTwoEntry = self.RsNetFloodDynamicStateTwoEntry()
        self.rsIpZhrConnectionEntry = self.RsIpZhrConnectionEntry()
        self.rsIDSNewRulesEntry = self.RsIDSNewRulesEntry()
        self.rsTunning = self.RsTunning()
        self.rsIDSImmediateChecks = self.RsIDSImmediateChecks()
        self.rsBWMDynamicNetworkRangeTuning = self.RsBWMDynamicNetworkRangeTuning()
        self.rsDebugTraceApplEntry = self.RsDebugTraceApplEntry()
        self.rsAntiFraud = self.RsAntiFraud()
        self.rsIDSIpFragmentsTuning = self.RsIDSIpFragmentsTuning()
        self.rsNewWhiteListEntry = self.RsNewWhiteListEntry()
        self.rsSigReportTotalTrafficEntry = self.RsSigReportTotalTrafficEntry()
        self.rdwrRedundancyInfoEntry = self.RdwrRedundancyInfoEntry()
        self.genGroup = self.GenGroup()
        self.rsSSDvirtualLanEntry = self.RsSSDvirtualLanEntry()
        self.rsIfConfEntry = self.RsIfConfEntry()
        self.rsMLBRulesEntry = self.RsMLBRulesEntry()
        self.rsIDSNewSuspendTableEntry = self.RsIDSNewSuspendTableEntry()
        self.rsSSLCertificateEntry = self.RsSSLCertificateEntry()
        self.rsMLBDNSRegexpURLtoIPEntry = self.RsMLBDNSRegexpURLtoIPEntry()
        self.rsREACCReasonCounters = self.RsREACCReasonCounters()
        self.rsIDSNetworkPolicyEvent = self.RsIDSNetworkPolicyEvent()
        self.ipSpec = self.IpSpec()
        self.rsRip2IfConfEntry = self.RsRip2IfConfEntry()
        self.rsIDSServiceEntry = self.RsIDSServiceEntry()
        self.rsIDSWebQuarantineEntry = self.RsIDSWebQuarantineEntry()
        self.rsAPM = self.RsAPM()
        self.virtualLanAutoConfEntry = self.VirtualLanAutoConfEntry()
        self.rsIDSSignaturesProfileAttackNumberEntry = self.RsIDSSignaturesProfileAttackNumberEntry()
        self.rsMLBDNSVirtualEntry = self.RsMLBDNSVirtualEntry()
        self.rsMLBMaxBasicNatEntriesTuning = self.RsMLBMaxBasicNatEntriesTuning()
        self.rsIpZhrStatusEntry = self.RsIpZhrStatusEntry()
        self.rsCCKChkMethodEntry = self.RsCCKChkMethodEntry()
        self.rsIpRipFilterGlbEntry = self.RsIpRipFilterGlbEntry()
        self.rdwrClientsTableStatistics = self.RdwrClientsTableStatistics()
        self.rsBWMPolicyGroupEntry = self.RsBWMPolicyGroupEntry()
        self.rsCPPasswordPromptEntry = self.RsCPPasswordPromptEntry()
        self.rndMonitoredElementEntry = self.RndMonitoredElementEntry()
        self.rsSESSIONSynProtectionPolicyEntry = self.RsSESSIONSynProtectionPolicyEntry()
        self.rsIDSSourceTableParams = self.RsIDSSourceTableParams()
        self.rsIDSUserGroupsNumberTuning = self.RsIDSUserGroupsNumberTuning()
        self.rsTrafficUtilizationPerPolicyEntrySCTP = self.RsTrafficUtilizationPerPolicyEntrySCTP()
        self.rsWSDTelnetUserEntry = self.RsWSDTelnetUserEntry()
        self.rsCPLegalStringEntry = self.RsCPLegalStringEntry()
        self.rsImportBaselineBdosEntry = self.RsImportBaselineBdosEntry()
        self.rsMLBMaxNoNatEntriesTuning = self.RsMLBMaxNoNatEntriesTuning()
        self.rsIDSSignaturesAttributesEntry = self.RsIDSSignaturesAttributesEntry()
        self.snmpCommunityEntry = self.SnmpCommunityEntry()
        self.snmpNotifyEntry = self.SnmpNotifyEntry()
        self.rsBWMACL = self.RsBWMACL()
        self.rsWSDSCProtcolsEntry = self.RsWSDSCProtcolsEntry()
        self.rdwrRip2IfConfEntry = self.RdwrRip2IfConfEntry()
        self.rsIDSConnectionLimitAttackEntry = self.RsIDSConnectionLimitAttackEntry()
        self.ifXEntry = self.IfXEntry()
        self.rsBWMCurrentFarmRulesEntry = self.RsBWMCurrentFarmRulesEntry()
        self.rsSignaling = self.RsSignaling()
        self.rsMLBLocalServiceEntry = self.RsMLBLocalServiceEntry()
        self.rsCCKDiameterBinaryFileEntry = self.RsCCKDiameterBinaryFileEntry()
        self.rsPhysPortMirrorEntry = self.RsPhysPortMirrorEntry()
        self.rsStatisticsProtocolEntry = self.RsStatisticsProtocolEntry()
        self.rsRadiusServer = self.RsRadiusServer()
        self.usmStats = self.UsmStats()
        self.rdwrDPRoutingIpForwardingEntry = self.RdwrDPRoutingIpForwardingEntry()
        self.rsIDSImmediateChecksAttackEntry = self.RsIDSImmediateChecksAttackEntry()
        self.rsCCKChkBindingEntry = self.RsCCKChkBindingEntry()
        self.rsAPMMonitorDataItemEntry = self.RsAPMMonitorDataItemEntry()
        self.rsBWMFilterEntry = self.RsBWMFilterEntry()
        self.rsServiceDiscoveryProfileEntry = self.RsServiceDiscoveryProfileEntry()
        self.rsMLBProximityTuning = self.RsMLBProximityTuning()
        self.vacmViewTreeFamilyEntry = self.VacmViewTreeFamilyEntry()
        self.ipForward = self.IpForward()
        self.rsBWMMacGroupCurrentEntry = self.RsBWMMacGroupCurrentEntry()
        self.rsDOS = self.RsDOS()
        self.rsMLBTunnelEntry = self.RsMLBTunnelEntry()
        self.rsMLBApplicationServerEntry = self.RsMLBApplicationServerEntry()
        self.rsIDSSignaturesAttributeAttackNumberEntry = self.RsIDSSignaturesAttributeAttackNumberEntry()
        self.rsIDSAdvancedFilterEntry = self.RsIDSAdvancedFilterEntry()
        self.rsSESSIONSynProtectionStatsTuning = self.RsSESSIONSynProtectionStatsTuning()
        self.rsBWMDSCPEntry = self.RsBWMDSCPEntry()
        self.rsBWMAdvancedTuning = self.RsBWMAdvancedTuning()
        self.rsMLBURLtoIPEntry = self.RsMLBURLtoIPEntry()
        self.reaIpFftEntry = self.ReaIpFftEntry()
        self.rsBWMPortBandwidthEntry = self.RsBWMPortBandwidthEntry()
        self.rsIDSScanningTrustedPorts = self.RsIDSScanningTrustedPorts()
        self.rsMLBMaxFragmentTableEntriesTuning = self.RsMLBMaxFragmentTableEntriesTuning()
        self.rsImportPolicyEntry = self.RsImportPolicyEntry()
        self.ifMIBObjects = self.IfMIBObjects()
        self.ipIfEntry = self.IpIfEntry()
        self.rsTrafficUtilizationPerPortEntryOTHER = self.RsTrafficUtilizationPerPortEntryOTHER()
        self.rsBWMACLModifyPolicyEntry = self.RsBWMACLModifyPolicyEntry()
        self.rsDnsServerParameters = self.RsDnsServerParameters()
        self.ipRouteLeaking = self.IpRouteLeaking()
        self.rsDnsProtBypassEntry = self.RsDnsProtBypassEntry()
        self.rsMLBRemoteLinkEntry = self.RsMLBRemoteLinkEntry()
        self.reaTunning = self.ReaTunning()
        self.rsBWMCurrentFilterEntry = self.RsBWMCurrentFilterEntry()
        self.rsMLBFarmEntry = self.RsMLBFarmEntry()
        self.rsHTTPFProfileEntry = self.RsHTTPFProfileEntry()
        self.rsREStateMonitoring = self.RsREStateMonitoring()
        self.snmpNotifyFilterProfileEntry = self.SnmpNotifyFilterProfileEntry()
        self.rsAPMAlertSpecEntry = self.RsAPMAlertSpecEntry()
        self.dpsRTSPControlTableTuning = self.DpsRTSPControlTableTuning()
        self.rsMLBBasicNatEntry = self.RsMLBBasicNatEntry()
        self.rsBWMCurrentNetworkEntry = self.RsBWMCurrentNetworkEntry()
        self.rsIpFragment = self.RsIpFragment()
        self.rsOverloadThresholdsEntry = self.RsOverloadThresholdsEntry()
        self.rsCCKPktSequenceEntry = self.RsCCKPktSequenceEntry()
        self.rdwrClientsEntry = self.RdwrClientsEntry()
        self.rsStatefulReportThresholdEntry = self.RsStatefulReportThresholdEntry()
        self.rndMidLevelManagement = self.RndMidLevelManagement()
        self.rsBWMNetworkRangeTuning = self.RsBWMNetworkRangeTuning()
        self.rsBWMDestinationTuning = self.RsBWMDestinationTuning()
        self.rsSESSIONPasvProtocolsTuning = self.RsSESSIONPasvProtocolsTuning()
        self.virtualLanEntry = self.VirtualLanEntry()
        self.rsSESSIONSessionTuning = self.RsSESSIONSessionTuning()
        self.rsDeleteServerEntry = self.RsDeleteServerEntry()
        self.rsBWMServiceEntry = self.RsBWMServiceEntry()
        self.vrrpStatistics = self.VrrpStatistics()
        self.rsBWMChainTuning = self.RsBWMChainTuning()
        self.rsNetFloodQuotaEntry = self.RsNetFloodQuotaEntry()
        self.rndAlarmOptions = self.RndAlarmOptions()
        self.rsMLBVirtualIPEntry = self.RsMLBVirtualIPEntry()
        self.rsBWMNetworkTuning = self.RsBWMNetworkTuning()
        self.rsSignalingTotalUtilEntry = self.RsSignalingTotalUtilEntry()
        self.rsIDSMPLSRDParams = self.RsIDSMPLSRDParams()
        self.rdwrBgp = self.RdwrBgp()

    class RdwrClientsViewEntry:
        def __init__(self):
            self.srcAddrFrom = 'srcAddrFrom'
            self.srcAddrTo = 'srcAddrTo'
            self.dstAddrFrom = 'dstAddrFrom'
            self.dstAddrTo = 'dstAddrTo'
            self.srcPortFrom = 'srcPortFrom'
            self.srcPortTo = 'srcPortTo'
            self.dstPortFrom = 'dstPortFrom'
            self.dstPortTo = 'dstPortTo'
            self.farmAddr = 'farmAddr'
            self.serverAddr = 'serverAddr'
            self.clientType = 'clientType'
            self.adminStatus = 'adminStatus'
            self.status = 'status'
            self.action = 'action'
            self.actionFeedback = 'actionFeedback'
            self.vlanTag = 'vlanTag'
            self.farmName = 'farmName'
            self.index = 'index'

        def __call__(self):
            return 'RdwrClientsViewEntry'

    class RsIDSNewRulesEntryOne:
        def __init__(self):
            self.iDSServiceNameOne = 'iDSServiceNameOne'
            self.sourceOne = 'sourceOne'
            self.destinationOne = 'destinationOne'
            self.directionOne = 'directionOne'
            self.portmaskOne = 'portmaskOne'
            self.vlanTagGroupOne = 'vlanTagGroupOne'
            self.mPLSRDGroupOne = 'mPLSRDGroupOne'
            self.statusOne = 'statusOne'
            self.nameOne = 'nameOne'

        def __call__(self):
            return 'RsIDSNewRulesEntryOne'

    class RsStatefulPolicyEntry:
        def __init__(self):
            self.sTATFULPolicyProfileName = 'sTATFULPolicyProfileName'
            self.sTATFULPolicySourceNet = 'sTATFULPolicySourceNet'
            self.sTATFULPolicyDestinationNet = 'sTATFULPolicyDestinationNet'
            self.sTATFULPolicyPhysicalPortGroup = 'sTATFULPolicyPhysicalPortGroup'
            self.sTATFULPolicyVlanTagGroup = 'sTATFULPolicyVlanTagGroup'
            self.sTATFULPolicyOperationalStatus = 'sTATFULPolicyOperationalStatus'
            self.sTATFULPolicyStatus = 'sTATFULPolicyStatus'
            self.sTATFULPolicyAction = 'sTATFULPolicyAction'
            self.sTATFULPolicyPacketReport = 'sTATFULPolicyPacketReport'
            self.sTATFULPolicyName = 'sTATFULPolicyName'

        def __call__(self):
            return 'RsStatefulPolicyEntry'

    class RsNetFloodBypassIgmpEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassIgmpEntry'

    class RsIDSNewRulesEntryThree:
        def __init__(self):
            self.profileAppsecThree = 'profileAppsecThree'
            self.profileConlmtThree = 'profileConlmtThree'
            self.profileStatefulThree = 'profileStatefulThree'
            self.profileScanningThree = 'profileScanningThree'
            self.profileNetfloodThree = 'profileNetfloodThree'
            self.profileSynprotectionThree = 'profileSynprotectionThree'
            self.profileServprotectionThree = 'profileServprotectionThree'
            self.profilePPSThree = 'profilePPSThree'
            self.profileDNSThree = 'profileDNSThree'
            self.iDSQuarantineStatusInPolicyThree = 'iDSQuarantineStatusInPolicyThree'
            self.profileServiceDiscoveryThree = 'profileServiceDiscoveryThree'
            self.statusThree = 'statusThree'
            self.nameThree = 'nameThree'

        def __call__(self):
            return 'RsIDSNewRulesEntryThree'

    class RsMLBDNS:
        def __init__(self):
            self.rsMLBDNSttl = 'rsMLBDNSttl'
            self.rsMLBDNSTwoAnswers = 'rsMLBDNSTwoAnswers'
            self.rsMLBDNSURLToIPSearchMode = 'rsMLBDNSURLToIPSearchMode'
            self.rsMLBDNSLocation = 'rsMLBDNSLocation'
            self.rsMLBDNSNatResponseMode = 'rsMLBDNSNatResponseMode'

        def __call__(self):
            return 'RsMLBDNS'

    class RsWhiteList:
        def __init__(self):
            self.rsNewWhiteListDummyVal = 'rsNewWhiteListDummyVal'

        def __call__(self):
            return 'RsWhiteList'

    class RdwrDPPacketReport:
        def __init__(self):
            self.rdwrDPPacketReportAddr = 'rdwrDPPacketReportAddr'
            self.rdwrDPPacketReportDestPort = 'rdwrDPPacketReportDestPort'
            self.rdwrDPPacketReportStatus = 'rdwrDPPacketReportStatus'

        def __call__(self):
            return 'RdwrDPPacketReport'

    class VacmSecurityToGroupEntry:
        def __init__(self):
            self.groupName = 'groupName'
            self.storageType = 'storageType'
            self.status = 'status'
            self.model = 'model'
            self.name = 'name'

        def __call__(self):
            return 'VacmSecurityToGroupEntry'

    class RdwrVersionIdentifierEntry:
        def __init__(self):
            self.base = 'base'
            self.val = 'val'
            self.idx = 'idx'

        def __call__(self):
            return 'RdwrVersionIdentifierEntry'

    class RsIDSScanningPolicyEntry:
        def __init__(self):
            self.serviceName = 'serviceName'
            self.internal = 'internal'
            self.external = 'external'
            self.portmask = 'portmask'
            self.state = 'state'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.direction = 'direction'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSScanningPolicyEntry'

    class RsMLBRemoteNatGlobalCnfg:
        def __init__(self):
            self.rsMLBTrpPort = 'rsMLBTrpPort'
            self.rsMLBTrpRegularInterval = 'rsMLBTrpRegularInterval'
            self.rsMLBTrpCompleteInterval = 'rsMLBTrpCompleteInterval'
            self.rsMLBTrpRetries = 'rsMLBTrpRetries'
            self.rsMLBTunnelCheckInterval = 'rsMLBTunnelCheckInterval'
            self.rsMLBTunnelWeight = 'rsMLBTunnelWeight'
            self.rsMLBLocalLinkWeight = 'rsMLBLocalLinkWeight'
            self.rsMLBRemoteLinkWeight = 'rsMLBRemoteLinkWeight'
            self.rsMLBTunnelChecksRetries = 'rsMLBTunnelChecksRetries'
            self.rsMLBTunnelChecksTimeout = 'rsMLBTunnelChecksTimeout'

        def __call__(self):
            return 'RsMLBRemoteNatGlobalCnfg'

    class RsIDSMemoryReservedTuning:
        def __init__(self):
            self.rsIDSDynamicMemoryAfterReset = 'rsIDSDynamicMemoryAfterReset'
            self.rsIDSDynamicMemory = 'rsIDSDynamicMemory'

        def __call__(self):
            return 'RsIDSMemoryReservedTuning'

    class RsFileSystem:
        def __init__(self):
            self.rsFSinstallNew = 'rsFSinstallNew'

        def __call__(self):
            return 'RsFileSystem'

    class RsSmtpParameters:
        def __init__(self):
            self.rsSmtpPrimaryAddr = 'rsSmtpPrimaryAddr'
            self.rsSmtpAlternateAddr = 'rsSmtpAlternateAddr'
            self.rsSmtpEnable = 'rsSmtpEnable'
            self.rsSmtpOwnAddr = 'rsSmtpOwnAddr'
            self.rsSmtpBackupOwnAddr = 'rsSmtpBackupOwnAddr'

        def __call__(self):
            return 'RsSmtpParameters'

    class RsBWMFarmRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.status = 'status'
            self.direction = 'direction'
            self.description = 'description'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.operationalStatus = 'operationalStatus'
            self.specific = 'specific'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.dSCPMarking = 'dSCPMarking'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMFarmRulesEntry'

    class RsWSDHttpsParams:
        def __init__(self):
            self.rsWSDHttpsPort = 'rsWSDHttpsPort'
            self.rsWSDHttpsStatus = 'rsWSDHttpsStatus'

        def __call__(self):
            return 'RsWSDHttpsParams'

    class RsIDSNetforensics:
        def __init__(self):
            self.rsIDSNetforensicsAgentAddress = 'rsIDSNetforensicsAgentAddress'
            self.rsIDSNetforensicsAgentPort = 'rsIDSNetforensicsAgentPort'
            self.rsIDSNetforensicsAgentStatus = 'rsIDSNetforensicsAgentStatus'

        def __call__(self):
            return 'RsIDSNetforensics'

    class RsREStateCounters:
        def __init__(self):
            self.rsREStateRXReplyCounter = 'rsREStateRXReplyCounter'
            self.rsREStateRXRequestCounter = 'rsREStateRXRequestCounter'
            self.rsREStateIPDAinFFTCounter = 'rsREStateIPDAinFFTCounter'
            self.rsREStateIPDAnotFFTCounter = 'rsREStateIPDAnotFFTCounter'
            self.rsREStateBridgeCounter = 'rsREStateBridgeCounter'

        def __call__(self):
            return 'RsREStateCounters'

    class RsWSDIfEntry:
        def __init__(self):
            self.boardNum = 'boardNum'
            self.netAddress = 'netAddress'
            self.status = 'status'
            self.clockType = 'clockType'
            self.baudRate = 'baudRate'
            self.cost = 'cost'
            self.compression = 'compression'
            self.compressionStatus = 'compressionStatus'
            self.compressionRate = 'compressionRate'
            self.lATCompression = 'lATCompression'
            self.compressionType = 'compressionType'
            self.filterMode = 'filterMode'
            self.channelType = 'channelType'
            self.bridge = 'bridge'
            self.wSDHighPriorityIf = 'wSDHighPriorityIf'
            self.wSDWanHeader = 'wSDWanHeader'
            self.wSDDuplexMode = 'wSDDuplexMode'
            self.index = 'index'

        def __call__(self):
            return 'RsWSDIfEntry'

    class DpsPendingTableTuning:
        def __init__(self):
            self.dpsPendingTableEntries = 'dpsPendingTableEntries'
            self.dpsPendingTableEntriesAfterReset = 'dpsPendingTableEntriesAfterReset'

        def __call__(self):
            return 'DpsPendingTableTuning'

    class RdwrMirroring:
        def __init__(self):
            self.rdwrMirroringActiveThreshold = 'rdwrMirroringActiveThreshold'
            self.rdwrMirroringActiveSleep = 'rdwrMirroringActiveSleep'
            self.rdwrMirroringActiveBackupThreshold = 'rdwrMirroringActiveBackupThreshold'
            self.rdwrMirroringActiveBackupSleep = 'rdwrMirroringActiveBackupSleep'
            self.rdwrMirroringActiveBackupHoldtime = 'rdwrMirroringActiveBackupHoldtime'
            self.rdwrMirroringActiveBackupUpdate = 'rdwrMirroringActiveBackupUpdate'

        def __call__(self):
            return 'RdwrMirroring'

    class RsSESSIONL3SynFloodReportTuning:
        def __init__(self):
            self.rsSESSIONL3SynFloodReportEntries = 'rsSESSIONL3SynFloodReportEntries'
            self.rsSESSIONL3SynFloodReportEntriesAfterReset = 'rsSESSIONL3SynFloodReportEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONL3SynFloodReportTuning'

    class RdwrDPJumboFrames:
        def __init__(self):
            self.rdwrDPJumboFramesMaxSwitchSize = 'rdwrDPJumboFramesMaxSwitchSize'
            self.rdwrDPJumboFramesMaxInspectionSize = 'rdwrDPJumboFramesMaxInspectionSize'
            self.rdwrDPJumboFramesProcessStatus = 'rdwrDPJumboFramesProcessStatus'

        def __call__(self):
            return 'RdwrDPJumboFrames'

    class RsIDSNewRulesEntryTwo:
        def __init__(self):
            self.instanceIdTwo = 'instanceIdTwo'
            self.priorityTwo = 'priorityTwo'
            self.stateTwo = 'stateTwo'
            self.actionTwo = 'actionTwo'
            self.packetReportingStatusTwo = 'packetReportingStatusTwo'
            self.packetReportingEnforcementTwo = 'packetReportingEnforcementTwo'
            self.packetTraceStatusTwo = 'packetTraceStatusTwo'
            self.packetTraceEnforcementTwo = 'packetTraceEnforcementTwo'
            self.statusTwo = 'statusTwo'
            self.nameTwo = 'nameTwo'

        def __call__(self):
            return 'RsIDSNewRulesEntryTwo'

    class RsAPMTuning:
        def __init__(self):
            self.rsAPMNumberOfPolicies = 'rsAPMNumberOfPolicies'
            self.rsAPMNumberOfPoliciesAfterReset = 'rsAPMNumberOfPoliciesAfterReset'
            self.rsAPMNumberOfFarmsPerPolicy = 'rsAPMNumberOfFarmsPerPolicy'
            self.rsAPMNumberOfFarmsPerPolicyAfterReset = 'rsAPMNumberOfFarmsPerPolicyAfterReset'
            self.rsAPMNumberOfFarmElementsPerFarm = 'rsAPMNumberOfFarmElementsPerFarm'
            self.rsAPMNumberOfFarmElementsPerFarmAfterReset = 'rsAPMNumberOfFarmElementsPerFarmAfterReset'
            self.rsAPMNumberOfLegFarmsPerPolicy = 'rsAPMNumberOfLegFarmsPerPolicy'
            self.rsAPMNumberOfLegFarmsPerPolicyAfterReset = 'rsAPMNumberOfLegFarmsPerPolicyAfterReset'
            self.rsAPMNumberOfAlerts = 'rsAPMNumberOfAlerts'
            self.rsAPMNumberOfAlertsAfterReset = 'rsAPMNumberOfAlertsAfterReset'
            self.rsAPMNumberOfApmSessions = 'rsAPMNumberOfApmSessions'
            self.rsAPMNumberOfApmSessionsAfterReset = 'rsAPMNumberOfApmSessionsAfterReset'
            self.rsAPMNumberOfPoliciesPerSession = 'rsAPMNumberOfPoliciesPerSession'
            self.rsAPMNumberOfPoliciesPerSessionAfterReset = 'rsAPMNumberOfPoliciesPerSessionAfterReset'

        def __call__(self):
            return 'RsAPMTuning'

    class RsIDSSignaturesAttackAttributeStaticEntry:
        def __init__(self):
            self.attributeId = 'attributeId'
            self.status = 'status'
            self.attackId = 'attackId'
            self.attributeName = 'attributeName'

        def __call__(self):
            return 'RsIDSSignaturesAttackAttributeStaticEntry'

    class LagMIBObjects:
        def __init__(self):
            self.dot3adTablesLastChanged = 'dot3adTablesLastChanged'

        def __call__(self):
            return 'LagMIBObjects'

    class RsIDS:
        def __init__(self):
            self.mechanismStatus = 'mechanismStatus'
            self.tCPAgingTimeFreq = 'tCPAgingTimeFreq'
            self.nCPsAgingTimeFreq = 'nCPsAgingTimeFreq'
            self.statsAgingTimeFreq = 'statsAgingTimeFreq'
            self.nCPSTableSize = 'nCPSTableSize'
            self.nCPDTableSize = 'nCPDTableSize'
            self.nCPSDTableSize = 'nCPSDTableSize'
            self.tCPTableSize = 'tCPTableSize'
            self.sTATSTableSize = 'sTATSTableSize'
            self.basic = 'basic'
            self.allServers = 'allServers'
            self.uNIXServers = 'uNIXServers'
            self.lotusServers = 'lotusServers'
            self.mSIISServers = 'mSIISServers'
            self.mSFrontPageServers = 'mSFrontPageServers'
            self.apacheServers = 'apacheServers'
            self.netscapeWebServers = 'netscapeWebServers'
            self.novellServers = 'novellServers'
            self.oracleServers = 'oracleServers'
            self.omniHTTPDServers = 'omniHTTPDServers'
            self.webSiteServers = 'webSiteServers'
            self.coldfusionServers = 'coldfusionServers'
            self.iRIXServers = 'iRIXServers'
            self.nCSAServers = 'nCSAServers'
            self.compaqServers = 'compaqServers'
            self.backdoors = 'backdoors'
            self.traps = 'traps'
            self.nCPDTableSizeAfterReset = 'nCPDTableSizeAfterReset'
            self.nCPSDTableSizeAfterReset = 'nCPSDTableSizeAfterReset'
            self.tCPTableSizeAfterReset = 'tCPTableSizeAfterReset'
            self.sTATSTableSizeAfterReset = 'sTATSTableSizeAfterReset'
            self.logfileAgingTimeFreq = 'logfileAgingTimeFreq'
            self.sendLogFile = 'sendLogFile'
            self.utils = 'utils'
            self.version = 'version'
            self.email = 'email'
            self.logging = 'logging'
            self.sLTSamplingTimeFreq = 'sLTSamplingTimeFreq'
            self.sLTMechStatus = 'sLTMechStatus'
            self.reportStatus = 'reportStatus'
            self.sLTReportStatus = 'sLTReportStatus'
            self.restore = 'restore'
            self.maxURILength = 'maxURILength'
            self.minFragmentSize = 'minFragmentSize'
            self.minUrlPktSize = 'minUrlPktSize'
            self.restoreGroup = 'restoreGroup'
            self.panicMode = 'panicMode'
            self.attackDBSend = 'attackDBSend'
            self.attackDBVersion = 'attackDBVersion'
            self.attackDBUpdateRes = 'attackDBUpdateRes'
            self.dHCPTableSize = 'dHCPTableSize'
            self.dHCPTableSizeAfterReset = 'dHCPTableSizeAfterReset'
            self.globalPacketReport = 'globalPacketReport'
            self.reportingInterval = 'reportingInterval'
            self.maxAlertPerReport = 'maxAlertPerReport'
            self.nCPSTableSizeAfterReset = 'nCPSTableSizeAfterReset'
            self.reportTerminalStatus = 'reportTerminalStatus'
            self.reportSysLogStatus = 'reportSysLogStatus'
            self.packetReportLimit = 'packetReportLimit'
            self.packetReportAttackLimit = 'packetReportAttackLimit'
            self.reportAggregationTrheshold = 'reportAggregationTrheshold'
            self.aSAttackNextID = 'aSAttackNextID'
            self.dOSAttackNextID = 'dOSAttackNextID'
            self.encoding = 'encoding'
            self.reportTrapsRisk = 'reportTrapsRisk'
            self.reportEmailRisk = 'reportEmailRisk'
            self.reportTerminalRisk = 'reportTerminalRisk'
            self.reportSysLogRisk = 'reportSysLogRisk'
            self.tcpReassemblyStatus = 'tcpReassemblyStatus'
            self.dropSession = 'dropSession'
            self.minRisk = 'minRisk'
            self.serverProtectionTabServers = 'serverProtectionTabServers'
            self.serverProtectionTabServersAfterReset = 'serverProtectionTabServersAfterReset'
            self.oOPStatus = 'oOPStatus'
            self.rsIdsHwaccWarning = 'rsIdsHwaccWarning'
            self.httpfldSuspectSrcIp = 'httpfldSuspectSrcIp'
            self.httpfldSuspectSrcIpAfterReset = 'httpfldSuspectSrcIpAfterReset'
            self.pPSMaxPerConnectionAttacks = 'pPSMaxPerConnectionAttacks'
            self.mAXConnectionIP = 'mAXConnectionIP'
            self.pPSMaxSrcIp = 'pPSMaxSrcIp'
            self.pPSMaxTrackedSources = 'pPSMaxTrackedSources'
            self.bWMReportTrackTime = 'bWMReportTrackTime'
            self.bWMReportStartThreshold = 'bWMReportStartThreshold'
            self.bWMReportTermThresholdDelta = 'bWMReportTermThresholdDelta'
            self.geoIPDBVersion = 'geoIPDBVersion'
            self.geoIPDBUpdateRes = 'geoIPDBUpdateRes'
            self.geoIPDBSend = 'geoIPDBSend'
            self.rsTcpAuthenListAging = 'rsTcpAuthenListAging'
            self.rsHttpAuthenListAging = 'rsHttpAuthenListAging'
            self.rsTcpAuthenListUtilization = 'rsTcpAuthenListUtilization'
            self.rsHttpAuthenListUtilization = 'rsHttpAuthenListUtilization'
            self.rsDnsAuthenListUtilization = 'rsDnsAuthenListUtilization'
            self.rsTcpAuthenListSize = 'rsTcpAuthenListSize'
            self.rsHttpAuthenListSize = 'rsHttpAuthenListSize'
            self.rsDnsAuthenListSize = 'rsDnsAuthenListSize'
            self.rsTcpAuthenListClean = 'rsTcpAuthenListClean'
            self.rsHttpAuthenListClean = 'rsHttpAuthenListClean'
            self.rsDnsAuthenListClean = 'rsDnsAuthenListClean'
            self.rsHttpAuthenListSizeAfterReset = 'rsHttpAuthenListSizeAfterReset'
            self.rsTcpAuthenListSizeAfterReset = 'rsTcpAuthenListSizeAfterReset'
            self.trafficExclusionStatus = 'trafficExclusionStatus'
            self.hwPoliciesTotalNum = 'hwPoliciesTotalNum'
            self.hwPoliciesSubPoliciesUtilization = 'hwPoliciesSubPoliciesUtilization'
            self.hwPoliciesHWEntriesUtilization = 'hwPoliciesHWEntriesUtilization'
            self.bWMReportRiskLevel = 'bWMReportRiskLevel'
            self.reportSysLogSeverity = 'reportSysLogSeverity'
            self.reportTrapsSeverity = 'reportTrapsSeverity'
            self.rsTcpAuthenContenderTblUtilization = 'rsTcpAuthenContenderTblUtilization'
            self.rsTcpAuthenContenderTblClean = 'rsTcpAuthenContenderTblClean'
            self.reportInterval = 'reportInterval'

        def __call__(self):
            return 'RsIDS'

    class RsBWM:
        def __init__(self):
            self.cBQMode = 'cBQMode'
            self.actualQueueSize = 'actualQueueSize'
            self.averageQueueSize = 'averageQueueSize'
            self.queueRedDropped = 'queueRedDropped'
            self.redMode = 'redMode'
            self.classificationMode = 'classificationMode'
            self.maximumBandwidth = 'maximumBandwidth'
            self.bandwidthBorrowingMode = 'bandwidthBorrowingMode'
            self.actions = 'actions'
            self.applicationClassification = 'applicationClassification'
            self.version = 'version'
            self.sessionAgingTime = 'sessionAgingTime'
            self.samplingRatio = 'samplingRatio'
            self.samplerOverloadMode = 'samplerOverloadMode'
            self.oMPCHashTableOffset = 'oMPCHashTableOffset'
            self.oMPCHashTableMask = 'oMPCHashTableMask'
            self.noSaveMode = 'noSaveMode'
            self.stringSearchMode = 'stringSearchMode'
            self.queueSize = 'queueSize'
            self.trafficFlowBWAgingTime = 'trafficFlowBWAgingTime'
            self.defaultGatewayClassificatiomMode = 'defaultGatewayClassificatiomMode'
            self.tCPSessionClassification = 'tCPSessionClassification'
            self.maxPacketsForClassification = 'maxPacketsForClassification'

        def __call__(self):
            return 'RsBWM'

    class RsMLBSrcSbntGroupEntry:
        def __init__(self):
            self.srvrStatus = 'srvrStatus'
            self.srvrOperMode = 'srvrOperMode'
            self.addr = 'addr'
            self.mask = 'mask'
            self.srvrAddr = 'srvrAddr'

        def __call__(self):
            return 'RsMLBSrcSbntGroupEntry'

    class RsNetFloodBypassIcmpEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassIcmpEntry'

    class RsMLBRemoteStationEntry:
        def __init__(self):
            self.externalAddress = 'externalAddress'
            self.setMode = 'setMode'
            self.status = 'status'
            self.remoteServiceName = 'remoteServiceName'
            self.remoteLinkAddress = 'remoteLinkAddress'
            self.internalAddress = 'internalAddress'

        def __call__(self):
            return 'RsMLBRemoteStationEntry'

    class RdwrDPRouting:
        def __init__(self):
            self.rdwrDPRoutingStatus = 'rdwrDPRoutingStatus'

        def __call__(self):
            return 'RdwrDPRouting'

    class RndDeviceParams:
        def __init__(self):
            self.rndBridgeType = 'rndBridgeType'
            self.rndInactiveArpTimeOut = 'rndInactiveArpTimeOut'
            self.rndBrgVersion = 'rndBrgVersion'
            self.rndBrgFeatures = 'rndBrgFeatures'
            self.rndBrgLicense = 'rndBrgLicense'
            self.rndManagedTime = 'rndManagedTime'
            self.rndManagedDate = 'rndManagedDate'
            self.rndSerialNumber = 'rndSerialNumber'
            self.rndApsoluteOSVersion = 'rndApsoluteOSVersion'
            self.rdwrDeviceType = 'rdwrDeviceType'
            self.rdwrDeviceNumberOfPorts = 'rdwrDeviceNumberOfPorts'
            self.rdwrDevicePortsConfig = 'rdwrDevicePortsConfig'
            self.rdwrDeviceThroughput = 'rdwrDeviceThroughput'
            self.rdwrDeviceNetworkDriver = 'rdwrDeviceNetworkDriver'
            self.rdwrDeviceCPUsNumber = 'rdwrDeviceCPUsNumber'
            self.rdwrDeviceActiveBoot = 'rdwrDeviceActiveBoot'
            self.rdwrDeviceSecondaryBoot = 'rdwrDeviceSecondaryBoot'

        def __call__(self):
            return 'RndDeviceParams'

    class RsStatisticsDiscoveryEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.destinationMACGroup = 'destinationMACGroup'
            self.sourceMACGroup = 'sourceMACGroup'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.direction = 'direction'
            self.operationalStatus = 'operationalStatus'
            self.status = 'status'
            self.fromFarm = 'fromFarm'
            self.toFarm = 'toFarm'
            self.classificationPoint = 'classificationPoint'
            self.name = 'name'

        def __call__(self):
            return 'RsStatisticsDiscoveryEntry'

    class RsMaxDspClntEntriesTuning:
        def __init__(self):
            self.rsMaxDspClntEntries = 'rsMaxDspClntEntries'
            self.rsMaxDspClntEntriesAfterReset = 'rsMaxDspClntEntriesAfterReset'

        def __call__(self):
            return 'RsMaxDspClntEntriesTuning'

    class RsMLB:
        def __init__(self):
            self.adminStatus = 'adminStatus'
            self.clientsLifeTime = 'clientsLifeTime'
            self.dispatchMethod = 'dispatchMethod'
            self.checkConnectivityStatus = 'checkConnectivityStatus'
            self.checkConnectivityMethod = 'checkConnectivityMethod'
            self.checkConnectivityInterval = 'checkConnectivityInterval'
            self.checkConnectivityRetries = 'checkConnectivityRetries'
            self.clientsConnectDenials = 'clientsConnectDenials'
            self.sessionTracking = 'sessionTracking'
            self.clientTableMode = 'clientTableMode'
            self.translateOutBoundMode = 'translateOutBoundMode'
            self.virtualConnectivityIP = 'virtualConnectivityIP'
            self.virtualConnectivityMode = 'virtualConnectivityMode'
            self.removeEntryAtSessionEnd = 'removeEntryAtSessionEnd'
            self.firewallPortID = 'firewallPortID'
            self.fpNatStatus = 'fpNatStatus'
            self.srcPortInClientHash = 'srcPortInClientHash'
            self.timeoutForSYN = 'timeoutForSYN'
            self.tosOrPrecedence = 'tosOrPrecedence'
            self.checkConnectivitySnmpOid = 'checkConnectivitySnmpOid'
            self.checkConnectivitySnmpComm = 'checkConnectivitySnmpComm'
            self.noAvailableBasicNatAction = 'noAvailableBasicNatAction'
            self.clientTableHashLimit = 'clientTableHashLimit'
            self.checkConnectivityHttpUrl = 'checkConnectivityHttpUrl'
            self.hTTPContentCheckString = 'hTTPContentCheckString'
            self.hTTPContentCheckMode = 'hTTPContentCheckMode'
            self.hTTPContentCheckStatus = 'hTTPContentCheckStatus'
            self.proximityMirrorPercentage = 'proximityMirrorPercentage'
            self.proximityMirrorPollingTime = 'proximityMirrorPollingTime'
            self.proximityMirrorProtocolMode = 'proximityMirrorProtocolMode'
            self.transparentLoadBalancingMode = 'transparentLoadBalancingMode'
            self.fragmentTableAgingTime = 'fragmentTableAgingTime'
            self.identifyServerByNameMode = 'identifyServerByNameMode'
            self.excludeStaticNatForLocalNetwork = 'excludeStaticNatForLocalNetwork'
            self.iDSAdminStatus = 'iDSAdminStatus'
            self.resetFromIDSStatus = 'resetFromIDSStatus'
            self.staticNATClassificationMode = 'staticNATClassificationMode'
            self.dynamicNATClassificationMode = 'dynamicNATClassificationMode'
            self.basicNATClassificationMode = 'basicNATClassificationMode'
            self.overrideOSPFLeakonFailure = 'overrideOSPFLeakonFailure'
            self.overrideRIPLeakonFailure = 'overrideRIPLeakonFailure'
            self.advertiseOSPFAccordingtoPortRules = 'advertiseOSPFAccordingtoPortRules'
            self.advertiseRIPAccordingtoPortRules = 'advertiseRIPAccordingtoPortRules'
            self.trackNHRTableAgingTime = 'trackNHRTableAgingTime'
            self.ftpCtrlPort = 'ftpCtrlPort'
            self.ftpDataPort = 'ftpDataPort'
            self.groupSrvrOperModeMethod = 'groupSrvrOperModeMethod'
            self.logicalServersArpForMacEnable = 'logicalServersArpForMacEnable'
            self.logicalServersArpForMacTime = 'logicalServersArpForMacTime'
            self.iDSLbSessionClassifyMode = 'iDSLbSessionClassifyMode'
            self.pingStaticNatStatus = 'pingStaticNatStatus'
            self.iDSLbHashMethod = 'iDSLbHashMethod'
            self.trackNHRTableStatus = 'trackNHRTableStatus'
            self.accLookupModeExtension = 'accLookupModeExtension'

        def __call__(self):
            return 'RsMLB'

    class VrrpAssoIpAddrEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.ifIndex = 'ifIndex'
            self.vrId = 'vrId'
            self.vrrpAssoIpAddr = 'vrrpAssoIpAddr'

        def __call__(self):
            return 'VrrpAssoIpAddrEntry'

    class RsIDSProfilesEntry:
        def __init__(self):
            self.category = 'category'
            self.status = 'status'
            self.serviceId = 'serviceId'
            self.type = 'type'
            self.name = 'name'
            self.serviceName = 'serviceName'

        def __call__(self):
            return 'RsIDSProfilesEntry'

    class RsBWMACLSummaryReportsEntry:
        def __init__(self):
            self.tCPAllow = 'tCPAllow'
            self.tCPDrop = 'tCPDrop'
            self.uDPAllow = 'uDPAllow'
            self.uDPDrop = 'uDPDrop'
            self.iCMPAllow = 'iCMPAllow'
            self.iCMPDrop = 'iCMPDrop'
            self.otherAllow = 'otherAllow'
            self.otherDrop = 'otherDrop'
            self.tCPMidSess = 'tCPMidSess'
            self.tCPRstInvalid = 'tCPRstInvalid'
            self.tCPHandshakeViolation = 'tCPHandshakeViolation'
            self.iCMPSmurf = 'iCMPSmurf'
            self.iCMPPacketAnomaly = 'iCMPPacketAnomaly'
            self.gREAllow = 'gREAllow'
            self.gREDrop = 'gREDrop'
            self.sCTPAllow = 'sCTPAllow'
            self.sCTPDrop = 'sCTPDrop'
            self.l2TPAllow = 'l2TPAllow'
            self.l2TPDrop = 'l2TPDrop'
            self.gTPAllow = 'gTPAllow'
            self.gTPDrop = 'gTPDrop'
            self.iPinIPAllow = 'iPinIPAllow'
            self.iPinIPDrop = 'iPinIPDrop'
            self.policyName = 'policyName'

        def __call__(self):
            return 'RsBWMACLSummaryReportsEntry'

    class RsSESSIONSynTriggerEntry:
        def __init__(self):
            self.time = 'time'
            self.lastSecSYN = 'lastSecSYN'
            self.lastSecRqst = 'lastSecRqst'
            self.avrgSYN = 'avrgSYN'
            self.avrgRqst = 'avrgRqst'
            self.ip = 'ip'
            self.port = 'port'
            self.rxport = 'rxport'

        def __call__(self):
            return 'RsSESSIONSynTriggerEntry'

    class RsIDSGroupEntry:
        def __init__(self):
            self.name = 'name'
            self.id = 'id'
            self.type = 'type'
            self.status = 'status'
            self.rsIDSGroupName = 'rsIDSGroupName'
            self.rsIDSGroupEntryID = 'rsIDSGroupEntryID'

        def __call__(self):
            return 'RsIDSGroupEntry'

    class RsIDSSynServersEntry:
        def __init__(self):
            self.iDSSYNServerState = 'iDSSYNServerState'
            self.iDSSYNServerActivationThreshold = 'iDSSYNServerActivationThreshold'
            self.iDSSYNServerTerminationThreshold = 'iDSSYNServerTerminationThreshold'
            self.iDSSYNServerStableThresholdPeriod = 'iDSSYNServerStableThresholdPeriod'
            self.iDSSYNServerStatus = 'iDSSYNServerStatus'
            self.iDSSYNServerName = 'iDSSYNServerName'
            self.iDSSYNServerPort = 'iDSSYNServerPort'

        def __call__(self):
            return 'RsIDSSynServersEntry'

    class RsNetFloodBypassUdpEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassUdpEntry'

    class RsBWMGroupNetworksListEntry:
        def __init__(self):
            self.bWMNetworksList = 'bWMNetworksList'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMGroupNetworksListEntry'

    class SysOREntry:
        def __init__(self):
            self.orid = 'orid'
            self.oRDescr = 'oRDescr'
            self.oRUpTime = 'oRUpTime'
            self.oRIndex = 'oRIndex'

        def __call__(self):
            return 'SysOREntry'

    class RdwrApplicationFileEntry:
        def __init__(self):
            self.running = 'running'
            self.selected = 'selected'
            self.valid = 'valid'
            self.startup = 'startup'
            self.version = 'version'
            self.action = 'action'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RdwrApplicationFileEntry'

    class RsBWMBwmVLANOperationEntry:
        def __init__(self):
            self.status = 'status'
            self.rsBWMBwmVLAN = 'rsBWMBwmVLAN'

        def __call__(self):
            return 'RsBWMBwmVLANOperationEntry'

    class RsIDSMPLSRDGroupEntry:
        def __init__(self):
            self.rDType = 'rDType'
            self.status = 'status'
            self.name = 'name'
            self.rDValue = 'rDValue'

        def __call__(self):
            return 'RsIDSMPLSRDGroupEntry'

    class RsIDSDOSOverloadEvent:
        def __init__(self):
            self.rsIDSDOSOverloadErrorDesc = 'rsIDSDOSOverloadErrorDesc'
            self.rsIDSDOSOverloadErrorSeverity = 'rsIDSDOSOverloadErrorSeverity'

        def __call__(self):
            return 'RsIDSDOSOverloadEvent'

    class RsCPCIDRPeerProhibitedMatchEntry:
        def __init__(self):
            self.description = 'description'
            self.status = 'status'
            self.neighborIP = 'neighborIP'
            self.localRouterIP = 'localRouterIP'
            self.cIDRSubnet = 'cIDRSubnet'
            self.cIDRMask = 'cIDRMask'

        def __call__(self):
            return 'RsCPCIDRPeerProhibitedMatchEntry'

    class RsIDSSLTACTtrackingEntry:
        def __init__(self):
            self.iDSSLTACTAlertThreshold = 'iDSSLTACTAlertThreshold'
            self.iDSSLTACTActiveThreshold = 'iDSSLTACTActiveThreshold'
            self.iDSSLTACTDropThreshold = 'iDSSLTACTDropThreshold'
            self.iDSSLTACTTermAlertThreshold = 'iDSSLTACTTermAlertThreshold'
            self.iDSSLTACTTermThreshold = 'iDSSLTACTTermThreshold'
            self.iDSSLTACTAgingPeriod = 'iDSSLTACTAgingPeriod'
            self.iDSSLTACTObjectID = 'iDSSLTACTObjectID'
            self.iDSSLTACTAttackState = 'iDSSLTACTAttackState'
            self.iDSSLTACTMsg = 'iDSSLTACTMsg'
            self.iDSSLTACTStatus = 'iDSSLTACTStatus'
            self.iDSSLTACTReportMode = 'iDSSLTACTReportMode'
            self.iDSSLTACTRisk = 'iDSSLTACTRisk'
            self.iDSSLTACTFilterGroupName = 'iDSSLTACTFilterGroupName'

        def __call__(self):
            return 'RsIDSSLTACTtrackingEntry'

    class RsNetFlood:
        def __init__(self):
            self.rsNetFloodMechStatus = 'rsNetFloodMechStatus'
            self.rsNetFloodBandwidthIn = 'rsNetFloodBandwidthIn'
            self.rsNetFloodBandwidthOut = 'rsNetFloodBandwidthOut'
            self.rsNetFloodLearningPeriod = 'rsNetFloodLearningPeriod'
            self.rsNetFloodResetAllLearning = 'rsNetFloodResetAllLearning'
            self.rsNetFloodResetPolicyLearning = 'rsNetFloodResetPolicyLearning'
            self.rsNetFloodSetDefaultQuotas = 'rsNetFloodSetDefaultQuotas'
            self.rsNetFloodFootprintStrictness = 'rsNetFloodFootprintStrictness'
            self.rsNetFloodSamplingStatus = 'rsNetFloodSamplingStatus'
            self.rsIDSNetFloodPolicies = 'rsIDSNetFloodPolicies'
            self.rsIDSNetFloodPoliciesAfterReset = 'rsIDSNetFloodPoliciesAfterReset'
            self.rsNetFloodDynamicTermSC2 = 'rsNetFloodDynamicTermSC2'
            self.rsNetFloodDynamicTermSC6 = 'rsNetFloodDynamicTermSC6'
            self.rsNetFloodDynamicTermSC37 = 'rsNetFloodDynamicTermSC37'
            self.rsNetFloodAvgUdpSzNorm = 'rsNetFloodAvgUdpSzNorm'
            self.rsNetFloodAvgUdpSzAttack = 'rsNetFloodAvgUdpSzAttack'
            self.rsNetFloodEnableANDrestriction = 'rsNetFloodEnableANDrestriction'
            self.rsNetFloodExpertTableT2 = 'rsNetFloodExpertTableT2'
            self.rsNetFloodExpertTableT3 = 'rsNetFloodExpertTableT3'
            self.rsNetFloodExpertTableT4 = 'rsNetFloodExpertTableT4'
            self.rsNetFloodExpertTableT6 = 'rsNetFloodExpertTableT6'
            self.rsNetFloodExpertTableT7 = 'rsNetFloodExpertTableT7'
            self.rsNetFloodExpertTableT8 = 'rsNetFloodExpertTableT8'
            self.rsNetFloodLearningSuppressionThreshold = 'rsNetFloodLearningSuppressionThreshold'
            self.rsNetFloodConcurrentActiveAttacks = 'rsNetFloodConcurrentActiveAttacks'
            self.rsNetFloodFootprintThresholds = 'rsNetFloodFootprintThresholds'
            self.rsNetFloodDestIPFootprintStatus = 'rsNetFloodDestIPFootprintStatus'

        def __call__(self):
            return 'RsNetFlood'

    class RsMLBApplPortGroupEntry:
        def __init__(self):
            self.srvrStatus = 'srvrStatus'
            self.srvrOperMode = 'srvrOperMode'
            self.rsMLBApplPort = 'rsMLBApplPort'
            self.srvrAddr = 'srvrAddr'

        def __call__(self):
            return 'RsMLBApplPortGroupEntry'

    class RsBWMRulesIPObjectEntry:
        def __init__(self):
            self.address = 'address'
            self.mask = 'mask'
            self.fromIP = 'fromIP'
            self.toIP = 'toIP'
            self.mode = 'mode'
            self.status = 'status'
            self.name = 'name'
            self.subIndex = 'subIndex'

        def __call__(self):
            return 'RsBWMRulesIPObjectEntry'

    class RsIDSStatsEntry:
        def __init__(self):
            self.iDSAttackName = 'iDSAttackName'
            self.iDSAttackSrcAddr = 'iDSAttackSrcAddr'
            self.iDSAttackDstAddr = 'iDSAttackDstAddr'
            self.iDSAttackStatus = 'iDSAttackStatus'
            self.iDSAttacktime = 'iDSAttacktime'
            self.status = 'status'
            self.context = 'context'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.protocol = 'protocol'
            self.phyPort = 'phyPort'
            self.rid = 'rid'
            self.service = 'service'
            self.iDSPolicyName = 'iDSPolicyName'
            self.pktCount = 'pktCount'
            self.byteCount = 'byteCount'
            self.reportMode = 'reportMode'
            self.risk = 'risk'
            self.iDSAttackIndex = 'iDSAttackIndex'

        def __call__(self):
            return 'RsIDSStatsEntry'

    class RsIDSServerTableEntry:
        def __init__(self):
            self.iPAddress = 'iPAddress'
            self.sYNProfile = 'sYNProfile'
            self.hTTPProfile = 'hTTPProfile'
            self.iPSProfile = 'iPSProfile'
            self.state = 'state'
            self.status = 'status'
            self.packetTraceStatus = 'packetTraceStatus'
            self.packetTraceEnforcement = 'packetTraceEnforcement'
            self.packetReportStatus = 'packetReportStatus'
            self.packetReportEnforcement = 'packetReportEnforcement'
            self.vlanTagGroup = 'vlanTagGroup'
            self.iPRange = 'iPRange'
            self.sDiscoveryServerPolicyName = 'sDiscoveryServerPolicyName'
            self.sDiscoveryServerStatus = 'sDiscoveryServerStatus'
            self.nextReEvaluationTime = 'nextReEvaluationTime'
            self.lastValidatedTimeStamp = 'lastValidatedTimeStamp'
            self.policyName = 'policyName'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSServerTableEntry'

    class RsStatefulStatisticsEntry:
        def __init__(self):
            self.sTATFULStatisticsProtocolName = 'sTATFULStatisticsProtocolName'
            self.sTATFULStatisticsEstablished = 'sTATFULStatisticsEstablished'
            self.sTATFULStatisticsTainted = 'sTATFULStatisticsTainted'
            self.sTATFULStatisticsIndex = 'sTATFULStatisticsIndex'

        def __call__(self):
            return 'RsStatefulStatisticsEntry'

    class RsBWMCurrentRulesIPObjectEntry:
        def __init__(self):
            self.address = 'address'
            self.mask = 'mask'
            self.fromIP = 'fromIP'
            self.toIP = 'toIP'
            self.mode = 'mode'
            self.name = 'name'
            self.subIndex = 'subIndex'

        def __call__(self):
            return 'RsBWMCurrentRulesIPObjectEntry'

    class RdwrDP:
        def __init__(self):
            self.bypassStatus = 'bypassStatus'
            self.rsSmeOverloadMechanism = 'rsSmeOverloadMechanism'
            self.rsOverloadAlerts = 'rsOverloadAlerts'
            self.rsGlobalOverloadMechanism = 'rsGlobalOverloadMechanism'
            self.buildID = 'buildID'
            self.netDrvVersion = 'netDrvVersion'
            self.accRamSize = 'accRamSize'
            self.version = 'version'
            self.bypassJumboFramesStatus = 'bypassJumboFramesStatus'
            self.eZChipEnabled = 'eZChipEnabled'
            self.operationSwitchMode = 'operationSwitchMode'

        def __call__(self):
            return 'RdwrDP'

    class RsIDSPPS:
        def __init__(self):
            self.rsIDSPPSAttackNextID = 'rsIDSPPSAttackNextID'

        def __call__(self):
            return 'RsIDSPPS'

    class RsIDSConnectionLimit:
        def __init__(self):
            self.rsIDSConnectionLimitAttackNextID = 'rsIDSConnectionLimitAttackNextID'

        def __call__(self):
            return 'RsIDSConnectionLimit'

    class RsNewBlackListEntryTwo:
        def __init__(self):
            self.expirationHourTwo = 'expirationHourTwo'
            self.expirationMinuteTwo = 'expirationMinuteTwo'
            self.cDBExpirationTimeTwo = 'cDBExpirationTimeTwo'
            self.detectorTwo = 'detectorTwo'
            self.detectorSecurityModuleTwo = 'detectorSecurityModuleTwo'
            self.dynamicStateTwo = 'dynamicStateTwo'
            self.actionTwo = 'actionTwo'
            self.reportActionTwo = 'reportActionTwo'
            self.packetReportTwo = 'packetReportTwo'
            self.statusTwo = 'statusTwo'
            self.nameTwo = 'nameTwo'

        def __call__(self):
            return 'RsNewBlackListEntryTwo'

    class RsBWMCurrentPolicyEntry:
        def __init__(self):
            self.name = 'name'
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.action = 'action'
            self.direction = 'direction'
            self.priority = 'priority'
            self.type = 'type'
            self.description = 'description'
            self.guaranteedBW = 'guaranteedBW'
            self.filterType = 'filterType'
            self.filter = 'filter'
            self.reportBlockedPackets = 'reportBlockedPackets'
            self.maxBW = 'maxBW'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.specific = 'specific'
            self.radiusRule = 'radiusRule'
            self.key = 'key'

        def __call__(self):
            return 'RsBWMCurrentPolicyEntry'

    class RsDnsProtProfileEntry:
        def __init__(self):
            self.dnsAStatus = 'dnsAStatus'
            self.dnsMxStatus = 'dnsMxStatus'
            self.dnsPtrStatus = 'dnsPtrStatus'
            self.dnsAaaaStatus = 'dnsAaaaStatus'
            self.dnsTextStatus = 'dnsTextStatus'
            self.dnsSoaStatus = 'dnsSoaStatus'
            self.dnsNaptrStatus = 'dnsNaptrStatus'
            self.dnsSrvStatus = 'dnsSrvStatus'
            self.dnsOtherStatus = 'dnsOtherStatus'
            self.expectedQps = 'expectedQps'
            self.dnsAQuota = 'dnsAQuota'
            self.dnsMxQuota = 'dnsMxQuota'
            self.dnsPtrQuota = 'dnsPtrQuota'
            self.dnsAaaaQuota = 'dnsAaaaQuota'
            self.dnsTextQuota = 'dnsTextQuota'
            self.dnsSoaQuota = 'dnsSoaQuota'
            self.dnsNaptrQuota = 'dnsNaptrQuota'
            self.dnsSrvQuota = 'dnsSrvQuota'
            self.dnsOtherQuota = 'dnsOtherQuota'
            self.action = 'action'
            self.maxAllowQps = 'maxAllowQps'
            self.sigRateLimTarget = 'sigRateLimTarget'
            self.manualTriggerStatus = 'manualTriggerStatus'
            self.manualTriggerActThresh = 'manualTriggerActThresh'
            self.manualTriggerTermThresh = 'manualTriggerTermThresh'
            self.manualTriggerMaxQpsTarget = 'manualTriggerMaxQpsTarget'
            self.manualTriggerActPeriod = 'manualTriggerActPeriod'
            self.manualTriggerTermPeriod = 'manualTriggerTermPeriod'
            self.manualTriggerEscalatePeriod = 'manualTriggerEscalatePeriod'
            self.packetReportStatus = 'packetReportStatus'
            self.packetTraceStatus = 'packetTraceStatus'
            self.status = 'status'
            self.challengeMethod = 'challengeMethod'
            self.name = 'name'

        def __call__(self):
            return 'RsDnsProtProfileEntry'

    class IfStackEntry:
        def __init__(self):
            self.status = 'status'
            self.higherLayer = 'higherLayer'
            self.lowerLayer = 'lowerLayer'

        def __call__(self):
            return 'IfStackEntry'

    class RsMLBLinkEntry:
        def __init__(self):
            self.iPAddress = 'iPAddress'
            self.type = 'type'
            self.status = 'status'
            self.virtDnsIP = 'virtDnsIP'
            self.no = 'no'

        def __call__(self):
            return 'RsMLBLinkEntry'

    class RsIDSSynProfilesEntry:
        def __init__(self):
            self.status = 'status'
            self.serviceId = 'serviceId'
            self.type = 'type'
            self.action = 'action'
            self.name = 'name'
            self.serviceName = 'serviceName'

        def __call__(self):
            return 'RsIDSSynProfilesEntry'

    class NdSpec:
        def __init__(self):
            self.rsNetNdInactiveTimeOut = 'rsNetNdInactiveTimeOut'

        def __call__(self):
            return 'NdSpec'

    class RsIDSSignaturesProfileAttackListEntry:
        def __init__(self):
            self.attackName = 'attackName'
            self.status = 'status'
            self.profileName = 'profileName'
            self.attackID = 'attackID'

        def __call__(self):
            return 'RsIDSSignaturesProfileAttackListEntry'

    class RsMLBRemoteNat:
        def __init__(self):
            self.rsMLBRemoteNatOperStatus = 'rsMLBRemoteNatOperStatus'
            self.rsMLBTrpProtocolOperStatus = 'rsMLBTrpProtocolOperStatus'
            self.rsMLBRNatHealthMonitorOperStatus = 'rsMLBRNatHealthMonitorOperStatus'
            self.rsMLBExecAutoRemoteNatUpdate = 'rsMLBExecAutoRemoteNatUpdate'

        def __call__(self):
            return 'RsMLBRemoteNat'

    class RsAPMCurrentPolicyEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.name = 'name'
            self.enabledStatus = 'enabledStatus'
            self.description = 'description'
            self.destination = 'destination'
            self.source = 'source'
            self.filter = 'filter'
            self.filterType = 'filterType'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.l4Protocol = 'l4Protocol'
            self.l7Protocol = 'l7Protocol'
            self.reportInterval = 'reportInterval'
            self.reportSubInterval = 'reportSubInterval'
            self.nextReportIntervalID = 'nextReportIntervalID'
            self.remainingTimeTillNextReportIntervalStart = 'remainingTimeTillNextReportIntervalStart'
            self.reportViaSrp = 'reportViaSrp'
            self.insiteInfo = 'insiteInfo'
            self.id = 'id'

        def __call__(self):
            return 'RsAPMCurrentPolicyEntry'

    class RdwrSyslogServerEntry:
        def __init__(self):
            self.status = 'status'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.facility = 'facility'
            self.protocol = 'protocol'
            self.cACertificate = 'cACertificate'
            self.rowStatus = 'rowStatus'
            self.connectionStatus = 'connectionStatus'
            self.numberOfLogsInBackLog = 'numberOfLogsInBackLog'
            self.securitySending = 'securitySending'
            self.healthSending = 'healthSending'
            self.userAuditSending = 'userAuditSending'
            self.address = 'address'

        def __call__(self):
            return 'RdwrSyslogServerEntry'

    class RsIfEntry:
        def __init__(self):
            self.speed = 'speed'
            self.duplex = 'duplex'
            self.autoNegotiate = 'autoNegotiate'
            self.autoNegotiateCfg = 'autoNegotiateCfg'
            self.index = 'index'

        def __call__(self):
            return 'RsIfEntry'

    class RdwrSnmpParameters:
        def __init__(self):
            self.rdwrSnmpSupportedVersions = 'rdwrSnmpSupportedVersions'
            self.rdwrSnmpSupportedVersionsAfterReset = 'rdwrSnmpSupportedVersionsAfterReset'
            self.rdwrSnmpPort = 'rdwrSnmpPort'
            self.rdwrSnmpStatus = 'rdwrSnmpStatus'
            self.rdwrSnmpConfigFileFormat = 'rdwrSnmpConfigFileFormat'
            self.rdwrSnmpErrorIndex = 'rdwrSnmpErrorIndex'
            self.rdwrSnmpErrorStatus = 'rdwrSnmpErrorStatus'
            self.rdwrSnmpErrorDescription = 'rdwrSnmpErrorDescription'
            self.rdwrSnmpErrorRequestId = 'rdwrSnmpErrorRequestId'
            self.rdwrSnmpErrorTbTableReset = 'rdwrSnmpErrorTbTableReset'
            self.rdwrLastConfigurationChangesTableReset = 'rdwrLastConfigurationChangesTableReset'
            self.rdwrLastConfigurationChangesTimestamp = 'rdwrLastConfigurationChangesTimestamp'
            self.rdwrLastConfigurationChangesTime = 'rdwrLastConfigurationChangesTime'

        def __call__(self):
            return 'RdwrSnmpParameters'

    class RndCommunityEntry:
        def __init__(self):
            self.access = 'access'
            self.trapsEnable = 'trapsEnable'
            self.status = 'status'
            self.mngStationAddr = 'mngStationAddr'
            self.string = 'string'

        def __call__(self):
            return 'RndCommunityEntry'

    class RsBWMCurrentExtPolicyEntry:
        def __init__(self):
            self.name = 'name'
            self.fromFarm = 'fromFarm'
            self.toFarm = 'toFarm'
            self.classificationPoint = 'classificationPoint'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.maxRqstsPerSec = 'maxRqstsPerSec'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.forceBestFit = 'forceBestFit'
            self.packetMarkingType = 'packetMarkingType'
            self.packetMarkingValue = 'packetMarkingValue'
            self.reportMaxBw = 'reportMaxBw'
            self.key = 'key'

        def __call__(self):
            return 'RsBWMCurrentExtPolicyEntry'

    class RsStateful:
        def __init__(self):
            self.inspectionStatus = 'inspectionStatus'
            self.inspectionActionMode = 'inspectionActionMode'
            self.startupMode = 'startupMode'
            self.startupTimer = 'startupTimer'
            self.inspectionState = 'inspectionState'
            self.midflowStatus = 'midflowStatus'
            self.midflowAction = 'midflowAction'
            self.midflowTermThreshold = 'midflowTermThreshold'
            self.midflowActThreshold = 'midflowActThreshold'
            self.midflowPacketTraceStatus = 'midflowPacketTraceStatus'
            self.midflowAttackRisk = 'midflowAttackRisk'

        def __call__(self):
            return 'RsStateful'

    class UsmUserEntry:
        def __init__(self):
            self.securityName = 'securityName'
            self.cloneFrom = 'cloneFrom'
            self.authProtocol = 'authProtocol'
            self.authKeyChange = 'authKeyChange'
            self.ownAuthKeyChange = 'ownAuthKeyChange'
            self.privProtocol = 'privProtocol'
            self.privKeyChange = 'privKeyChange'
            self.ownPrivKeyChange = 'ownPrivKeyChange'
            self._public = '_public'
            self.storageType = 'storageType'
            self.status = 'status'
            self.engineID = 'engineID'
            self.name = 'name'

        def __call__(self):
            return 'UsmUserEntry'

    class StpSpec:
        def __init__(self):
            self.rsStpMode = 'rsStpMode'
            self.rsStpDefaultBridgePriority = 'rsStpDefaultBridgePriority'
            self.rsStpDefaultHelloTime = 'rsStpDefaultHelloTime'
            self.rsStpDefaultMaxAgingTime = 'rsStpDefaultMaxAgingTime'
            self.rsStpDefaultForwardDelayTime = 'rsStpDefaultForwardDelayTime'
            self.rsStpDefaultPortPriority = 'rsStpDefaultPortPriority'

        def __call__(self):
            return 'StpSpec'

    class VirtualLanProtocolVlan:
        def __init__(self):
            self.virtualLanUserEtherType = 'virtualLanUserEtherType'
            self.virtualLanUserMask = 'virtualLanUserMask'

        def __call__(self):
            return 'VirtualLanProtocolVlan'

    class DpsSIPCallTableTuning:
        def __init__(self):
            self.dpSIPCallEntries = 'dpSIPCallEntries'
            self.dpSIPCallEntriesAfterReset = 'dpSIPCallEntriesAfterReset'

        def __call__(self):
            return 'DpsSIPCallTableTuning'

    class RsIDSSLTNCPFEntry:
        def __init__(self):
            self.iDSSLTNCPFSamplingCNT = 'iDSSLTNCPFSamplingCNT'
            self.iDSSLTNCPFActiveCNT = 'iDSSLTNCPFActiveCNT'
            self.iDSSLTNCPFAlertState = 'iDSSLTNCPFAlertState'
            self.iDSSLTNCPFAttackState = 'iDSSLTNCPFAttackState'
            self.iDSSLTNCPFTermAlertCNT = 'iDSSLTNCPFTermAlertCNT'
            self.iDSSLTNCPFTermCNT = 'iDSSLTNCPFTermCNT'
            self.iDSSLTAttackTime = 'iDSSLTAttackTime'
            self.iDSSLTAttackDate = 'iDSSLTAttackDate'
            self.iDSSLTAttackTermTime = 'iDSSLTAttackTermTime'
            self.iDSSLTAttackTermDate = 'iDSSLTAttackTermDate'
            self.iDSSLTNCPFStatus = 'iDSSLTNCPFStatus'
            self.iDSSLTAttackMsg = 'iDSSLTAttackMsg'
            self.iDSSLTNCPFPeakCNT = 'iDSSLTNCPFPeakCNT'
            self.iDSSLTNCPFObjectID = 'iDSSLTNCPFObjectID'
            self.iDSSLTNCPFRuleName = 'iDSSLTNCPFRuleName'

        def __call__(self):
            return 'RsIDSSLTNCPFEntry'

    class RsMLBNHRDailyStatisticsEntry:
        def __init__(self):
            self.discardZonePrcnt = 'discardZonePrcnt'
            self.minBW = 'minBW'
            self.maxBW = 'maxBW'
            self.forwardedPacketNum = 'forwardedPacketNum'
            self.discardedPacketNum = 'discardedPacketNum'
            self.bytesNum = 'bytesNum'
            self.sessionsNum = 'sessionsNum'
            self.status = 'status'
            self.month = 'month'
            self.day = 'day'
            self.nHRAddr = 'nHRAddr'

        def __call__(self):
            return 'RsMLBNHRDailyStatisticsEntry'

    class RsIDSNewerSuspendTableEntry:
        def __init__(self):
            self.srcIp = 'srcIp'
            self.dstIp = 'dstIp'
            self.dstPort = 'dstPort'
            self.protocol = 'protocol'
            self.module = 'module'
            self.classType = 'classType'
            self.className = 'className'
            self.expType = 'expType'
            self.expTime = 'expTime'
            self.index = 'index'

        def __call__(self):
            return 'RsIDSNewerSuspendTableEntry'

    class VacmMIBViews:
        def __init__(self):
            self.vacmViewSpinLock = 'vacmViewSpinLock'

        def __call__(self):
            return 'VacmMIBViews'

    class RsBWMAppPortGroupEntry:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.name = 'name'
            self.fromPort = 'fromPort'
            self.toPort = 'toPort'

        def __call__(self):
            return 'RsBWMAppPortGroupEntry'

    class ReaIpxFftEntry:
        def __init__(self):
            self.dstNetid = 'dstNetid'
            self.rangeType = 'rangeType'
            self.srcMacAddr = 'srcMacAddr'
            self.dstMacAddr = 'dstMacAddr'
            self.reNum = 'reNum'
            self.portNum = 'portNum'
            self.facsSrcIndex = 'facsSrcIndex'
            self.facsDstIndex = 'facsDstIndex'
            self.num = 'num'

        def __call__(self):
            return 'ReaIpxFftEntry'

    class RsWSDSNMPPortsEntry:
        def __init__(self):
            self.wSDSNMPPhysicalPortState = 'wSDSNMPPhysicalPortState'
            self.wSDSNMPPhysicalPortTelnetState = 'wSDSNMPPhysicalPortTelnetState'
            self.wSDSNMPPhysicalPortSSHState = 'wSDSNMPPhysicalPortSSHState'
            self.wSDSNMPPhysicalPortWebState = 'wSDSNMPPhysicalPortWebState'
            self.wSDSNMPPhysicalPortSSLState = 'wSDSNMPPhysicalPortSSLState'
            self.wSDSNMPPhysicalPortNumber = 'wSDSNMPPhysicalPortNumber'

        def __call__(self):
            return 'RsWSDSNMPPortsEntry'

    class IpRedundRoutersEntry:
        def __init__(self):
            self.operStatus = 'operStatus'
            self.pollInterval = 'pollInterval'
            self.timeout = 'timeout'
            self.status = 'status'
            self.ifAddr = 'ifAddr'
            self.mainRouterAddr = 'mainRouterAddr'

        def __call__(self):
            return 'IpRedundRoutersEntry'

    class RsSESSIONSessionResetsTableTuning:
        def __init__(self):
            self.rsSESSIONSessionResetsEntries = 'rsSESSIONSessionResetsEntries'
            self.rsSESSIONSessionResetsEntriesAfterReset = 'rsSESSIONSessionResetsEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSessionResetsTableTuning'

    class RsIDSOOPTableEntry:
        def __init__(self):
            self.iDSOOPRouterIPAddress = 'iDSOOPRouterIPAddress'
            self.iDSOOPRouterPassword = 'iDSOOPRouterPassword'
            self.iDSOOPRouterProtectedPort = 'iDSOOPRouterProtectedPort'
            self.iDSOOPSSHUserName = 'iDSOOPSSHUserName'
            self.iDSOOPSSHPassWord = 'iDSOOPSSHPassWord'
            self.iDSOOPDebugMode = 'iDSOOPDebugMode'
            self.status = 'status'
            self.iDSOOPRouterEntryKey = 'iDSOOPRouterEntryKey'

        def __call__(self):
            return 'RsIDSOOPTableEntry'

    class RsIDSSynProfilesParamsEntry:
        def __init__(self):
            self.authType = 'authType'
            self.webEnable = 'webEnable'
            self.webMethod = 'webMethod'
            self.tCPResetStatus = 'tCPResetStatus'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSynProfilesParamsEntry'

    class RndDeleteValuesEntry:
        def __init__(self):
            self.rowStatusObjectId = 'rowStatusObjectId'
            self.rowDeleteValue = 'rowDeleteValue'
            self.entryStatus = 'entryStatus'
            self.rowStatusVariableName = 'rowStatusVariableName'

        def __call__(self):
            return 'RndDeleteValuesEntry'

    class RdwrVrrpAssoIpV6AddrEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.ifIndex = 'ifIndex'
            self.vrId = 'vrId'
            self.rdwrVrrpAssoIpV6Addr = 'rdwrVrrpAssoIpV6Addr'

        def __call__(self):
            return 'RdwrVrrpAssoIpV6AddrEntry'

    class Tftp:
        def __init__(self):
            self.rsTftpRetryTimeOut = 'rsTftpRetryTimeOut'
            self.rsTftpTotalTimeOut = 'rsTftpTotalTimeOut'
            self.rsSendConfigFile = 'rsSendConfigFile'
            self.rsGetConfigFile = 'rsGetConfigFile'
            self.rsLoadSoftware = 'rsLoadSoftware'
            self.rsFileServerAddress = 'rsFileServerAddress'
            self.rsGetConfigFileAppend = 'rsGetConfigFileAppend'
            self.rsGetConfigFileAppendReboot = 'rsGetConfigFileAppendReboot'
            self.rsGetConfigErrorLog = 'rsGetConfigErrorLog'
            self.rsSendConfigFileBer = 'rsSendConfigFileBer'
            self.rsIncludePrivateKeys = 'rsIncludePrivateKeys'
            self.rsGetConfigFileType = 'rsGetConfigFileType'

        def __call__(self):
            return 'Tftp'

    class RspRadiusParameters:
        def __init__(self):
            self.rspRadiusPrimaryAddr = 'rspRadiusPrimaryAddr'
            self.rspRadiusPrimaryAuthPort = 'rspRadiusPrimaryAuthPort'
            self.rspRadiusPrimaryAccPort = 'rspRadiusPrimaryAccPort'
            self.rspRadiusPrimarySecret = 'rspRadiusPrimarySecret'
            self.rspRadiusAltAddr = 'rspRadiusAltAddr'
            self.rspRadiusAltAuthPort = 'rspRadiusAltAuthPort'
            self.rspRadiusAltAccPort = 'rspRadiusAltAccPort'
            self.rspRadiusAltSecret = 'rspRadiusAltSecret'
            self.rspRadiusOwnAuthPort = 'rspRadiusOwnAuthPort'
            self.rspRadiusOwnAccPort = 'rspRadiusOwnAccPort'
            self.rspRadiusEnable = 'rspRadiusEnable'
            self.rspRadiusTransparentEnable = 'rspRadiusTransparentEnable'
            self.rspRadiusUserMirrorProtocolMode = 'rspRadiusUserMirrorProtocolMode'
            self.rspRadiusUserMirrorPollingTime = 'rspRadiusUserMirrorPollingTime'
            self.rspRadiusNetworkUpdatePolicy = 'rspRadiusNetworkUpdatePolicy'

        def __call__(self):
            return 'RspRadiusParameters'

    class RsIDSQuarantineFileSend:
        def __init__(self):
            self.quarantineDownloadAddress = 'quarantineDownloadAddress'
            self.quarantineDownloadfile = 'quarantineDownloadfile'
            self.quarantineDownloadStatus = 'quarantineDownloadStatus'
            self.quarantineDownloadPolicy = 'quarantineDownloadPolicy'

        def __call__(self):
            return 'RsIDSQuarantineFileSend'

    class RsDebugTraceApplEntryInternal:
        def __init__(self):
            self.statusInternal = 'statusInternal'
            self.severityInternal = 'severityInternal'
            self.nameInternal = 'nameInternal'

        def __call__(self):
            return 'RsDebugTraceApplEntryInternal'

    class RsNetFloodBypassTcpEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassTcpEntry'

    class Dot3adAggPortDebugEntry:
        def __init__(self):
            self.rxState = 'rxState'
            self.lastRxTime = 'lastRxTime'
            self.muxState = 'muxState'
            self.muxReason = 'muxReason'
            self.actorChurnState = 'actorChurnState'
            self.partnerChurnState = 'partnerChurnState'
            self.actorChurnCount = 'actorChurnCount'
            self.partnerChurnCount = 'partnerChurnCount'
            self.actorSyncTransitionCount = 'actorSyncTransitionCount'
            self.partnerSyncTransitionCount = 'partnerSyncTransitionCount'
            self.actorChangeCount = 'actorChangeCount'
            self.partnerChangeCount = 'partnerChangeCount'
            self.index = 'index'

        def __call__(self):
            return 'Dot3adAggPortDebugEntry'

    class RsWSDManagementPortsEntry:
        def __init__(self):
            self.wSDPortOperation = 'wSDPortOperation'
            self.wSDPortIndex = 'wSDPortIndex'

        def __call__(self):
            return 'RsWSDManagementPortsEntry'

    class RsStatistics:
        def __init__(self):
            self.sRPDstIpAddr = 'sRPDstIpAddr'
            self.probeStatusMessagePeriod = 'probeStatusMessagePeriod'
            self.probeMaxBufferingTime = 'probeMaxBufferingTime'
            self.nMSDstPort = 'nMSDstPort'
            self.probeURLMaxLength = 'probeURLMaxLength'
            self.probeRefererURLMaxLength = 'probeRefererURLMaxLength'
            self.probeHostMaxLength = 'probeHostMaxLength'
            self.probeMimeTypeMaxLength = 'probeMimeTypeMaxLength'
            self.probeBrowserMaxLength = 'probeBrowserMaxLength'
            self.probeTCPTableSize = 'probeTCPTableSize'
            self.probeHTTPTableSize = 'probeHTTPTableSize'
            self.nMSDstIpAddr = 'nMSDstIpAddr'
            self.protocolsDiscoveryAgingTime = 'protocolsDiscoveryAgingTime'
            self.defaultGatewayClassificatiomMode = 'defaultGatewayClassificatiomMode'

        def __call__(self):
            return 'RsStatistics'

    class RsDebugFileRamEntry:
        def __init__(self):
            self.size = 'size'
            self.pathSecret = 'pathSecret'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsDebugFileRamEntry'

    class RsMLBNatEntry:
        def __init__(self):
            self.status = 'status'
            self.mode = 'mode'
            self.fromLclAddress = 'fromLclAddress'
            self.toLclAddress = 'toLclAddress'
            self.routerAddress = 'routerAddress'
            self.address = 'address'

        def __call__(self):
            return 'RsMLBNatEntry'

    class RsIDSReportDataAddressEntry:
        def __init__(self):
            self.status = 'status'
            self.rsIDSReportDataAddress = 'rsIDSReportDataAddress'

        def __call__(self):
            return 'RsIDSReportDataAddressEntry'

    class RsIpZeroHopRouting:
        def __init__(self):
            self.rsIpZhrGeneralStatus = 'rsIpZhrGeneralStatus'
            self.rsIpZhrAgingTimeout = 'rsIpZhrAgingTimeout'

        def __call__(self):
            return 'RsIpZeroHopRouting'

    class VirtualLanPortEntry:
        def __init__(self):
            self.vLPortType = 'vLPortType'
            self.vLPortStatus = 'vLPortStatus'
            self.vLIfIndex = 'vLIfIndex'
            self.vLPortIfIndex = 'vLPortIfIndex'

        def __call__(self):
            return 'VirtualLanPortEntry'

    class RsStpPortEntry:
        def __init__(self):
            self.vlanId = 'vlanId'
            self.priority = 'priority'
            self.pathCost = 'pathCost'
            self.modeFast = 'modeFast'
            self.enabled = 'enabled'
            self.state = 'state'
            self.role = 'role'
            self.id = 'id'

        def __call__(self):
            return 'RsStpPortEntry'

    class RsBWMPhysicalPortGroupEntry:
        def __init__(self):
            self.operationStatus = 'operationStatus'
            self.name = 'name'
            self.port = 'port'

        def __call__(self):
            return 'RsBWMPhysicalPortGroupEntry'

    class RsBWMPolicyGroupCurrentEntry:
        def __init__(self):
            self.name = 'name'

        def __call__(self):
            return 'RsBWMPolicyGroupCurrentEntry'

    class SnmpTargetObjects:
        def __init__(self):
            self.snmpTargetSpinLock = 'snmpTargetSpinLock'
            self.snmpUnavailableContexts = 'snmpUnavailableContexts'
            self.snmpUnknownContexts = 'snmpUnknownContexts'

        def __call__(self):
            return 'SnmpTargetObjects'

    class RsDnsProtDynamicStateTwoEntry:
        def __init__(self):
            self.anyTypeFlag = 'anyTypeFlag'
            self.typeThreshold = 'typeThreshold'
            self.valThreshold = 'valThreshold'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'

        def __call__(self):
            return 'RsDnsProtDynamicStateTwoEntry'

    class RsNetPortUtilizationEntry:
        def __init__(self):
            self.inUtil = 'inUtil'
            self.outUtil = 'outUtil'
            self.index = 'index'

        def __call__(self):
            return 'RsNetPortUtilizationEntry'

    class RspRadiusNasEntry:
        def __init__(self):
            self.secret = 'secret'
            self.nasrowStatus = 'nasrowStatus'
            self.ip = 'ip'

        def __call__(self):
            return 'RspRadiusNasEntry'

    class RsWSDNTCheckEntry:
        def __init__(self):
            self.wSDNTFrequentCheckPeriod = 'wSDNTFrequentCheckPeriod'
            self.wSDNTOpenSessionsWeight = 'wSDNTOpenSessionsWeight'
            self.wSDNTIncomingTrafficWeight = 'wSDNTIncomingTrafficWeight'
            self.wSDNTOutgoingTrafficWeight = 'wSDNTOutgoingTrafficWeight'
            self.wSDNTRegularCheckPeriod = 'wSDNTRegularCheckPeriod'
            self.wSDNTAvResponseWeight = 'wSDNTAvResponseWeight'
            self.wSDNTUsersLimitWeight = 'wSDNTUsersLimitWeight'
            self.wSDNTTCPLimitWeight = 'wSDNTTCPLimitWeight'
            self.wSDNTRetries = 'wSDNTRetries'
            self.wSDNTCommunity = 'wSDNTCommunity'
            self.wSDNTSerialNum = 'wSDNTSerialNum'

        def __call__(self):
            return 'RsWSDNTCheckEntry'

    class RsNewBlackListEntry:
        def __init__(self):
            self.srcNetwork = 'srcNetwork'
            self.dstNetwork = 'dstNetwork'
            self.srcPortGroup = 'srcPortGroup'
            self.dstPortGroup = 'dstPortGroup'
            self.physicalPort = 'physicalPort'
            self.vLANTag = 'vLANTag'
            self.protocol = 'protocol'
            self.state = 'state'
            self.direction = 'direction'
            self.action = 'action'
            self.reportAction = 'reportAction'
            self.description = 'description'
            self.status = 'status'
            self.expirationHour = 'expirationHour'
            self.expirationMinute = 'expirationMinute'
            self.cDBExpirationTime = 'cDBExpirationTime'
            self.detector = 'detector'
            self.detectorSecurityModule = 'detectorSecurityModule'
            self.dynamicState = 'dynamicState'
            self.packetReport = 'packetReport'
            self.name = 'name'

        def __call__(self):
            return 'RsNewBlackListEntry'

    class RsStatisticsProtocolPortsTuning:
        def __init__(self):
            self.rsStatisticsProtocolPortsEntries = 'rsStatisticsProtocolPortsEntries'
            self.rsStatisticsProtocolPortsEntriesAfterReset = 'rsStatisticsProtocolPortsEntriesAfterReset'

        def __call__(self):
            return 'RsStatisticsProtocolPortsTuning'

    class RsSESSIONSynProtectionRqstsTuning:
        def __init__(self):
            self.rsSESSIONSynProtectionRqstsEntries = 'rsSESSIONSynProtectionRqstsEntries'
            self.rsSESSIONSynProtectionRqstsEntriesAfterReset = 'rsSESSIONSynProtectionRqstsEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSynProtectionRqstsTuning'

    class RsStatefulProfileEntry:
        def __init__(self):
            self.status = 'status'
            self.actThreshold = 'actThreshold'
            self.termThreshold = 'termThreshold'
            self.synAckAllow = 'synAckAllow'
            self.packetTraceStatus = 'packetTraceStatus'
            self.packetReportStatus = 'packetReportStatus'
            self.risk = 'risk'
            self.action = 'action'
            self.name = 'name'

        def __call__(self):
            return 'RsStatefulProfileEntry'

    class RsWSDStaticForwardingEntry:
        def __init__(self):
            self.destinationPort = 'destinationPort'
            self.portOperation = 'portOperation'
            self.status = 'status'
            self.failureMode = 'failureMode'
            self.inPort = 'inPort'
            self.sourcePort = 'sourcePort'

        def __call__(self):
            return 'RsWSDStaticForwardingEntry'

    class RsIDSSignaturesProfilesEntry:
        def __init__(self):
            self.type = 'type'
            self.ruleAttributeTypeId = 'ruleAttributeTypeId'
            self.ruleAttributeValue = 'ruleAttributeValue'
            self.status = 'status'
            self.name = 'name'
            self.ruleName = 'ruleName'
            self.ruleAttributeType = 'ruleAttributeType'
            self.ruleAttributeName = 'ruleAttributeName'

        def __call__(self):
            return 'RsIDSSignaturesProfilesEntry'

    class RsWSDApplicationMirrorEntry:
        def __init__(self):
            self.wSDMirrorActiveStatus = 'wSDMirrorActiveStatus'
            self.wSDMirrorActiveAddress = 'wSDMirrorActiveAddress'

        def __call__(self):
            return 'RsWSDApplicationMirrorEntry'

    class RsBWMContentTuning:
        def __init__(self):
            self.rsBWMContentEntries = 'rsBWMContentEntries'
            self.rsBWMContentEntriesAfterReset = 'rsBWMContentEntriesAfterReset'

        def __call__(self):
            return 'RsBWMContentTuning'

    class RsBWMACLActualPolicyEntry:
        def __init__(self):
            self.index = 'index'
            self.description = 'description'
            self.destination = 'destination'
            self.source = 'source'
            self.service = 'service'
            self.vLANTagGroup = 'vLANTagGroup'
            self.portGroup = 'portGroup'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.action = 'action'
            self.protocol = 'protocol'
            self.icmpFlags = 'icmpFlags'
            self.classificationPoint = 'classificationPoint'
            self.operationalStatus = 'operationalStatus'
            self.packetReportStatus = 'packetReportStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMACLActualPolicyEntry'

    class RdwrDPPassiveSSLPortEntry:
        def __init__(self):
            self.sSLAcceleratorPort = 'sSLAcceleratorPort'
            self.status = 'status'
            self.sSLSourcePort = 'sSLSourcePort'

        def __call__(self):
            return 'RdwrDPPassiveSSLPortEntry'

    class RsMLBMaxAllNatEntriesTuning:
        def __init__(self):
            self.rsMLBMaxAllNatEntries = 'rsMLBMaxAllNatEntries'
            self.rsMLBMaxAllNatEntriesAfterReset = 'rsMLBMaxAllNatEntriesAfterReset'

        def __call__(self):
            return 'RsMLBMaxAllNatEntriesTuning'

    class RsCPUserNamePromptEntry:
        def __init__(self):
            self.status = 'status'
            self.dispString = 'dispString'

        def __call__(self):
            return 'RsCPUserNamePromptEntry'

    class RndFACS:
        def __init__(self):
            self.rndFACSDefaultAction = 'rndFACSDefaultAction'

        def __call__(self):
            return 'RndFACS'

    class RsMLBPhysicalIDSServerEntry:
        def __init__(self):
            self.attachedUsersNumber = 'attachedUsersNumber'
            self.peakLoad = 'peakLoad'
            self.framesRate = 'framesRate'
            self.framesLoad = 'framesLoad'
            self.connectionLimit = 'connectionLimit'
            self.peakBytesLoad = 'peakBytesLoad'
            self.recoveryTime = 'recoveryTime'
            self.warmUpTime = 'warmUpTime'
            self.bytesRate = 'bytesRate'
            self.bytesLoad = 'bytesLoad'
            self.bytesLimit = 'bytesLimit'
            self.status = 'status'
            self.adminStatus = 'adminStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBPhysicalIDSServerEntry'

    class SnmpTrap:
        def __init__(self):
            self.snmpTrapOID = 'snmpTrapOID'
            self.snmpTrapEnterprise = 'snmpTrapEnterprise'

        def __call__(self):
            return 'SnmpTrap'

    class RsWSDWebParams:
        def __init__(self):
            self.rsWSDWebPort = 'rsWSDWebPort'
            self.rsWSDWebStatus = 'rsWSDWebStatus'
            self.rsWSDWebHelpLocation = 'rsWSDWebHelpLocation'
            self.rsWSDWebSSLPort = 'rsWSDWebSSLPort'
            self.rsWSDWebSSLStatus = 'rsWSDWebSSLStatus'
            self.rsWSDWebSSLPrivateKeyFile = 'rsWSDWebSSLPrivateKeyFile'
            self.rsWSDWebSSLCertificateFile = 'rsWSDWebSSLCertificateFile'
            self.rsWSDWebSSLCaFile = 'rsWSDWebSSLCaFile'
            self.rsWSDWebSSLCaPath = 'rsWSDWebSSLCaPath'
            self.rsWSDWebSSLClientAuthentication = 'rsWSDWebSSLClientAuthentication'
            self.rsWSDWebAccessLevel = 'rsWSDWebAccessLevel'
            self.rsWSDWebSoapSupportStatus = 'rsWSDWebSoapSupportStatus'
            self.rsWSDWebSSLWeakCiphersSupportStatus = 'rsWSDWebSSLWeakCiphersSupportStatus'

        def __call__(self):
            return 'RsWSDWebParams'

    class SnmpNotifyFilterEntry:
        def __init__(self):
            self.mask = 'mask'
            self.type = 'type'
            self.storageType = 'storageType'
            self.rowStatus = 'rowStatus'
            self.profileName = 'profileName'
            self.subtree = 'subtree'

        def __call__(self):
            return 'SnmpNotifyFilterEntry'

    class SnmpMPDStats:
        def __init__(self):
            self.snmpUnknownSecurityModels = 'snmpUnknownSecurityModels'
            self.snmpInvalidMsgs = 'snmpInvalidMsgs'
            self.snmpUnknownPDUHandlers = 'snmpUnknownPDUHandlers'

        def __call__(self):
            return 'SnmpMPDStats'

    class RndMibFileEntry:
        def __init__(self):
            self.path = 'path'
            self.refresh = 'refresh'
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'RndMibFileEntry'

    class RdwrConfigurationSyncMonitor:
        def __init__(self):
            self.rdwrConfSyncState = 'rdwrConfSyncState'
            self.rdwrConfSyncIP = 'rdwrConfSyncIP'
            self.rdwrConfSyncPeerIP = 'rdwrConfSyncPeerIP'
            self.rdwrConfSyncPeerBaseMac = 'rdwrConfSyncPeerBaseMac'
            self.rdwrConfSyncIncompatibilityReason = 'rdwrConfSyncIncompatibilityReason'
            self.rdwrConfSyncLastConfSyncTime = 'rdwrConfSyncLastConfSyncTime'
            self.rdwrConfSyncLastConfFullSyncTime = 'rdwrConfSyncLastConfFullSyncTime'
            self.rdwrConfSyncNumOfFullSyncOperations = 'rdwrConfSyncNumOfFullSyncOperations'
            self.rdwrConfSyncNumOfSyncOperations = 'rdwrConfSyncNumOfSyncOperations'
            self.rdwrConfSyncNumOfFailedSyncAttempts = 'rdwrConfSyncNumOfFailedSyncAttempts'
            self.rdwrConfSyncPeerConfigVersion = 'rdwrConfSyncPeerConfigVersion'
            self.rdwrConfSyncConfigTimestamp = 'rdwrConfSyncConfigTimestamp'
            self.rdwrConfSyncResetStatistics = 'rdwrConfSyncResetStatistics'
            self.rdwrConfSyncShouldReboot = 'rdwrConfSyncShouldReboot'
            self.rdwrConfSyncNumOfConnects = 'rdwrConfSyncNumOfConnects'
            self.rdwrConfSyncNumOfDisconnects = 'rdwrConfSyncNumOfDisconnects'
            self.rdwrConfSyncIPString = 'rdwrConfSyncIPString'
            self.rdwrConfSyncPeerIPString = 'rdwrConfSyncPeerIPString'

        def __call__(self):
            return 'RdwrConfigurationSyncMonitor'

    class RsSESSIONSynStatisticsEntry:
        def __init__(self):
            self.currentAttackStatus = 'currentAttackStatus'
            self.lastSecSynCount = 'lastSecSynCount'
            self.lastSecGoodCount = 'lastSecGoodCount'
            self.averageSynCount = 'averageSynCount'
            self.averageGoodCount = 'averageGoodCount'
            self.peakSynCount = 'peakSynCount'
            self.peakGoodCount = 'peakGoodCount'
            self.activityTime = 'activityTime'
            self.lastAttackStartTime = 'lastAttackStartTime'
            self.lastAttackTermTime = 'lastAttackTermTime'
            self.policy = 'policy'
            self.ip = 'ip'
            self.port = 'port'
            self.rxPort = 'rxPort'

        def __call__(self):
            return 'RsSESSIONSynStatisticsEntry'

    class RsMLBMaxTrackNHRTableEntriesTuning:
        def __init__(self):
            self.rsMLBMaxTrackNHRTableSize = 'rsMLBMaxTrackNHRTableSize'
            self.rsMLBMaxTrackNHRTableSizeAfterReset = 'rsMLBMaxTrackNHRTableSizeAfterReset'

        def __call__(self):
            return 'RsMLBMaxTrackNHRTableEntriesTuning'

    class RsIDSServProtection:
        def __init__(self):
            self.rsIDSServProtCntTableSize = 'rsIDSServProtCntTableSize'
            self.rsIDSServProtCntTableSizeAfterReset = 'rsIDSServProtCntTableSizeAfterReset'
            self.rsIDSServProtSipTrackingType = 'rsIDSServProtSipTrackingType'
            self.rsIDSServProtSipResetCode = 'rsIDSServProtSipResetCode'
            self.rsIDSServProtSipServerOrig = 'rsIDSServProtSipServerOrig'
            self.rsIDSServProtSipEnableURIinTCP = 'rsIDSServProtSipEnableURIinTCP'

        def __call__(self):
            return 'RsIDSServProtection'

    class RsExportPolicyEntry:
        def __init__(self):
            self.configuration = 'configuration'
            self.baselineBdos = 'baselineBdos'
            self.baselineDns = 'baselineDns'
            self.name = 'name'

        def __call__(self):
            return 'RsExportPolicyEntry'

    class RsAPMCurrentMonitorEntry:
        def __init__(self):
            self.type = 'type'
            self.farmID = 'farmID'
            self.directionOrientation = 'directionOrientation'
            self.itemsToCollect = 'itemsToCollect'
            self.policyID = 'policyID'
            self.id = 'id'

        def __call__(self):
            return 'RsAPMCurrentMonitorEntry'

    class RsMLBPriceEntry:
        def __init__(self):
            self.method = 'method'
            self.bWUnit = 'bWUnit'
            self.price = 'price'
            self.status = 'status'
            self.levelPrcnt = 'levelPrcnt'
            self.nHRAddr = 'nHRAddr'
            self.threshold = 'threshold'

        def __call__(self):
            return 'RsMLBPriceEntry'

    class IfRcvAddressEntry:
        def __init__(self):
            self.status = 'status'
            self.type = 'type'
            self.index = 'index'
            self.address = 'address'

        def __call__(self):
            return 'IfRcvAddressEntry'

    class RsMLBPrxyCheckFPIPEntry:
        def __init__(self):
            self.mLBFPIPAddr = 'mLBFPIPAddr'
            self.fPIPStatus = 'fPIPStatus'
            self.mLBRouterAddr = 'mLBRouterAddr'

        def __call__(self):
            return 'RsMLBPrxyCheckFPIPEntry'

    class IpCidrRouteEntry:
        def __init__(self):
            self.ifIndex = 'ifIndex'
            self.type = 'type'
            self.proto = 'proto'
            self.age = 'age'
            self.info = 'info'
            self.nextHopAS = 'nextHopAS'
            self.metric1 = 'metric1'
            self.metric2 = 'metric2'
            self.metric3 = 'metric3'
            self.metric4 = 'metric4'
            self.metric5 = 'metric5'
            self.status = 'status'
            self.dest = 'dest'
            self.mask = 'mask'
            self.tos = 'tos'
            self.nextHop = 'nextHop'

        def __call__(self):
            return 'IpCidrRouteEntry'

    class RsMaxIpxForwardingEntriesTuning:
        def __init__(self):
            self.rsMaxIpxFrwEntries = 'rsMaxIpxFrwEntries'
            self.rsMaxIpxFrwEntriesAfterReset = 'rsMaxIpxFrwEntriesAfterReset'

        def __call__(self):
            return 'RsMaxIpxForwardingEntriesTuning'

    class RsMLBNoNatEntry:
        def __init__(self):
            self.status = 'status'
            self.fromLclServerAddress = 'fromLclServerAddress'
            self.toLclServerAddress = 'toLclServerAddress'
            self.portNumber = 'portNumber'
            self.routerAddress = 'routerAddress'

        def __call__(self):
            return 'RsMLBNoNatEntry'

    class RsIDSSLTProfilesEntry:
        def __init__(self):
            self.category = 'category'
            self.status = 'status'
            self.serviceId = 'serviceId'
            self.type = 'type'
            self.name = 'name'
            self.serviceName = 'serviceName'

        def __call__(self):
            return 'RsIDSSLTProfilesEntry'

    class RsSSLCertificateImportExport:
        def __init__(self):
            self.rsSSLCertificateImportExportEntryName = 'rsSSLCertificateImportExportEntryName'
            self.rsSSLCertificateImportExportFileName = 'rsSSLCertificateImportExportFileName'
            self.rsSSLCertificateImportExportPassphrase = 'rsSSLCertificateImportExportPassphrase'
            self.rsSSLCertificateImportExportAction = 'rsSSLCertificateImportExportAction'

        def __call__(self):
            return 'RsSSLCertificateImportExport'

    class SnmpTargetAddrEntry:
        def __init__(self):
            self.tDomain = 'tDomain'
            self.tAddress = 'tAddress'
            self.timeout = 'timeout'
            self.retryCount = 'retryCount'
            self.tagList = 'tagList'
            self.params = 'params'
            self.storageType = 'storageType'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'SnmpTargetAddrEntry'

    class IpRedundancy:
        def __init__(self):
            self.ipRedundAdminStatus = 'ipRedundAdminStatus'
            self.ipRedundOperStatus = 'ipRedundOperStatus'
            self.rdwrRedunForceDownPorts = 'rdwrRedunForceDownPorts'

        def __call__(self):
            return 'IpRedundancy'

    class RsMLBNHRPriceDailyStatisticsEntry:
        def __init__(self):
            self.levelPrcnt = 'levelPrcnt'
            self.status = 'status'
            self.month = 'month'
            self.day = 'day'
            self.nHRAddr = 'nHRAddr'
            self.threshold = 'threshold'

        def __call__(self):
            return 'RsMLBNHRPriceDailyStatisticsEntry'

    class RsIDSynSSLMitigationAlteonPortsEntry:
        def __init__(self):
            self.inboundPort = 'inboundPort'
            self.outboundPort = 'outboundPort'
            self.index = 'index'

        def __call__(self):
            return 'RsIDSynSSLMitigationAlteonPortsEntry'

    class RsDeletePolicyEntry:
        def __init__(self):
            self.update = 'update'
            self.name = 'name'

        def __call__(self):
            return 'RsDeletePolicyEntry'

    class RdwrDefCfg:
        def __init__(self):
            self.rdwrDefCfgIpAddress = 'rdwrDefCfgIpAddress'
            self.rdwrDefCfgIpMask = 'rdwrDefCfgIpMask'
            self.rdwrDefCfgPort = 'rdwrDefCfgPort'
            self.rdwrDefCfgGateway = 'rdwrDefCfgGateway'
            self.rdwrDefCfgUserName = 'rdwrDefCfgUserName'
            self.rdwrDefCfgUserPassword = 'rdwrDefCfgUserPassword'
            self.rdwrDefCfgCommunity = 'rdwrDefCfgCommunity'

        def __call__(self):
            return 'RdwrDefCfg'

    class RsBWMCurrentRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.action = 'action'
            self.direction = 'direction'
            self.priority = 'priority'
            self.physicalPort = 'physicalPort'
            self.type = 'type'
            self.description = 'description'
            self.guaranteedBW = 'guaranteedBW'
            self.maxBW = 'maxBW'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.dSCPMarking = 'dSCPMarking'
            self.reportBlockedPackets = 'reportBlockedPackets'
            self.specific = 'specific'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.policyGroup = 'policyGroup'
            self.radiusRule = 'radiusRule'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMCurrentRulesEntry'

    class RsIDSAsAttackEntry:
        def __init__(self):
            self.name = 'name'
            self.serviceName = 'serviceName'
            self.serviceType = 'serviceType'
            self.trackingTime = 'trackingTime'
            self.threshold = 'threshold'
            self.trackingType = 'trackingType'
            self.msg = 'msg'
            self.status = 'status'
            self.reportMode = 'reportMode'
            self.sourceType = 'sourceType'
            self.packetReport = 'packetReport'
            self.risk = 'risk'
            self.state = 'state'
            self.direction = 'direction'
            self.suspendAction = 'suspendAction'
            self.dropThreshold = 'dropThreshold'
            self.termThreshold = 'termThreshold'
            self.excludeSrcAddr = 'excludeSrcAddr'
            self.excludeDestAddr = 'excludeDestAddr'
            self.packetTrace = 'packetTrace'
            self.quarantine = 'quarantine'
            self.id = 'id'

        def __call__(self):
            return 'RsIDSAsAttackEntry'

    class RsWSDTelnetParams:
        def __init__(self):
            self.port = 'port'
            self.status = 'status'

        def __call__(self):
            return 'RsWSDTelnetParams'

    class RsMaxBridgeForwardingEntriesTuning:
        def __init__(self):
            self.rsMaxBrgFrwEntries = 'rsMaxBrgFrwEntries'
            self.rsMaxBrgFrwEntriesAfterReset = 'rsMaxBrgFrwEntriesAfterReset'

        def __call__(self):
            return 'RsMaxBridgeForwardingEntriesTuning'

    class RsSSDvirtualLanPortEntry:
        def __init__(self):
            self.sSDvLPortType = 'sSDvLPortType'
            self.sSDvLPortStatus = 'sSDvLPortStatus'
            self.sSDvLPortTag = 'sSDvLPortTag'
            self.sSDvLPortInterfaceGroupingState = 'sSDvLPortInterfaceGroupingState'
            self.sSDvLIfIndex = 'sSDvLIfIndex'
            self.sSDvLPortIfIndex = 'sSDvLPortIfIndex'

        def __call__(self):
            return 'RsSSDvirtualLanPortEntry'

    class RdwrDPTunnelMonEntry:
        def __init__(self):
            self.primStatus = 'primStatus'
            self.scndStatus = 'scndStatus'
            self.rowStatus = 'rowStatus'
            self.ip = 'ip'

        def __call__(self):
            return 'RdwrDPTunnelMonEntry'

    class RsNetFloodBypassTcpSynEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassTcpSynEntry'

    class RdwrDPRoutingVifEntry:
        def __init__(self):
            self._interface = '_interface'
            self.mac = 'mac'
            self.ip = 'ip'
            self.mask = 'mask'
            self.vlanType = 'vlanType'
            self.vlanTag = 'vlanTag'
            self.adminStatus = 'adminStatus'
            self.operStatus = 'operStatus'
            self.rowStatus = 'rowStatus'
            self.index = 'index'

        def __call__(self):
            return 'RdwrDPRoutingVifEntry'

    class RsDebugFileFlashEntry:
        def __init__(self):
            self.size = 'size'
            self.pathSecret = 'pathSecret'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsDebugFileFlashEntry'

    class RdwrConfigurationSyncConf:
        def __init__(self):
            self.rdwrConfSyncMode = 'rdwrConfSyncMode'
            self.rdwrConfSyncRetryTimeout = 'rdwrConfSyncRetryTimeout'
            self.rdwrConfSyncKeepAlivePeriod = 'rdwrConfSyncKeepAlivePeriod'
            self.rdwrConfSyncRebootTimeout = 'rdwrConfSyncRebootTimeout'
            self.rdwrConfSyncPeerDiscTrapDelay = 'rdwrConfSyncPeerDiscTrapDelay'
            self.rdwrConfSyncPeerResponseTimeout = 'rdwrConfSyncPeerResponseTimeout'
            self.rdwrConfSyncMasterActivityTimeout = 'rdwrConfSyncMasterActivityTimeout'
            self.rdwrConfSyncAllowRebootActiveDevice = 'rdwrConfSyncAllowRebootActiveDevice'
            self.rdwrConfSyncRebootSlave = 'rdwrConfSyncRebootSlave'
            self.rdwrConfSyncExcludeMgmtIP = 'rdwrConfSyncExcludeMgmtIP'
            self.rdwrConfSyncExcludeMgmtCert = 'rdwrConfSyncExcludeMgmtCert'
            self.rdwrConfSyncFullSyncDelay = 'rdwrConfSyncFullSyncDelay'
            self.rdwrConfSyncFullSyncMaxDelay = 'rdwrConfSyncFullSyncMaxDelay'
            self.rdwrConfSyncCommunicationPassword = 'rdwrConfSyncCommunicationPassword'
            self.rdwrConfSyncConnectionPreference = 'rdwrConfSyncConnectionPreference'
            self.rdwrConfSyncAlternateConnectionPreference = 'rdwrConfSyncAlternateConnectionPreference'
            self.rdwrConfSyncReconnect = 'rdwrConfSyncReconnect'

        def __call__(self):
            return 'RdwrConfigurationSyncConf'

    class RsDebugPoliciesTuning:
        def __init__(self):
            self.rsDEBUGPolicyEntries = 'rsDEBUGPolicyEntries'
            self.rsDEBUGPolicyEntriesAfterReset = 'rsDEBUGPolicyEntriesAfterReset'

        def __call__(self):
            return 'RsDebugPoliciesTuning'

    class IcmpSpec:
        def __init__(self):
            self.rsIcmpGenErrMsgEnable = 'rsIcmpGenErrMsgEnable'

        def __call__(self):
            return 'IcmpSpec'

    class RdwrDayLightSaving:
        def __init__(self):
            self.rdwrDayLightSavingBegins = 'rdwrDayLightSavingBegins'
            self.rdwrDayLightSavingEnds = 'rdwrDayLightSavingEnds'
            self.rdwrDayLightSavingTimeDesignations = 'rdwrDayLightSavingTimeDesignations'
            self.rdwrDayLightSavingAdminStatus = 'rdwrDayLightSavingAdminStatus'
            self.rdwrDayLightSavingBeginDate = 'rdwrDayLightSavingBeginDate'
            self.rdwrDayLightSavingEndDate = 'rdwrDayLightSavingEndDate'
            self.rdwrDayLightSavingDelta = 'rdwrDayLightSavingDelta'

        def __call__(self):
            return 'RdwrDayLightSaving'

    class RsIDSSLTtrackingEntry:
        def __init__(self):
            self.iDSSLTAlertThreshold = 'iDSSLTAlertThreshold'
            self.iDSSLTActiveThreshold = 'iDSSLTActiveThreshold'
            self.iDSSLTDropThreshold = 'iDSSLTDropThreshold'
            self.iDSSLTTermAlertThreshold = 'iDSSLTTermAlertThreshold'
            self.iDSSLTTermThreshold = 'iDSSLTTermThreshold'
            self.iDSSLTAgingPeriod = 'iDSSLTAgingPeriod'
            self.iDSSLTObjectID = 'iDSSLTObjectID'
            self.iDSSLTAttackState = 'iDSSLTAttackState'
            self.iDSSLTMsg = 'iDSSLTMsg'
            self.iDSSLTStatus = 'iDSSLTStatus'
            self.iDSSLTReportMode = 'iDSSLTReportMode'
            self.iDSSLTRisk = 'iDSSLTRisk'
            self.iDSSLTFilterGroupName = 'iDSSLTFilterGroupName'

        def __call__(self):
            return 'RsIDSSLTtrackingEntry'

    class RsAPMCurrentLegFarmEntry:
        def __init__(self):
            self.farmID = 'farmID'
            self.policyID = 'policyID'
            self.index = 'index'

        def __call__(self):
            return 'RsAPMCurrentLegFarmEntry'

    class RsIDSFPRiskAttackEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.simulationDuration = 'simulationDuration'
            self.simulationAction = 'simulationAction'
            self.simulationStopAtAttackEnd = 'simulationStopAtAttackEnd'
            self.stabilizationDuration = 'stabilizationDuration'
            self.simulationStartWhenSigChange = 'simulationStartWhenSigChange'
            self.jointDistributionStatus = 'jointDistributionStatus'
            self.simulationStop = 'simulationStop'
            self.simulationStatus = 'simulationStatus'
            self.attackStatus = 'attackStatus'
            self.simulationRunTime = 'simulationRunTime'
            self.simulationType = 'simulationType'
            self.type = 'type'
            self.reportIdTime = 'reportIdTime'
            self.reportIdCounter = 'reportIdCounter'

        def __call__(self):
            return 'RsIDSFPRiskAttackEntry'

    class RdwrDPOverload:
        def __init__(self):
            self.rsOverloadMechanismCongestionStatus = 'rsOverloadMechanismCongestionStatus'
            self.rsOverloadThresholdsDefault = 'rsOverloadThresholdsDefault'

        def __call__(self):
            return 'RdwrDPOverload'

    class RsMLBChainActionEntry:
        def __init__(self):
            self.index = 'index'
            self.status = 'status'
            self.chainName = 'chainName'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBChainActionEntry'

    class RdwrConfigurationFileEntry:
        def __init__(self):
            self.running = 'running'
            self.installed = 'installed'
            self.path = 'path'
            self.action = 'action'
            self.status = 'status'
            self.app = 'app'
            self.name = 'name'

        def __call__(self):
            return 'RdwrConfigurationFileEntry'

    class RsSESSIONDisplayFilterEntry:
        def __init__(self):
            self.srcIP = 'srcIP'
            self.srcIPMask = 'srcIPMask'
            self.dstIP = 'dstIP'
            self.dstIPMask = 'dstIPMask'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.physicalPort = 'physicalPort'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsSESSIONDisplayFilterEntry'

    class Dot3adAggPortListEntry:
        def __init__(self):
            self.ports = 'ports'
            self.index = 'index'

        def __call__(self):
            return 'Dot3adAggPortListEntry'

    class RsIcmpRdEntry:
        def __init__(self):
            self.ipAdvertAddr = 'ipAdvertAddr'
            self.maxAdvertInterval = 'maxAdvertInterval'
            self.minAdvertInterval = 'minAdvertInterval'
            self.advertLifetime = 'advertLifetime'
            self.advertise = 'advertise'
            self.preferenceLevel = 'preferenceLevel'
            self.entStatus = 'entStatus'
            self.ipAddr = 'ipAddr'

        def __call__(self):
            return 'RsIcmpRdEntry'

    class RsDnsServerStaticResEntry:
        def __init__(self):
            self.sIp = 'sIp'
            self.sEnable = 'sEnable'
            self.srowStatus = 'srowStatus'
            self.sUrl = 'sUrl'

        def __call__(self):
            return 'RsDnsServerStaticResEntry'

    class RsSESSIONFilterEntry:
        def __init__(self):
            self.srcIP = 'srcIP'
            self.srcIPMask = 'srcIPMask'
            self.dstIP = 'dstIP'
            self.dstIPMask = 'dstIPMask'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.physicalPort = 'physicalPort'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsSESSIONFilterEntry'

    class RsHWCoreUtilizationEntry:
        def __init__(self):
            self.value = 'value'
            self.index = 'index'

        def __call__(self):
            return 'RsHWCoreUtilizationEntry'

    class RsExportServerEntry:
        def __init__(self):
            self.configuration = 'configuration'
            self.baselineHttp = 'baselineHttp'
            self.name = 'name'

        def __call__(self):
            return 'RsExportServerEntry'

    class RsBWMCurrentChainRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.direction = 'direction'
            self.description = 'description'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.specific = 'specific'
            self.bandwidthLastSec = 'bandwidthLastSec'
            self.packetsLastSec = 'packetsLastSec'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.dSCPMarking = 'dSCPMarking'
            self.radiusRule = 'radiusRule'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMCurrentChainRulesEntry'

    class RsErrMailParams:
        def __init__(self):
            self.rsErrMailEnable = 'rsErrMailEnable'
            self.rsErrMailGateway = 'rsErrMailGateway'
            self.rsErrMailSrcAddress = 'rsErrMailSrcAddress'
            self.rsErrMailToFieldText = 'rsErrMailToFieldText'

        def __call__(self):
            return 'RsErrMailParams'

    class RsMaxArpEntriesTuning:
        def __init__(self):
            self.rsMaxArpEntries = 'rsMaxArpEntries'
            self.rsMaxArpEntriesAfterReset = 'rsMaxArpEntriesAfterReset'

        def __call__(self):
            return 'RsMaxArpEntriesTuning'

    class RsIDSSignaturesRuleAttackListEntry:
        def __init__(self):
            self.attackName = 'attackName'
            self.status = 'status'
            self.profileName = 'profileName'
            self.ruleName = 'ruleName'
            self.attackID = 'attackID'

        def __call__(self):
            return 'RsIDSSignaturesRuleAttackListEntry'

    class RsBWMSessionTuning:
        def __init__(self):
            self.rsBWMSessionEntries = 'rsBWMSessionEntries'
            self.rsBWMSessionEntriesAfterReset = 'rsBWMSessionEntriesAfterReset'

        def __call__(self):
            return 'RsBWMSessionTuning'

    class RsIDSSynPolicyEntry:
        def __init__(self):
            self.profileName = 'profileName'
            self.source = 'source'
            self.destination = 'destination'
            self.direction = 'direction'
            self.portmask = 'portmask'
            self.state = 'state'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSynPolicyEntry'

    class RsIDSQuarantineTableAction:
        def __init__(self):
            self.actionType = 'actionType'
            self.actionRedirect = 'actionRedirect'
            self.actionMetadata = 'actionMetadata'
            self.actionTimeoutHour = 'actionTimeoutHour'
            self.actionTimeoutMin = 'actionTimeoutMin'
            self.actionStatus = 'actionStatus'
            self.actionPolicyName = 'actionPolicyName'

        def __call__(self):
            return 'RsIDSQuarantineTableAction'

    class RsTacacsServer:
        def __init__(self):
            self.rsTacacsPrimaryServerAddr = 'rsTacacsPrimaryServerAddr'
            self.rsTacacsPrimaryServerSecret = 'rsTacacsPrimaryServerSecret'
            self.rsTacacsPrimaryServerPort = 'rsTacacsPrimaryServerPort'
            self.rsTacacsSecondaryServerAddr = 'rsTacacsSecondaryServerAddr'
            self.rsTacacsSecondaryServerSecret = 'rsTacacsSecondaryServerSecret'
            self.rsTacacsSecondaryServerPort = 'rsTacacsSecondaryServerPort'
            self.rsTacacsServerRetries = 'rsTacacsServerRetries'
            self.rsTacacsServerTimeout = 'rsTacacsServerTimeout'
            self.rsTacacsCommandLoggingStatus = 'rsTacacsCommandLoggingStatus'
            self.rsTacacsCommandAuthorizationStatus = 'rsTacacsCommandAuthorizationStatus'
            self.rsTacacsClientAging = 'rsTacacsClientAging'

        def __call__(self):
            return 'RsTacacsServer'

    class Dot3adAggPortEntry:
        def __init__(self):
            self.actorSystemPriority = 'actorSystemPriority'
            self.actorSystemID = 'actorSystemID'
            self.actorAdminKey = 'actorAdminKey'
            self.actorOperKey = 'actorOperKey'
            self.partnerAdminSystemPriority = 'partnerAdminSystemPriority'
            self.partnerOperSystemPriority = 'partnerOperSystemPriority'
            self.partnerAdminSystemID = 'partnerAdminSystemID'
            self.partnerOperSystemID = 'partnerOperSystemID'
            self.partnerAdminKey = 'partnerAdminKey'
            self.partnerOperKey = 'partnerOperKey'
            self.selectedAggID = 'selectedAggID'
            self.attachedAggID = 'attachedAggID'
            self.actorPort = 'actorPort'
            self.actorPortPriority = 'actorPortPriority'
            self.partnerAdminPort = 'partnerAdminPort'
            self.partnerOperPort = 'partnerOperPort'
            self.partnerAdminPortPriority = 'partnerAdminPortPriority'
            self.partnerOperPortPriority = 'partnerOperPortPriority'
            self.actorAdminState = 'actorAdminState'
            self.actorOperState = 'actorOperState'
            self.partnerAdminState = 'partnerAdminState'
            self.partnerOperState = 'partnerOperState'
            self.aggregateOrIndividual = 'aggregateOrIndividual'
            self.index = 'index'

        def __call__(self):
            return 'Dot3adAggPortEntry'

    class RsServerDispatcher:
        def __init__(self):
            self.rsWSDNewEntryOnSourcePort = 'rsWSDNewEntryOnSourcePort'
            self.rsWSDSelectServerOnSourcePort = 'rsWSDSelectServerOnSourcePort'
            self.rsWSDRedundancyMode = 'rsWSDRedundancyMode'
            self.rsNsdMode = 'rsNsdMode'
            self.rsNsdWINSAddr = 'rsNsdWINSAddr'
            self.rsWSDSyslogStatus = 'rsWSDSyslogStatus'
            self.rsWSDSyslogAddress = 'rsWSDSyslogAddress'
            self.rsWSDDNSResolution = 'rsWSDDNSResolution'
            self.rsIGTransitTimeout = 'rsIGTransitTimeout'
            self.rsWSDUserPassword = 'rsWSDUserPassword'
            self.rsWSDUserVersion = 'rsWSDUserVersion'
            self.rsWSDNatStatus = 'rsWSDNatStatus'
            self.rsWSDRedundancyTakeback = 'rsWSDRedundancyTakeback'
            self.rsWSDClientMirrorPercentage = 'rsWSDClientMirrorPercentage'
            self.rsWSDMirrorStatus = 'rsWSDMirrorStatus'
            self.rsWSDMirrorProtocolMode = 'rsWSDMirrorProtocolMode'
            self.rsWSDClientMirrorPollingTime = 'rsWSDClientMirrorPollingTime'
            self.rsPlatformIdentifier = 'rsPlatformIdentifier'
            self.rsConfigurationIdentifier = 'rsConfigurationIdentifier'
            self.rsSWPasswordStatus = 'rsSWPasswordStatus'
            self.rsWSDFlashSize = 'rsWSDFlashSize'
            self.rsWSDDRAMSize = 'rsWSDDRAMSize'
            self.rsWSDVLANRedundOperStatus = 'rsWSDVLANRedundOperStatus'
            self.rsWSDResourceUtilization = 'rsWSDResourceUtilization'
            self.rsWSDRSResourceUtilization = 'rsWSDRSResourceUtilization'
            self.rsWSDREResourceUtilization = 'rsWSDREResourceUtilization'
            self.rsWSDBuildNumber = 'rsWSDBuildNumber'
            self.rsWSDUseOneTrap = 'rsWSDUseOneTrap'
            self.rsWSDLicense = 'rsWSDLicense'
            self.rsWSDLicenseID = 'rsWSDLicenseID'
            self.rsWSDSendFakeArp = 'rsWSDSendFakeArp'
            self.rsWSDManagementPorts = 'rsWSDManagementPorts'
            self.rsWSDDeviceOperationMode = 'rsWSDDeviceOperationMode'
            self.rsWSDVersionStatus = 'rsWSDVersionStatus'
            self.rsWSDSyslogFacility = 'rsWSDSyslogFacility'
            self.rsWSDBackupInterfaceGrouping = 'rsWSDBackupInterfaceGrouping'
            self.rsRegistrationStatus = 'rsRegistrationStatus'
            self.rsFloatingPacketOffset = 'rsFloatingPacketOffset'
            self.rsPrivateCheckSNMPPort = 'rsPrivateCheckSNMPPort'
            self.rsVlanTagHandling = 'rsVlanTagHandling'
            self.rsWSDSyslogUrl = 'rsWSDSyslogUrl'
            self.rsWSDHardwareLicense = 'rsWSDHardwareLicense'
            self.rsWSDHardwareLicenseID = 'rsWSDHardwareLicenseID'
            self.rsWSDSyslogSourcePort = 'rsWSDSyslogSourcePort'
            self.rsFullMacCompareStatus = 'rsFullMacCompareStatus'
            self.rdwr5SecAvgResourceUtilization = 'rdwr5SecAvgResourceUtilization'
            self.rdwr60SecAvgResourceUtilization = 'rdwr60SecAvgResourceUtilization'
            self.rdwrArpWithInterfaceGroup = 'rdwrArpWithInterfaceGroup'
            self.rdwrDedicatedManagementPort = 'rdwrDedicatedManagementPort'
            self.rsWSDSyslogDestinationPort = 'rsWSDSyslogDestinationPort'
            self.rsPhysPortMirrorThresholdUnits = 'rsPhysPortMirrorThresholdUnits'
            self.rsPhysPortMirrorThresholdInterval = 'rsPhysPortMirrorThresholdInterval'
            self.rsPhysPortMirrorThresholdReset = 'rsPhysPortMirrorThresholdReset'
            self.rsWSDThroughputLicense = 'rsWSDThroughputLicense'
            self.rsWSDThroughputLicenseID = 'rsWSDThroughputLicenseID'
            self.rdwrTemperatureCPU1Get = 'rdwrTemperatureCPU1Get'
            self.rdwrTemperatureCPU2Get = 'rdwrTemperatureCPU2Get'
            self.rdwrTemperatureWarningThresholdGet = 'rdwrTemperatureWarningThresholdGet'
            self.rdwrTemperatureShutdownThresholdGet = 'rdwrTemperatureShutdownThresholdGet'
            self.rdwrTemperatureThresholdStatusCPU1Get = 'rdwrTemperatureThresholdStatusCPU1Get'
            self.rdwrTemperatureThresholdStatusCPU2Get = 'rdwrTemperatureThresholdStatusCPU2Get'
            self.rndNumberOfHD = 'rndNumberOfHD'
            self.rndSSLCardName = 'rndSSLCardName'
            self.rndCompCardName = 'rndCompCardName'
            self.rdwrDualPsuStatus = 'rdwrDualPsuStatus'
            self.rdwrTotalIncomingTrafficPeak = 'rdwrTotalIncomingTrafficPeak'
            self.rsUserLockoutInterval = 'rsUserLockoutInterval'
            self.rdwrManagmentPortsStatus = 'rdwrManagmentPortsStatus'
            self.rsWSDSyslogGlobalStatus = 'rsWSDSyslogGlobalStatus'
            self.rsSendPortUnreachableStatus = 'rsSendPortUnreachableStatus'
            self.rsWSDResourceUtilizationInstance1 = 'rsWSDResourceUtilizationInstance1'
            self.rsWSDREResourceUtilizationInstance1 = 'rsWSDREResourceUtilizationInstance1'
            self.rsWSDRSResourceUtilizationInstance1 = 'rsWSDRSResourceUtilizationInstance1'
            self.rdwr5SecAvgResourceUtilizationInstance1 = 'rdwr5SecAvgResourceUtilizationInstance1'
            self.rdwr60SecAvgResourceUtilizationInstance1 = 'rdwr60SecAvgResourceUtilizationInstance1'

        def __call__(self):
            return 'RsServerDispatcher'

    class RsBWMFarmsClassifyListsTuning:
        def __init__(self):
            self.rsBWMFarmsClassifyListsTuningEntries = 'rsBWMFarmsClassifyListsTuningEntries'
            self.rsBWMFarmsClassifyListsTuningEntriesAfterReset = 'rsBWMFarmsClassifyListsTuningEntriesAfterReset'

        def __call__(self):
            return 'RsBWMFarmsClassifyListsTuning'

    class RsBWMMacGroupTuning:
        def __init__(self):
            self.rsBWMMacGroupEntries = 'rsBWMMacGroupEntries'
            self.rsBWMMacGroupEntriesAfterReset = 'rsBWMMacGroupEntriesAfterReset'

        def __call__(self):
            return 'RsBWMMacGroupTuning'

    class RsBWMCurrentVLANTagGroupEntry:
        def __init__(self):
            self.vLANTagTo = 'vLANTagTo'
            self.mode = 'mode'
            self.name = 'name'
            self.vLANTag = 'vLANTag'
            self.vLANTagFrom = 'vLANTagFrom'

        def __call__(self):
            return 'RsBWMCurrentVLANTagGroupEntry'

    class RsBWMParallelStringSearchMemoryTuning:
        def __init__(self):
            self.rsBWMParallelStringSearchMemory = 'rsBWMParallelStringSearchMemory'
            self.rsBWMParallelStringSearchMemoryAfterReset = 'rsBWMParallelStringSearchMemoryAfterReset'

        def __call__(self):
            return 'RsBWMParallelStringSearchMemoryTuning'

    class RsCCK:
        def __init__(self):
            self.argDelimiter = 'argDelimiter'
            self.nextElementId = 'nextElementId'
            self.nextCheckId = 'nextCheckId'
            self.status = 'status'
            self.loadSamples = 'loadSamples'
            self.certFile = 'certFile'
            self.keyFile = 'keyFile'

        def __call__(self):
            return 'RsCCK'

    class RsBWMCurrentExtRulesEntry:
        def __init__(self):
            self.fromFarm = 'fromFarm'
            self.toFarm = 'toFarm'
            self.classificationPoint = 'classificationPoint'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.maxRqstsPerSec = 'maxRqstsPerSec'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.forceBestFit = 'forceBestFit'
            self.packetMarkingType = 'packetMarkingType'
            self.packetMarkingValue = 'packetMarkingValue'
            self.reportMaxBw = 'reportMaxBw'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMCurrentExtRulesEntry'

    class RdwrDPTunnel:
        def __init__(self):
            self.rdwrDPTunnelMonTotalTunnels = 'rdwrDPTunnelMonTotalTunnels'
            self.rdwrDPTunnelGreKeepaliveInterval = 'rdwrDPTunnelGreKeepaliveInterval'
            self.rdwrDPTunnelGreKeepaliveRetries = 'rdwrDPTunnelGreKeepaliveRetries'

        def __call__(self):
            return 'RdwrDPTunnel'

    class RsCPCIDREntry:
        def __init__(self):
            self.cPCIDRStaticNeighborIPAddress = 'cPCIDRStaticNeighborIPAddress'
            self.cPCIDRStaticRouterIPAddress = 'cPCIDRStaticRouterIPAddress'
            self.cPCIDRAssignedNeighborIP = 'cPCIDRAssignedNeighborIP'
            self.cPCIDRAssignedLocalRouterIP = 'cPCIDRAssignedLocalRouterIP'
            self.cPCIDRPrefixListIndex = 'cPCIDRPrefixListIndex'
            self.cPCIDRLastMinuteLoad = 'cPCIDRLastMinuteLoad'
            self.cPCIDRDescription = 'cPCIDRDescription'
            self.cPCIDRStatsTimePeriod1 = 'cPCIDRStatsTimePeriod1'
            self.cPCIDRStatsTimePeriod2 = 'cPCIDRStatsTimePeriod2'
            self.cPCIDRStatsTimePeriod3 = 'cPCIDRStatsTimePeriod3'
            self.cPCIDRStatsTimePeriod4 = 'cPCIDRStatsTimePeriod4'
            self.cPCIDRStatsTimePeriod5 = 'cPCIDRStatsTimePeriod5'
            self.cPCIDRStatsTimePeriod6 = 'cPCIDRStatsTimePeriod6'
            self.cPCIDRStatus = 'cPCIDRStatus'
            self.cPCIDRSubnet = 'cPCIDRSubnet'
            self.cPCIDRMask = 'cPCIDRMask'

        def __call__(self):
            return 'RsCPCIDREntry'

    class RsIDSDosAttackEntry:
        def __init__(self):
            self.name = 'name'
            self.serviceName = 'serviceName'
            self.serviceType = 'serviceType'
            self.alertThreshold = 'alertThreshold'
            self.activeThreshold = 'activeThreshold'
            self.dropThreshold = 'dropThreshold'
            self.termAlertThreshold = 'termAlertThreshold'
            self.termThreshold = 'termThreshold'
            self.agingPeriod = 'agingPeriod'
            self.msg = 'msg'
            self.packetReport = 'packetReport'
            self.status = 'status'
            self.reportMode = 'reportMode'
            self.sourceType = 'sourceType'
            self.risk = 'risk'
            self.id = 'id'

        def __call__(self):
            return 'RsIDSDosAttackEntry'

    class RsImportExport:
        def __init__(self):
            self.rsExportBaselineBdosEntry = 'rsExportBaselineBdosEntry'
            self.rsExportBaselineDnsEntry = 'rsExportBaselineDnsEntry'
            self.rsExportBaselineHttpEntry = 'rsExportBaselineHttpEntry'

        def __call__(self):
            return 'RsImportExport'

    class RsBWMPolicyTuning:
        def __init__(self):
            self.rsBWMPolicyEntries = 'rsBWMPolicyEntries'
            self.rsBWMPolicyEntriesAfterReset = 'rsBWMPolicyEntriesAfterReset'
            self.rsBWMPolicyLeavesPercent = 'rsBWMPolicyLeavesPercent'
            self.rsBWMPolicyLeavesPercentAfterReset = 'rsBWMPolicyLeavesPercentAfterReset'

        def __call__(self):
            return 'RsBWMPolicyTuning'

    class RsIDSLogEntry:
        def __init__(self):
            self.attackName = 'attackName'
            self.srcAddr = 'srcAddr'
            self.dstAddr = 'dstAddr'
            self.attackStatus = 'attackStatus'
            self.iDSLogtime = 'iDSLogtime'
            self.status = 'status'
            self.context = 'context'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.protocol = 'protocol'
            self.phyPort = 'phyPort'
            self.rid = 'rid'
            self.category = 'category'
            self.policyName = 'policyName'
            self.pktCount = 'pktCount'
            self.byteCount = 'byteCount'
            self.reportMode = 'reportMode'
            self.risk = 'risk'
            self.vlanTag = 'vlanTag'
            self.mPLSTag = 'mPLSTag'
            self.mplsrd = 'mplsrd'
            self.guid = 'guid'
            self.instance = 'instance'
            self.index = 'index'

        def __call__(self):
            return 'RsIDSLogEntry'

    class RsIDSGenericSignatureParams:
        def __init__(self):
            self.rsIDSGenericSignaturesMaxSize = 'rsIDSGenericSignaturesMaxSize'
            self.rsIDSGenericSignaturesMaxSizeAfterReset = 'rsIDSGenericSignaturesMaxSizeAfterReset'

        def __call__(self):
            return 'RsIDSGenericSignatureParams'

    class RsTrafficUtilizationPerPolicyEntryOTHER:
        def __init__(self):
            self.newConnectionsPerPolicyOTHER = 'newConnectionsPerPolicyOTHER'
            self.concurConnectionsPerPolicyOTHER = 'concurConnectionsPerPolicyOTHER'
            self.droppedPacketsPerPolicyOTHER = 'droppedPacketsPerPolicyOTHER'
            self.droppedBytesPerPolicyOTHER = 'droppedBytesPerPolicyOTHER'
            self.receivedPacketsPerPolicyOTHER = 'receivedPacketsPerPolicyOTHER'
            self.receivedBytesPerPolicyOTHER = 'receivedBytesPerPolicyOTHER'
            self.policyNamePerPolicyOTHER = 'policyNamePerPolicyOTHER'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntryOTHER'

    class RsIDSSuspendTableEntry:
        def __init__(self):
            self.expTypeAndTime = 'expTypeAndTime'
            self.srcIp = 'srcIp'
            self.dstIp = 'dstIp'
            self.dstPort = 'dstPort'
            self.protocol = 'protocol'

        def __call__(self):
            return 'RsIDSSuspendTableEntry'

    class RsBWMNetworkEntry:
        def __init__(self):
            self.address = 'address'
            self.mask = 'mask'
            self.fromIP = 'fromIP'
            self.toIP = 'toIP'
            self.mode = 'mode'
            self.status = 'status'
            self.name = 'name'
            self.subIndex = 'subIndex'

        def __call__(self):
            return 'RsBWMNetworkEntry'

    class Dot3adAggPortStatsEntry:
        def __init__(self):
            self.lACPDUsRx = 'lACPDUsRx'
            self.markerPDUsRx = 'markerPDUsRx'
            self.markerResponsePDUsRx = 'markerResponsePDUsRx'
            self.unknownRx = 'unknownRx'
            self.illegalRx = 'illegalRx'
            self.lACPDUsTx = 'lACPDUsTx'
            self.markerPDUsTx = 'markerPDUsTx'
            self.markerResponsePDUsTx = 'markerResponsePDUsTx'
            self.index = 'index'

        def __call__(self):
            return 'Dot3adAggPortStatsEntry'

    class RsDEBUGPolicyEntry:
        def __init__(self):
            self.index = 'index'
            self.description = 'description'
            self.source = 'source'
            self.destination = 'destination'
            self.rXPortGroup = 'rXPortGroup'
            self.tXPortGroup = 'tXPortGroup'
            self.serviceType = 'serviceType'
            self.service = 'service'
            self.vlanTagGroupName = 'vlanTagGroupName'
            self.srcMacGroupName = 'srcMacGroupName'
            self.dstMacGroupName = 'dstMacGroupName'
            self.isSnp = 'isSnp'
            self.isTrace = 'isTrace'
            self.packetsMaxNum = 'packetsMaxNum'
            self.packetMaxLen = 'packetMaxLen'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsDEBUGPolicyEntry'

    class RndMonitoringEntry:
        def __init__(self):
            self.monitoredObjectName = 'monitoredObjectName'
            self.monitoredObjectIdentifier = 'monitoredObjectIdentifier'
            self.monitoredObjectInstance = 'monitoredObjectInstance'
            self.monitoredObjectSyntax = 'monitoredObjectSyntax'
            self.interval = 'interval'
            self.alarmMaxTreshold = 'alarmMaxTreshold'
            self.alarmMinTreshold = 'alarmMinTreshold'
            self.logfile = 'logfile'
            self.status = 'status'
            self.monitoredElement = 'monitoredElement'
            self.monitoredObjectInstanceLabel = 'monitoredObjectInstanceLabel'

        def __call__(self):
            return 'RndMonitoringEntry'

    class RsIDSSuspendTableParams:
        def __init__(self):
            self.rsIDSSuspendTableMaxSrcIps = 'rsIDSSuspendTableMaxSrcIps'
            self.rsIDSSuspendTableMaxSrcIpsAfterReset = 'rsIDSSuspendTableMaxSrcIpsAfterReset'
            self.rsIDSSuspendTableMinAgingTimeout = 'rsIDSSuspendTableMinAgingTimeout'
            self.rsIDSSuspendTableMaxAgingTimeout = 'rsIDSSuspendTableMaxAgingTimeout'
            self.rsIDSSuspendTableEntriesPerSrcIP = 'rsIDSSuspendTableEntriesPerSrcIP'
            self.rsIDSSuspendTableNumberOfEntries = 'rsIDSSuspendTableNumberOfEntries'

        def __call__(self):
            return 'RsIDSSuspendTableParams'

    class RsCPPeerEntry:
        def __init__(self):
            self.routemapName = 'routemapName'
            self.peerState = 'peerState'
            self.currentCapacity = 'currentCapacity'
            self.originalCapacity = 'originalCapacity'
            self.currentLoad = 'currentLoad'
            self.status = 'status'
            self.criticalLoadThreshold = 'criticalLoadThreshold'
            self.optimalLoad = 'optimalLoad'
            self.neighborIPAddress = 'neighborIPAddress'
            self.routerLocalIPAddress = 'routerLocalIPAddress'

        def __call__(self):
            return 'RsCPPeerEntry'

    class RsSSLCertificateDefaultValues:
        def __init__(self):
            self.rsSSLCertificateDefaultCommon = 'rsSSLCertificateDefaultCommon'
            self.rsSSLCertificateDefaultLocality = 'rsSSLCertificateDefaultLocality'
            self.rsSSLCertificateDefaultStateOrProvince = 'rsSSLCertificateDefaultStateOrProvince'
            self.rsSSLCertificateDefaultOrganization = 'rsSSLCertificateDefaultOrganization'
            self.rsSSLCertificateDefaultOrganizationUnit = 'rsSSLCertificateDefaultOrganizationUnit'
            self.rsSSLCertificateDefaultCountryName = 'rsSSLCertificateDefaultCountryName'
            self.rsSSLCertificateDefaultEMail = 'rsSSLCertificateDefaultEMail'

        def __call__(self):
            return 'RsSSLCertificateDefaultValues'

    class RsBWMMacGroupEntry:
        def __init__(self):
            self.status = 'status'
            self.name = 'name'
            self.address = 'address'

        def __call__(self):
            return 'RsBWMMacGroupEntry'

    class RsSession:
        def __init__(self):
            self.sessionTableStatus = 'sessionTableStatus'
            self.sessionTableLookupMode = 'sessionTableLookupMode'
            self.removeEntryAtSessionEnd = 'removeEntryAtSessionEnd'
            self.synProtectionStatus = 'synProtectionStatus'
            self.synProtectionTimeout = 'synProtectionTimeout'
            self.synProtectionActivationBound = 'synProtectionActivationBound'
            self.synProtectionDeactivationBound = 'synProtectionDeactivationBound'
            self.synProtectionTrackingTime = 'synProtectionTrackingTime'
            self.synProtectionMinSynForTrigger = 'synProtectionMinSynForTrigger'
            self.synProtectionPolicyDummy = 'synProtectionPolicyDummy'
            self.synProtectionAttackAgingTime = 'synProtectionAttackAgingTime'
            self.sendResetToServer = 'sendResetToServer'
            self.synProtectionGlobalStatisticsStatus = 'synProtectionGlobalStatisticsStatus'
            self.sessionAgingTime = 'sessionAgingTime'
            self.sessionEntriesNum = 'sessionEntriesNum'
            self.sessionMaxDisplayEntries = 'sessionMaxDisplayEntries'
            self.sessionTableEntryDummy = 'sessionTableEntryDummy'
            self.ackReflectionProtectionMode = 'ackReflectionProtectionMode'
            self.ackReflectionSamplingPerSecond = 'ackReflectionSamplingPerSecond'
            self.ackReflectionDropThreshold = 'ackReflectionDropThreshold'
            self.synProtectionMaxTrapsPerTimeUnit = 'synProtectionMaxTrapsPerTimeUnit'
            self.synProtectionTrapsTimeUnit = 'synProtectionTrapsTimeUnit'
            self.synStatsMaxDestPerPolicy = 'synStatsMaxDestPerPolicy'
            self.synStatsTimePeriod = 'synStatsTimePeriod'
            self.synStatsDisplayPolicyName = 'synStatsDisplayPolicyName'
            self.synStatisticsTableDummy = 'synStatisticsTableDummy'
            self.synStatisticsReset = 'synStatisticsReset'
            self.h225AgingTime = 'h225AgingTime'
            self.noAgingMode = 'noAgingMode'
            self.protectionMode = 'protectionMode'
            self.protectionShortLifetime = 'protectionShortLifetime'
            self.protectionMaxSessions = 'protectionMaxSessions'
            self.tableFullAction = 'tableFullAction'
            self.tableFullActiveThreshold = 'tableFullActiveThreshold'
            self.tableFullDeactiveThreshold = 'tableFullDeactiveThreshold'
            self.sessionTCPAgingTime = 'sessionTCPAgingTime'
            self.sessionUDPAgingTime = 'sessionUDPAgingTime'
            self.sessionSCTPAgingTime = 'sessionSCTPAgingTime'
            self.sessionICMPAgingTime = 'sessionICMPAgingTime'
            self.sessionGREAgingTime = 'sessionGREAgingTime'
            self.removeEntryAtSessionEndTimeout = 'removeEntryAtSessionEndTimeout'

        def __call__(self):
            return 'RsSession'

    class RsACCSMEStatisticsEntry:
        def __init__(self):
            self.aCCSMEResultsReceived = 'aCCSMEResultsReceived'
            self.aCCSMEResultsForward = 'aCCSMEResultsForward'
            self.aCCSMEResultsDiscarded = 'aCCSMEResultsDiscarded'
            self.aCCSMEResultsNext = 'aCCSMEResultsNext'
            self.aCCSMEResultsFree = 'aCCSMEResultsFree'
            self.aCCSMERequestSent = 'aCCSMERequestSent'
            self.aCCSMERequestInvalidData = 'aCCSMERequestInvalidData'
            self.aCCSMERequestFailed = 'aCCSMERequestFailed'
            self.aCCSMEDiscard = 'aCCSMEDiscard'
            self.aCCSMETooManyResults = 'aCCSMETooManyResults'
            self.aCCSMEHWHWProblem = 'aCCSMEHWHWProblem'
            self.aCCSMEFragmented = 'aCCSMEFragmented'
            self.aCCSMEId = 'aCCSMEId'

        def __call__(self):
            return 'RsACCSMEStatisticsEntry'

    class RsWSDServerStatEntry:
        def __init__(self):
            self.wSDSerStatAttUsersNum = 'wSDSerStatAttUsersNum'
            self.wSDSerStatPeakLoad = 'wSDSerStatPeakLoad'
            self.wSDSerStatFramesRate = 'wSDSerStatFramesRate'
            self.wSDSerStatFramesLoad = 'wSDSerStatFramesLoad'
            self.wSDSerStatRecoveryTime = 'wSDSerStatRecoveryTime'
            self.wSDSerStatWarmUpTime = 'wSDSerStatWarmUpTime'
            self.wSDSerStatConnectionLimit = 'wSDSerStatConnectionLimit'
            self.wSDSerStatAdminStatus = 'wSDSerStatAdminStatus'
            self.wSDSerStatConnectionLimitReached = 'wSDSerStatConnectionLimitReached'
            self.wSDSerStatName = 'wSDSerStatName'

        def __call__(self):
            return 'RsWSDServerStatEntry'

    class RsServiceDiscovery:
        def __init__(self):
            self.rsServiceDiscoveryGlobalStatus = 'rsServiceDiscoveryGlobalStatus'
            self.rsServiceDiscoveryGlobalTrackingTime = 'rsServiceDiscoveryGlobalTrackingTime'
            self.rsServiceDiscoveryGlobalReValidTime = 'rsServiceDiscoveryGlobalReValidTime'

        def __call__(self):
            return 'RsServiceDiscovery'

    class RsCPRouterConnectionEntry:
        def __init__(self):
            self.userName = 'userName'
            self.userPassword = 'userPassword'
            self.confPassword = 'confPassword'
            self.protocol = 'protocol'
            self.community = 'community'
            self.port = 'port'
            self.enableLevel = 'enableLevel'
            self.terminalMode = 'terminalMode'
            self.lastSysUpTime = 'lastSysUpTime'
            self.status = 'status'
            self.routerIPAddress = 'routerIPAddress'

        def __call__(self):
            return 'RsCPRouterConnectionEntry'

    class RsMLBAcceptableHTTPCodeEntry:
        def __init__(self):
            self.status = 'status'
            self.rsMLBAcceptableHTTPCode = 'rsMLBAcceptableHTTPCode'

        def __call__(self):
            return 'RsMLBAcceptableHTTPCodeEntry'

    class RdwrTerminalAliasEntry:
        def __init__(self):
            self.command = 'command'
            self.status = 'status'
            self.name = 'name'
            self.userName = 'userName'

        def __call__(self):
            return 'RdwrTerminalAliasEntry'

    class RsCCKHealthChkEntry:
        def __init__(self):
            self.id = 'id'
            self.method = 'method'
            self.status = 'status'
            self.dstAddr = 'dstAddr'
            self.nextHop = 'nextHop'
            self.dstPort = 'dstPort'
            self.arguments = 'arguments'
            self.interval = 'interval'
            self.retries = 'retries'
            self.timeout = 'timeout'
            self.rowStatus = 'rowStatus'
            self.nNSTimeout = 'nNSTimeout'
            self.trckLoad = 'trckLoad'
            self.loadFactor = 'loadFactor'
            self.revResult = 'revResult'
            self.uptimePct = 'uptimePct'
            self.successCnt = 'successCnt'
            self.failCnt = 'failCnt'
            self.duration = 'duration'
            self.serverSpoof = 'serverSpoof'
            self.dstHost = 'dstHost'
            self.name = 'name'

        def __call__(self):
            return 'RsCCKHealthChkEntry'

    class RsSESSIONNewSynTriggerEntry:
        def __init__(self):
            self.time = 'time'
            self.lastSecSYN = 'lastSecSYN'
            self.lastSecRqst = 'lastSecRqst'
            self.avrgSYN = 'avrgSYN'
            self.avrgRqst = 'avrgRqst'
            self.totalSYN = 'totalSYN'
            self.totalDropped = 'totalDropped'
            self.type = 'type'
            self.ip = 'ip'
            self.port = 'port'
            self.rxport = 'rxport'

        def __call__(self):
            return 'RsSESSIONNewSynTriggerEntry'

    class RsSystemFansEntry:
        def __init__(self):
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'RsSystemFansEntry'

    class Snmp:
        def __init__(self):
            self.snmpInPkts = 'snmpInPkts'
            self.snmpInBadVersions = 'snmpInBadVersions'
            self.snmpInBadCommunityNames = 'snmpInBadCommunityNames'
            self.snmpInBadCommunityUses = 'snmpInBadCommunityUses'
            self.snmpInASNParseErrs = 'snmpInASNParseErrs'
            self.snmpEnableAuthenTraps = 'snmpEnableAuthenTraps'
            self.snmpSilentDrops = 'snmpSilentDrops'
            self.snmpProxyDrops = 'snmpProxyDrops'

        def __call__(self):
            return 'Snmp'

    class RsMLBProximity:
        def __init__(self):
            self.rsMLBProximityOperationMode = 'rsMLBProximityOperationMode'
            self.rsMLBProximityMainDNS = 'rsMLBProximityMainDNS'
            self.rsMLBProximityBackupDNS = 'rsMLBProximityBackupDNS'
            self.rsMLBProximityAgingPeriod = 'rsMLBProximityAgingPeriod'
            self.rsMLBProximityRetries = 'rsMLBProximityRetries'
            self.rsMLBProximityTimeout = 'rsMLBProximityTimeout'
            self.rsMLBProximityHopsWeight = 'rsMLBProximityHopsWeight'
            self.rsMLBProximityLatencyWeight = 'rsMLBProximityLatencyWeight'
            self.rsMLBProximityLoadWeight = 'rsMLBProximityLoadWeight'
            self.rsMLBProximityBasicStatus = 'rsMLBProximityBasicStatus'
            self.rsMLBProximityAdvancedStatus = 'rsMLBProximityAdvancedStatus'
            self.rsMLBProximityServerSideStatus = 'rsMLBProximityServerSideStatus'
            self.rsMLBProximityClientSideStatus = 'rsMLBProximityClientSideStatus'
            self.rsMLBProximityStatisticsStatus = 'rsMLBProximityStatisticsStatus'
            self.rsMLBProximityUseGroupingInProximity = 'rsMLBProximityUseGroupingInProximity'

        def __call__(self):
            return 'RsMLBProximity'

    class RsIDSSignaturesRuleAttackNumberEntry:
        def __init__(self):
            self.attackNumber = 'attackNumber'
            self.status = 'status'
            self.profileName = 'profileName'
            self.ruleName = 'ruleName'

        def __call__(self):
            return 'RsIDSSignaturesRuleAttackNumberEntry'

    class RndBootP:
        def __init__(self):
            self.rndBootPServerAddress = 'rndBootPServerAddress'
            self.rndBootPRelaySecThreshold = 'rndBootPRelaySecThreshold'

        def __call__(self):
            return 'RndBootP'

    class RsIDSSynAttackEntry:
        def __init__(self):
            self.iDSSYNAttackName = 'iDSSYNAttackName'
            self.iDSSYNDestinationAppPortGroup = 'iDSSYNDestinationAppPortGroup'
            self.iDSSYNAttackActivationThreshold = 'iDSSYNAttackActivationThreshold'
            self.iDSSYNAttackTerminationThreshold = 'iDSSYNAttackTerminationThreshold'
            self.iDSSYNAttackStableThresholdPeriod = 'iDSSYNAttackStableThresholdPeriod'
            self.iDSSYNAttackPacketReport = 'iDSSYNAttackPacketReport'
            self.iDSSYNAttackStatus = 'iDSSYNAttackStatus'
            self.iDSSYNAttackSourceType = 'iDSSYNAttackSourceType'
            self.iDSSYNAttackRisk = 'iDSSYNAttackRisk'
            self.iDSSYNVerificationType = 'iDSSYNVerificationType'
            self.iDSSYNAttackId = 'iDSSYNAttackId'

        def __call__(self):
            return 'RsIDSSynAttackEntry'

    class RsWSDSysParams:
        def __init__(self):
            self.rsWSDSysFlashSize = 'rsWSDSysFlashSize'
            self.rsWSDSysUpTime = 'rsWSDSysUpTime'
            self.rsWSDSysManagedTime = 'rsWSDSysManagedTime'
            self.rsWSDSysManagedDate = 'rsWSDSysManagedDate'
            self.rsWSDSysBaseMACAddress = 'rsWSDSysBaseMACAddress'

        def __call__(self):
            return 'RsWSDSysParams'

    class RsACCStatEntry:
        def __init__(self):
            self.value = 'value'
            self.id = 'id'

        def __call__(self):
            return 'RsACCStatEntry'

    class RsBWMCurrentDSCPEntry:
        def __init__(self):
            self.dSCPPriority = 'dSCPPriority'
            self.dSCPGuaranteedBW = 'dSCPGuaranteedBW'
            self.dSCPMaxBW = 'dSCPMaxBW'
            self.rsBWMCurrentDSCP = 'rsBWMCurrentDSCP'

        def __call__(self):
            return 'RsBWMCurrentDSCPEntry'

    class VacmContextEntry:
        def __init__(self):
            self.name = 'name'

        def __call__(self):
            return 'VacmContextEntry'

    class RsIDSScanningProfilesEntry:
        def __init__(self):
            self.tCPState = 'tCPState'
            self.uDPState = 'uDPState'
            self.iCMPState = 'iCMPState'
            self.status = 'status'
            self.type = 'type'
            self.sensitivity = 'sensitivity'
            self.accuracyLevel = 'accuracyLevel'
            self.singlePort = 'singlePort'
            self.packetTraceStatus = 'packetTraceStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSScanningProfilesEntry'

    class RsBWMStatisticsNewEntry:
        def __init__(self):
            self.policyNameSec = 'policyNameSec'
            self.bandwidthUsedSecond = 'bandwidthUsedSecond'
            self.packetNumberSecond = 'packetNumberSecond'
            self.guaranteedReachedSecond = 'guaranteedReachedSecond'
            self.maximumReachedSecond = 'maximumReachedSecond'
            self.matchedBandwidthSecond = 'matchedBandwidthSecond'
            self.inboundBandwidthUsedSecond = 'inboundBandwidthUsedSecond'
            self.inboundMatchedBandwidthSecond = 'inboundMatchedBandwidthSecond'
            self.inboundPacketNumberSecond = 'inboundPacketNumberSecond'
            self.outboundBandwidthUsedSecond = 'outboundBandwidthUsedSecond'
            self.outboundMatchedBandwidthSecond = 'outboundMatchedBandwidthSecond'
            self.outboundPacketNumberSecond = 'outboundPacketNumberSecond'
            self.tCPConnectionsSecond = 'tCPConnectionsSecond'
            self.uDPConnectionsSecond = 'uDPConnectionsSecond'
            self.queuedBWSecond = 'queuedBWSecond'
            self.bandwidthUsedPeriod = 'bandwidthUsedPeriod'
            self.peakBandwidthPeriod = 'peakBandwidthPeriod'
            self.packetNumberPeriod = 'packetNumberPeriod'
            self.guaranteedReachedCounterPeriod = 'guaranteedReachedCounterPeriod'
            self.maximumReachedCounterPeriod = 'maximumReachedCounterPeriod'
            self.matchedBandwidthPeriod = 'matchedBandwidthPeriod'
            self.inboundBandwidthUsedPeriod = 'inboundBandwidthUsedPeriod'
            self.inboundMatchedBandwidthPeriod = 'inboundMatchedBandwidthPeriod'
            self.inboundPacketNumberPeriod = 'inboundPacketNumberPeriod'
            self.outboundBandwidthUsedPeriod = 'outboundBandwidthUsedPeriod'
            self.outboundMatchedBandwidthPeriod = 'outboundMatchedBandwidthPeriod'
            self.outboundPacketNumberPeriod = 'outboundPacketNumberPeriod'
            self.tCPConnectionsPeriod = 'tCPConnectionsPeriod'
            self.uDPConnectionsPeriod = 'uDPConnectionsPeriod'
            self.queuedBWPeriod = 'queuedBWPeriod'
            self.policyKey = 'policyKey'

        def __call__(self):
            return 'RsBWMStatisticsNewEntry'

    class SnmpEngine:
        def __init__(self):
            self.snmpEngineID = 'snmpEngineID'
            self.snmpEngineBoots = 'snmpEngineBoots'
            self.snmpEngineTime = 'snmpEngineTime'
            self.snmpEngineMaxMessageSize = 'snmpEngineMaxMessageSize'

        def __call__(self):
            return 'SnmpEngine'

    class RsIpAddrEntry:
        def __init__(self):
            self.adEntIfIndex = 'adEntIfIndex'
            self.adEntNetMask = 'adEntNetMask'
            self.adEntForwardIpBroadcast = 'adEntForwardIpBroadcast'
            self.adEntReasmMaxSize = 'adEntReasmMaxSize'
            self.adEntStatus = 'adEntStatus'
            self.adEntBcastAddr = 'adEntBcastAddr'
            self.adEntVlanTag = 'adEntVlanTag'
            self.adEntOneIpMode = 'adEntOneIpMode'
            self.adEntType = 'adEntType'
            self.adEntPeerAddr = 'adEntPeerAddr'
            self.adEntPeerAddrStatus = 'adEntPeerAddrStatus'
            self.adEntAddr = 'adEntAddr'

        def __call__(self):
            return 'RsIpAddrEntry'

    class RsIDSServProtProfilesEntry:
        def __init__(self):
            self.status = 'status'
            self.serviceId = 'serviceId'
            self.attackSens = 'attackSens'
            self.attackRisk = 'attackRisk'
            self.action = 'action'
            self.packetTraceStatus = 'packetTraceStatus'
            self.name = 'name'
            self.serviceName = 'serviceName'

        def __call__(self):
            return 'RsIDSServProtProfilesEntry'

    class RsBWMPriorityEntry:
        def __init__(self):
            self.bWMPacketsSent = 'bWMPacketsSent'
            self.rsBWMPriority = 'rsBWMPriority'

        def __call__(self):
            return 'RsBWMPriorityEntry'

    class RsMLBMaxURLtoIPTableEntriesTuning:
        def __init__(self):
            self.rsMLBMaxURLtoIPTableSize = 'rsMLBMaxURLtoIPTableSize'
            self.rsMLBMaxURLtoIPTableSizeAfterReset = 'rsMLBMaxURLtoIPTableSizeAfterReset'

        def __call__(self):
            return 'RsMLBMaxURLtoIPTableEntriesTuning'

    class DpsTCPSegmentsTableTuning:
        def __init__(self):
            self.dpsTCPSegmentsTableEntries = 'dpsTCPSegmentsTableEntries'
            self.dpsTCPSegmentsTableEntriesAfterReset = 'dpsTCPSegmentsTableEntriesAfterReset'

        def __call__(self):
            return 'DpsTCPSegmentsTableTuning'

    class RsACCResourceEntry:
        def __init__(self):
            self.aCCFlow = 'aCCFlow'
            self.aCCOther = 'aCCOther'
            self.aCCIdle = 'aCCIdle'
            self.aCCQueue = 'aCCQueue'
            self.aCCInstanceId = 'aCCInstanceId'
            self.aCCId = 'aCCId'
            self.aCCCPUId = 'aCCCPUId'

        def __call__(self):
            return 'RsACCResourceEntry'

    class RsIDSPPSAttackEntry:
        def __init__(self):
            self.name = 'name'
            self.appPort = 'appPort'
            self.trackingType = 'trackingType'
            self.actThres = 'actThres'
            self.termThres = 'termThres'
            self.dropThres = 'dropThres'
            self.risk = 'risk'
            self.actionMode = 'actionMode'
            self.actPeriod = 'actPeriod'
            self.termPeriod = 'termPeriod'
            self.status = 'status'
            self.packetTrace = 'packetTrace'
            self.id = 'id'

        def __call__(self):
            return 'RsIDSPPSAttackEntry'

    class RdwrBgpPeerEntry:
        def __init__(self):
            self.defaultNextHop = 'defaultNextHop'
            self.adminStatus = 'adminStatus'
            self.connectRetryInterval = 'connectRetryInterval'
            self.holdTime = 'holdTime'
            self.keepAlive = 'keepAlive'
            self.state = 'state'
            self.remoteAs = 'remoteAs'
            self.lastError = 'lastError'
            self.mD5Secret = 'mD5Secret'
            self.peer4BytesAsSupport = 'peer4BytesAsSupport'
            self.noAdvertise = 'noAdvertise'
            self.noExport = 'noExport'
            self.noPeer = 'noPeer'
            self.rowStatus = 'rowStatus'
            self.iPv6NextHop = 'iPv6NextHop'
            self.remoteAddr = 'remoteAddr'

        def __call__(self):
            return 'RdwrBgpPeerEntry'

    class RsTrafficUtilizationPerPortEntryIGMP:
        def __init__(self):
            self.droppedPacketsPerPortIGMP = 'droppedPacketsPerPortIGMP'
            self.droppedBytesPerPortIGMP = 'droppedBytesPerPortIGMP'
            self.receivedPacketsPerPortIGMP = 'receivedPacketsPerPortIGMP'
            self.receivedBytesPerPortIGMP = 'receivedBytesPerPortIGMP'
            self.excludedPacketsPerPortIGMP = 'excludedPacketsPerPortIGMP'
            self.excludedBytesPerPortIGMP = 'excludedBytesPerPortIGMP'
            self.portPerPortIGMP = 'portPerPortIGMP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntryIGMP'

    class RsBWMRulesTreeManager:
        def __init__(self):
            self.rsBWMRulesTreeName = 'rsBWMRulesTreeName'
            self.rsBWMRulesTreeNewParentName = 'rsBWMRulesTreeNewParentName'
            self.rsBWMRulesTreeAction = 'rsBWMRulesTreeAction'

        def __call__(self):
            return 'RsBWMRulesTreeManager'

    class RdwrPortsTagEntry:
        def __init__(self):
            self.portInTag = 'portInTag'
            self.portOutTag = 'portOutTag'
            self.portNumber = 'portNumber'

        def __call__(self):
            return 'RdwrPortsTagEntry'

    class RsIDSLoop:
        def __init__(self):
            self.rsIDSLoopGlobalStatus = 'rsIDSLoopGlobalStatus'
            self.rsIDSLoopConfigurationStatus = 'rsIDSLoopConfigurationStatus'
            self.rsIDSLoopGlobalDiversionStatus = 'rsIDSLoopGlobalDiversionStatus'
            self.rsIDSLoopGlobalSwitchStatus = 'rsIDSLoopGlobalSwitchStatus'
            self.rsIDSLoopAdvancedMode = 'rsIDSLoopAdvancedMode'
            self.rsIDSLoopAdvancedActivationTimeout = 'rsIDSLoopAdvancedActivationTimeout'
            self.rsIDSLoopAdvancedTerminationTimeout = 'rsIDSLoopAdvancedTerminationTimeout'
            self.rsIDSLoopAdvancedManualStatus = 'rsIDSLoopAdvancedManualStatus'
            self.rsIDSLoopConfigurationMngIPAddr = 'rsIDSLoopConfigurationMngIPAddr'
            self.rsIDSLoopConfigurationSSHUser = 'rsIDSLoopConfigurationSSHUser'
            self.rsIDSLoopConfigurationSSHPassword = 'rsIDSLoopConfigurationSSHPassword'
            self.rsIDSLoopConfigurationUser = 'rsIDSLoopConfigurationUser'
            self.rsIDSLoopConfigurationPassword = 'rsIDSLoopConfigurationPassword'
            self.rsIDSLoopGlobalLoopDeviceType = 'rsIDSLoopGlobalLoopDeviceType'

        def __call__(self):
            return 'RsIDSLoop'

    class RndSmartFan:
        def __init__(self):
            self.rndSmartFanStatus = 'rndSmartFanStatus'

        def __call__(self):
            return 'RndSmartFan'

    class RsBWMBwmPortOperationEntry:
        def __init__(self):
            self.direction = 'direction'
            self.operationStatus = 'operationStatus'
            self.inboundPort = 'inboundPort'
            self.outboundPort = 'outboundPort'

        def __call__(self):
            return 'RsBWMBwmPortOperationEntry'

    class RsNetFloodBypassEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassEntry'

    class RsNetFloodDynamicStateFpEntry:
        def __init__(self):
            self.rsNetFloodDynamicState = 'rsNetFloodDynamicState'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'
            self.fpType = 'fpType'

        def __call__(self):
            return 'RsNetFloodDynamicStateFpEntry'

    class RsBWMFilterGroup:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.name = 'name'
            self.entryName = 'entryName'

        def __call__(self):
            return 'RsBWMFilterGroup'

    class RsMLBCost:
        def __init__(self):
            self.rsMLBCostAdminStatus = 'rsMLBCostAdminStatus'
            self.rsMLBCostWeight = 'rsMLBCostWeight'
            self.rsMLBTotalDiscardedSessionsNumber = 'rsMLBTotalDiscardedSessionsNumber'
            self.rsMLBCostLoadSamplesNumber = 'rsMLBCostLoadSamplesNumber'

        def __call__(self):
            return 'RsMLBCost'

    class RsHttpFloodLearnedStatEntry:
        def __init__(self):
            self.getPostCnt = 'getPostCnt'
            self.otherCnt = 'otherCnt'
            self.outBand = 'outBand'
            self.serverName = 'serverName'
            self.date = 'date'
            self.hour = 'hour'

        def __call__(self):
            return 'RsHttpFloodLearnedStatEntry'

    class RsSESSIONTableSynFloodTriggersTuning:
        def __init__(self):
            self.rsSESSIONTableSynFloodTriggersEntries = 'rsSESSIONTableSynFloodTriggersEntries'
            self.rsSESSIONTableSynFloodTriggersEntriesAfterReset = 'rsSESSIONTableSynFloodTriggersEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONTableSynFloodTriggersTuning'

    class RsIDSHwPoliciesTableEntry:
        def __init__(self):
            self.hwEntriesNum = 'hwEntriesNum'
            self.subPoliciesNum = 'subPoliciesNum'
            self.status = 'status'
            self.name = 'name'
            self.direction = 'direction'

        def __call__(self):
            return 'RsIDSHwPoliciesTableEntry'

    class RsImportBaselineHttpEntry:
        def __init__(self):
            self.avrgGetpost = 'avrgGetpost'
            self.avrgOther = 'avrgOther'
            self.avrgOutband = 'avrgOutband'
            self.peakGetpost = 'peakGetpost'
            self.peakOther = 'peakOther'
            self.peakOutband = 'peakOutband'
            self.learnInitGetpost = 'learnInitGetpost'
            self.learnInitOther = 'learnInitOther'
            self.learnInitOutband = 'learnInitOutband'
            self.maxGetPerSession = 'maxGetPerSession'
            self.maxGetPerSrc = 'maxGetPerSrc'
            self.creDay = 'creDay'
            self.reqConInit = 'reqConInit'
            self.reqSrcInit = 'reqSrcInit'
            self.getpostLongTerm1 = 'getpostLongTerm1'
            self.getpostLongTerm2 = 'getpostLongTerm2'
            self.getpostLongTerm3 = 'getpostLongTerm3'
            self.getpostLongTerm4 = 'getpostLongTerm4'
            self.getpostLongTerm5 = 'getpostLongTerm5'
            self.getpostLongTerm6 = 'getpostLongTerm6'
            self.getpostLongTerm7 = 'getpostLongTerm7'
            self.getpostLongTerm8 = 'getpostLongTerm8'
            self.getpostLongTerm9 = 'getpostLongTerm9'
            self.getpostLongTerm10 = 'getpostLongTerm10'
            self.name = 'name'

        def __call__(self):
            return 'RsImportBaselineHttpEntry'

    class RsIDSConnectionLimitProfileEntry:
        def __init__(self):
            self.attackId = 'attackId'
            self.status = 'status'
            self.name = 'name'
            self.attackName = 'attackName'

        def __call__(self):
            return 'RsIDSConnectionLimitProfileEntry'

    class RsBWMStatisticsEntry:
        def __init__(self):
            self.bandwidthUsedLastSec = 'bandwidthUsedLastSec'
            self.packetNumberLastSec = 'packetNumberLastSec'
            self.fullQueueFailuresBWLastSec = 'fullQueueFailuresBWLastSec'
            self.agedPacketsFailuresBWLastSec = 'agedPacketsFailuresBWLastSec'
            self.guaranteedReachedLastSec = 'guaranteedReachedLastSec'
            self.maximumReachedLastSec = 'maximumReachedLastSec'
            self.bandwidthUsedLastPeriod = 'bandwidthUsedLastPeriod'
            self.peakBandwidthLastPeriod = 'peakBandwidthLastPeriod'
            self.packetNumberLastPeriod = 'packetNumberLastPeriod'
            self.fullQueueFailuresBWLastPeriod = 'fullQueueFailuresBWLastPeriod'
            self.agedPacketsFailuresBWLastPeriod = 'agedPacketsFailuresBWLastPeriod'
            self.guaranteedReachedCounterLastPeriod = 'guaranteedReachedCounterLastPeriod'
            self.maximumReachedCounterLastPeriod = 'maximumReachedCounterLastPeriod'
            self.matchedBandwidthLastSec = 'matchedBandwidthLastSec'
            self.matchedBandwidthLastPeriod = 'matchedBandwidthLastPeriod'
            self.inboundBandwidthUsedLastSec = 'inboundBandwidthUsedLastSec'
            self.inboundBandwidthUsedLastPeriod = 'inboundBandwidthUsedLastPeriod'
            self.inboundMatchedBandwidthLastSec = 'inboundMatchedBandwidthLastSec'
            self.inboundMatchedBandwidthLastPeriod = 'inboundMatchedBandwidthLastPeriod'
            self.inboundPacketNumberLastSec = 'inboundPacketNumberLastSec'
            self.inboundPacketNumberLastPeriod = 'inboundPacketNumberLastPeriod'
            self.outboundBandwidthUsedLastSec = 'outboundBandwidthUsedLastSec'
            self.outboundBandwidthUsedLastPeriod = 'outboundBandwidthUsedLastPeriod'
            self.outboundMatchedBandwidthLastSec = 'outboundMatchedBandwidthLastSec'
            self.outboundMatchedBandwidthLastPeriod = 'outboundMatchedBandwidthLastPeriod'
            self.outboundPacketNumberLastSec = 'outboundPacketNumberLastSec'
            self.outboundPacketNumberLastPeriod = 'outboundPacketNumberLastPeriod'
            self.newTCPConnectionsLastSec = 'newTCPConnectionsLastSec'
            self.newTCPConnectionsLastPeriod = 'newTCPConnectionsLastPeriod'
            self.newUDPConnectionsLastSec = 'newUDPConnectionsLastSec'
            self.newUDPConnectionsLastPeriod = 'newUDPConnectionsLastPeriod'
            self.queuedBWLastSec = 'queuedBWLastSec'
            self.queuedBWLastPeriod = 'queuedBWLastPeriod'
            self.policyName = 'policyName'

        def __call__(self):
            return 'RsBWMStatisticsEntry'

    class RdwrCdbParameters:
        def __init__(self):
            self.rdwrCdbTimeStamp = 'rdwrCdbTimeStamp'

        def __call__(self):
            return 'RdwrCdbParameters'

    class RsImportBaselineDnsEntry:
        def __init__(self):
            self.mxInIpv4 = 'mxInIpv4'
            self.mxOutIpv4 = 'mxOutIpv4'
            self.ptrInIpv4 = 'ptrInIpv4'
            self.ptrOutIpv4 = 'ptrOutIpv4'
            self.aaaaInIpv4 = 'aaaaInIpv4'
            self.aaaaOutIpv4 = 'aaaaOutIpv4'
            self.textInIpv4 = 'textInIpv4'
            self.textOutIpv4 = 'textOutIpv4'
            self.soaInIpv4 = 'soaInIpv4'
            self.soaOutIpv4 = 'soaOutIpv4'
            self.naptrInIpv4 = 'naptrInIpv4'
            self.naptrOutIpv4 = 'naptrOutIpv4'
            self.srcInIpv4 = 'srcInIpv4'
            self.srcOutIpv4 = 'srcOutIpv4'
            self.otherInIpv4 = 'otherInIpv4'
            self.otherOutIpv4 = 'otherOutIpv4'
            self.aInIpv4 = 'aInIpv4'
            self.aOutIpv4 = 'aOutIpv4'
            self.mxInIpv6 = 'mxInIpv6'
            self.mxOutIpv6 = 'mxOutIpv6'
            self.ptrInIpv6 = 'ptrInIpv6'
            self.ptrOutIpv6 = 'ptrOutIpv6'
            self.aaaaInIpv6 = 'aaaaInIpv6'
            self.aaaaOutIpv6 = 'aaaaOutIpv6'
            self.textInIpv6 = 'textInIpv6'
            self.textOutIpv6 = 'textOutIpv6'
            self.soaInIpv6 = 'soaInIpv6'
            self.soaOutIpv6 = 'soaOutIpv6'
            self.naptrInIpv6 = 'naptrInIpv6'
            self.naptrOutIpv6 = 'naptrOutIpv6'
            self.srcInIpv6 = 'srcInIpv6'
            self.srcOutIpv6 = 'srcOutIpv6'
            self.otherInIpv6 = 'otherInIpv6'
            self.otherOutIpv6 = 'otherOutIpv6'
            self.aInIpv6 = 'aInIpv6'
            self.aOutIpv6 = 'aOutIpv6'
            self.name = 'name'

        def __call__(self):
            return 'RsImportBaselineDnsEntry'

    class RsWSDNTP:
        def __init__(self):
            self.rsWSDNTPServerAddr = 'rsWSDNTPServerAddr'
            self.rsWSDNTPInterval = 'rsWSDNTPInterval'
            self.rsWSDNTPStatus = 'rsWSDNTPStatus'
            self.rsWSDNTPTimeZone = 'rsWSDNTPTimeZone'
            self.rsWSDNTPPort = 'rsWSDNTPPort'
            self.rsWSDNTPServerUrl = 'rsWSDNTPServerUrl'

        def __call__(self):
            return 'RsWSDNTP'

    class RsDnsrParameters:
        def __init__(self):
            self.rsDnsrPrimaryAddr = 'rsDnsrPrimaryAddr'
            self.rsDnsrAlternateAddr = 'rsDnsrAlternateAddr'
            self.rsDnsrEnable = 'rsDnsrEnable'

        def __call__(self):
            return 'RsDnsrParameters'

    class RsIDSOutOfPathFootPrintEvent:
        def __init__(self):
            self.rsIDSOutOfPathFootPrintErrorDesc = 'rsIDSOutOfPathFootPrintErrorDesc'
            self.rsIDSOutOfPathFootPrintErrorSeverity = 'rsIDSOutOfPathFootPrintErrorSeverity'

        def __call__(self):
            return 'RsIDSOutOfPathFootPrintEvent'

    class RsSignalingReportHttpEntry:
        def __init__(self):
            self.sigRprtHttpDeviceName = 'sigRprtHttpDeviceName'
            self.sigRprtHttpTimestamp = 'sigRprtHttpTimestamp'
            self.sigRprtHttpCustomerName = 'sigRprtHttpCustomerName'
            self.sigRprtHttpCustomerDesc = 'sigRprtHttpCustomerDesc'
            self.sigRprtHttpProtectedNw = 'sigRprtHttpProtectedNw'
            self.sigRprtHttpLastSecXml = 'sigRprtHttpLastSecXml'
            self.sigRprtHttpNormalXml = 'sigRprtHttpNormalXml'
            self.sigRprtHttpPeakXml = 'sigRprtHttpPeakXml'
            self.sigRprtHttpServerName = 'sigRprtHttpServerName'

        def __call__(self):
            return 'RsSignalingReportHttpEntry'

    class RsIDSUserAttacksDBEntriesTuning:
        def __init__(self):
            self.rsIDSUserAttacksDBEntries = 'rsIDSUserAttacksDBEntries'
            self.rsIDSUserAttacksDBEntriesAfterReset = 'rsIDSUserAttacksDBEntriesAfterReset'

        def __call__(self):
            return 'RsIDSUserAttacksDBEntriesTuning'

    class RsNetFloodProfileEntry:
        def __init__(self):
            self.tcpStatus = 'tcpStatus'
            self.tcpSynStatus = 'tcpSynStatus'
            self.udpStatus = 'udpStatus'
            self.igmpStatus = 'igmpStatus'
            self.icmpStatus = 'icmpStatus'
            self.status = 'status'
            self.tcpFinAckStatus = 'tcpFinAckStatus'
            self.tcpRstStatus = 'tcpRstStatus'
            self.tcpPshAckStatus = 'tcpPshAckStatus'
            self.tcpSynAckStatus = 'tcpSynAckStatus'
            self.tcpFragStatus = 'tcpFragStatus'
            self.bandwidthIn = 'bandwidthIn'
            self.bandwidthOut = 'bandwidthOut'
            self.tcpInQuota = 'tcpInQuota'
            self.udpInQuota = 'udpInQuota'
            self.icmpInQuota = 'icmpInQuota'
            self.igmpInQuota = 'igmpInQuota'
            self.tcpOutQuota = 'tcpOutQuota'
            self.udpOutQuota = 'udpOutQuota'
            self.icmpOutQuota = 'icmpOutQuota'
            self.igmpOutQuota = 'igmpOutQuota'
            self.transparentOptimization = 'transparentOptimization'
            self.levelOfReuglarzation = 'levelOfReuglarzation'
            self.packetReportStatus = 'packetReportStatus'
            self.packetTraceStatus = 'packetTraceStatus'
            self.action = 'action'
            self.simulationDuration = 'simulationDuration'
            self.simulationStopAtAttackEnd = 'simulationStopAtAttackEnd'
            self.simulationStabilizationDuration = 'simulationStabilizationDuration'
            self.simulationStartWhenSigChange = 'simulationStartWhenSigChange'
            self.jointDistributionStatus = 'jointDistributionStatus'
            self.udpFragStatus = 'udpFragStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsNetFloodProfileEntry'

    class RsMaxZeroHopRoutEntriesTuning:
        def __init__(self):
            self.rsMaxZhrConns = 'rsMaxZhrConns'
            self.rsMaxZhrConnsAfterReset = 'rsMaxZhrConnsAfterReset'

        def __call__(self):
            return 'RsMaxZeroHopRoutEntriesTuning'

    class RsMLBVIPReservedPortsEntry:
        def __init__(self):
            self.status = 'status'
            self.rsMLBVIPReservedPort = 'rsMLBVIPReservedPort'

        def __call__(self):
            return 'RsMLBVIPReservedPortsEntry'

    class RsMLBLogicalIDSServerEntry:
        def __init__(self):
            self.connectedToPort = 'connectedToPort'
            self.iPAddr = 'iPAddr'
            self.operStatus = 'operStatus'
            self.weight = 'weight'
            self.operMode = 'operMode'
            self.adminStatus = 'adminStatus'
            self.connectivityCheckId = 'connectivityCheckId'
            self.connectivityCheckStatus = 'connectivityCheckStatus'
            self.status = 'status'
            self.attachedUsersNumber = 'attachedUsersNumber'
            self.peakLoad = 'peakLoad'
            self.framesRate = 'framesRate'
            self.framesLoad = 'framesLoad'
            self.connectionLimit = 'connectionLimit'
            self.peakBytesLoad = 'peakBytesLoad'
            self.bytesRate = 'bytesRate'
            self.bytesLoad = 'bytesLoad'
            self.bytesLimit = 'bytesLimit'
            self.macStatus = 'macStatus'
            self.farm = 'farm'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBLogicalIDSServerEntry'

    class RsImportServerEntry:
        def __init__(self):
            self.update = 'update'
            self.override = 'override'
            self.file = 'file'

        def __call__(self):
            return 'RsImportServerEntry'

    class VacmAccessEntry:
        def __init__(self):
            self.contextMatch = 'contextMatch'
            self.readViewName = 'readViewName'
            self.writeViewName = 'writeViewName'
            self.notifyViewName = 'notifyViewName'
            self.storageType = 'storageType'
            self.status = 'status'
            self.groupName = 'groupName'
            self.contextPrefix = 'contextPrefix'
            self.securityModel = 'securityModel'
            self.securityLevel = 'securityLevel'

        def __call__(self):
            return 'VacmAccessEntry'

    class RsIDStrackingEntry:
        def __init__(self):
            self.iDSTrackingTime = 'iDSTrackingTime'
            self.iDSThreshold = 'iDSThreshold'
            self.iDSFilterGroupType = 'iDSFilterGroupType'
            self.iDSTrackingType = 'iDSTrackingType'
            self.iDSStatus = 'iDSStatus'
            self.iDSReportMode = 'iDSReportMode'
            self.iDSPacketReport = 'iDSPacketReport'
            self.iDSRisk = 'iDSRisk'
            self.iDSFilterGroupName = 'iDSFilterGroupName'

        def __call__(self):
            return 'RsIDStrackingEntry'

    class RdwrVrrp:
        def __init__(self):
            self.rdwrVrrpAdmin = 'rdwrVrrpAdmin'
            self.rdwrVrrpOperAdvertisementInterval = 'rdwrVrrpOperAdvertisementInterval'
            self.rdwrVrrpPriorityTracking = 'rdwrVrrpPriorityTracking'

        def __call__(self):
            return 'RdwrVrrp'

    class RsIDSRulesEntry:
        def __init__(self):
            self.name = 'name'
            self.source = 'source'
            self.destination = 'destination'
            self.direction = 'direction'
            self.portmask = 'portmask'
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'RsIDSRulesEntry'

    class RsBWMVLANTagGroupEntry:
        def __init__(self):
            self.vLANTagTo = 'vLANTagTo'
            self.mode = 'mode'
            self.status = 'status'
            self.name = 'name'
            self.vLANTag = 'vLANTag'
            self.vLANTagFrom = 'vLANTagFrom'

        def __call__(self):
            return 'RsBWMVLANTagGroupEntry'

    class RsIpRipFilterLclEntry:
        def __init__(self):
            self.status = 'status'
            self.ipAddr = 'ipAddr'
            self.networkMaskBits = 'networkMaskBits'
            self.matchBits = 'matchBits'
            self.action = 'action'
            self.ipIntf = 'ipIntf'
            self.type = 'type'
            self.number = 'number'

        def __call__(self):
            return 'RsIpRipFilterLclEntry'

    class RsBWMFilterPolicyEntry:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.rsBWMFilterPolicyEntryType = 'rsBWMFilterPolicyEntryType'
            self.name = 'name'
            self.rsBWMFilterPolicyEntryName = 'rsBWMFilterPolicyEntryName'

        def __call__(self):
            return 'RsBWMFilterPolicyEntry'

    class RsTrafficUtilizationPerPolicyEntryIGMP:
        def __init__(self):
            self.newConnectionsPerPolicyIGMP = 'newConnectionsPerPolicyIGMP'
            self.concurConnectionsPerPolicyIGMP = 'concurConnectionsPerPolicyIGMP'
            self.droppedPacketsPerPolicyIGMP = 'droppedPacketsPerPolicyIGMP'
            self.droppedBytesPerPolicyIGMP = 'droppedBytesPerPolicyIGMP'
            self.receivedPacketsPerPolicyIGMP = 'receivedPacketsPerPolicyIGMP'
            self.receivedBytesPerPolicyIGMP = 'receivedBytesPerPolicyIGMP'
            self.policyNamePerPolicyIGMP = 'policyNamePerPolicyIGMP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntryIGMP'

    class VrrpOperEntry:
        def __init__(self):
            self.virtualMacAddr = 'virtualMacAddr'
            self.state = 'state'
            self.adminState = 'adminState'
            self.priority = 'priority'
            self.ipAddrCount = 'ipAddrCount'
            self.masterIpAddr = 'masterIpAddr'
            self.primaryIpAddr = 'primaryIpAddr'
            self.authType = 'authType'
            self.authKey = 'authKey'
            self.advertisementInterval = 'advertisementInterval'
            self.preemptMode = 'preemptMode'
            self.virtualRouterUpTime = 'virtualRouterUpTime'
            self.protocol = 'protocol'
            self.rowStatus = 'rowStatus'
            self.ifIndex = 'ifIndex'
            self.vrId = 'vrId'

        def __call__(self):
            return 'VrrpOperEntry'

    class RsBWMCurrentFilterGroup:
        def __init__(self):
            self.type = 'type'
            self.name = 'name'
            self.entryName = 'entryName'

        def __call__(self):
            return 'RsBWMCurrentFilterGroup'

    class RsMLBChainEntry:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBChainEntry'

    class RsMLBMappedIPEntry:
        def __init__(self):
            self.firewallNAT = 'firewallNAT'
            self.status = 'status'
            self.virtualAddress = 'virtualAddress'
            self.firewallIP = 'firewallIP'

        def __call__(self):
            return 'RsMLBMappedIPEntry'

    class ArpSpec:
        def __init__(self):
            self.rsArpDeleteTable = 'rsArpDeleteTable'
            self.rsArpInactiveTimeOut = 'rsArpInactiveTimeOut'
            self.rsArpProxy = 'rsArpProxy'

        def __call__(self):
            return 'ArpSpec'

    class RsMLBClientEntry:
        def __init__(self):
            self.mLBAttachedServerAddr = 'mLBAttachedServerAddr'
            self.lastActivityTime = 'lastActivityTime'
            self.attachmentTime = 'attachmentTime'
            self.status = 'status'
            self.mLBSessionType = 'mLBSessionType'
            self.addr = 'addr'
            self.mLBDestinationAddr = 'mLBDestinationAddr'
            self.mLBSourcePort = 'mLBSourcePort'
            self.mLBDestPort = 'mLBDestPort'

        def __call__(self):
            return 'RsMLBClientEntry'

    class RsSESSIONSynProtectionStatisticsEntry:
        def __init__(self):
            self.currentAttackStatus = 'currentAttackStatus'
            self.lastSecSynCount = 'lastSecSynCount'
            self.lastSecGoodCount = 'lastSecGoodCount'
            self.averageSynCount = 'averageSynCount'
            self.averageGoodCount = 'averageGoodCount'
            self.peakSynCount = 'peakSynCount'
            self.peakGoodCount = 'peakGoodCount'
            self.activityTime = 'activityTime'
            self.lastAttackStartTime = 'lastAttackStartTime'
            self.lastAttackTermTime = 'lastAttackTermTime'
            self.policy = 'policy'
            self.ip = 'ip'
            self.port = 'port'
            self.rxPort = 'rxPort'

        def __call__(self):
            return 'RsSESSIONSynProtectionStatisticsEntry'

    class RdwrClientsTypeEntry:
        def __init__(self):
            self.rdwrClientsType = 'rdwrClientsType'

        def __call__(self):
            return 'RdwrClientsTypeEntry'

    class RsNetFloodBypassTcpFragEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.type = 'type'

        def __call__(self):
            return 'RsNetFloodBypassTcpFragEntry'

    class RsBWMCurrentFilterPolicyEntry:
        def __init__(self):
            self.type = 'type'
            self.rsBWMCurrentFilterPolicyEntryType = 'rsBWMCurrentFilterPolicyEntryType'
            self.name = 'name'
            self.rsBWMCurrentFilterPolicyEntryName = 'rsBWMCurrentFilterPolicyEntryName'

        def __call__(self):
            return 'RsBWMCurrentFilterPolicyEntry'

    class RsIDSMemoryQuarantineTuning:
        def __init__(self):
            self.rsIDSQuarantineMaxIPs = 'rsIDSQuarantineMaxIPs'
            self.rsIDSQuarantineMaxIPsAfterReset = 'rsIDSQuarantineMaxIPsAfterReset'

        def __call__(self):
            return 'RsIDSMemoryQuarantineTuning'

    class RsSignalingNwSrcGroupEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.id = 'id'
            self.name = 'name'

        def __call__(self):
            return 'RsSignalingNwSrcGroupEntry'

    class RndFACSActEntry:
        def __init__(self):
            self.fACSAction = 'fACSAction'
            self.type = 'type'
            self.ifIndex = 'ifIndex'

        def __call__(self):
            return 'RndFACSActEntry'

    class RsDnsProt:
        def __init__(self):
            self.rsDnsProtResetServerLearning = 'rsDnsProtResetServerLearning'
            self.rsDnsProtMechStatus = 'rsDnsProtMechStatus'
            self.rsDnsProtLearningPeriod = 'rsDnsProtLearningPeriod'
            self.rsDnsProtResetAllLearning = 'rsDnsProtResetAllLearning'
            self.rsDnsProtFootprintStrictness = 'rsDnsProtFootprintStrictness'
            self.rsDnsProtDynamicTermSC2 = 'rsDnsProtDynamicTermSC2'
            self.rsDnsProtDynamicTermSC6 = 'rsDnsProtDynamicTermSC6'
            self.rsDnsProtDynamicTermSC37 = 'rsDnsProtDynamicTermSC37'
            self.rsDnsProtPolicies = 'rsDnsProtPolicies'
            self.rsDnsProtPoliciesAfterReset = 'rsDnsProtPoliciesAfterReset'
            self.rsDnsSDMWhiteListStatus = 'rsDnsSDMWhiteListStatus'
            self.rsDnsPacketAnomaliesStatus = 'rsDnsPacketAnomaliesStatus'
            self.rsDnsSDMWhiteListTimeout = 'rsDnsSDMWhiteListTimeout'
            self.rsDnsSDMRetransmitMinTime = 'rsDnsSDMRetransmitMinTime'
            self.rsDnsSDMRetransmitMaxTime = 'rsDnsSDMRetransmitMaxTime'
            self.rsDnsSDMRetransmitMaxAttackTime = 'rsDnsSDMRetransmitMaxAttackTime'
            self.rsDnsSDMTableSize = 'rsDnsSDMTableSize'
            self.rsDnsSDMTableSizeAfterReset = 'rsDnsSDMTableSizeAfterReset'
            self.rsDnsMitigationTimeout = 'rsDnsMitigationTimeout'
            self.rsDnsFootprintRetries = 'rsDnsFootprintRetries'
            self.rsDnsSignatureChallengeStatus = 'rsDnsSignatureChallengeStatus'
            self.rsDnsSignatureRateLimitStatus = 'rsDnsSignatureRateLimitStatus'
            self.rsDnsCollectiveChallengeStatus = 'rsDnsCollectiveChallengeStatus'
            self.rsDnsCollectiveRateLimitStatus = 'rsDnsCollectiveRateLimitStatus'
            self.rsDnsProtMitigationStabilityCounter = 'rsDnsProtMitigationStabilityCounter'
            self.rsDnsProtSamplingStatus = 'rsDnsProtSamplingStatus'
            self.rsDnsSDMProtQidTreatment = 'rsDnsSDMProtQidTreatment'
            self.rsDnsSDMProtForwardRetransmissions = 'rsDnsSDMProtForwardRetransmissions'

        def __call__(self):
            return 'RsDnsProt'

    class RdwrDPPassiveSSLTcpPortEntry:
        def __init__(self):
            self.decryptedPort = 'decryptedPort'
            self.status = 'status'
            self.sSLPort = 'sSLPort'

        def __call__(self):
            return 'RdwrDPPassiveSSLTcpPortEntry'

    class Ip6NetToMediaEntry:
        def __init__(self):
            self.physAddress = 'physAddress'
            self.type = 'type'
            self.ifIndex = 'ifIndex'
            self.netAddress = 'netAddress'

        def __call__(self):
            return 'Ip6NetToMediaEntry'

    class RsMLBMaxStaticNatEntriesTuning:
        def __init__(self):
            self.rsMLBMaxStaticNatEntries = 'rsMLBMaxStaticNatEntries'
            self.rsMLBMaxStaticNatEntriesAfterReset = 'rsMLBMaxStaticNatEntriesAfterReset'

        def __call__(self):
            return 'RsMLBMaxStaticNatEntriesTuning'

    class RsPortStatsEntry:
        def __init__(self):
            self.inOctetsPerSec = 'inOctetsPerSec'
            self.inPktsPerSec = 'inPktsPerSec'
            self.inDiscardsPerSec = 'inDiscardsPerSec'
            self.inErrorsPerSec = 'inErrorsPerSec'
            self.outOctetsPerSec = 'outOctetsPerSec'
            self.outPktsPerSec = 'outPktsPerSec'
            self.outDiscardsPerSec = 'outDiscardsPerSec'
            self.outErrorsPerSec = 'outErrorsPerSec'
            self.portNumber = 'portNumber'

        def __call__(self):
            return 'RsPortStatsEntry'

    class RsCPPeriodStartTimeEntry:
        def __init__(self):
            self.description = 'description'
            self.status = 'status'
            self.hours = 'hours'
            self.minutes = 'minutes'

        def __call__(self):
            return 'RsCPPeriodStartTimeEntry'

    class RsHttpFlood:
        def __init__(self):
            self.rsHttpFloodMechanismStatus = 'rsHttpFloodMechanismStatus'
            self.rsHttpFloodLearnTimeBeforeActive = 'rsHttpFloodLearnTimeBeforeActive'
            self.rsHttpFloodLearningMode = 'rsHttpFloodLearningMode'
            self.rsHttpFloodLearningSensitivity = 'rsHttpFloodLearningSensitivity'
            self.rsHttpFloodFullBlockModeStatus = 'rsHttpFloodFullBlockModeStatus'
            self.rsHttpFloodSourceRateLimit = 'rsHttpFloodSourceRateLimit'
            self.rsHttpFloodUriRateLimit = 'rsHttpFloodUriRateLimit'
            self.rsHttpFloodMitigationMode = 'rsHttpFloodMitigationMode'
            self.rsHttpFloodManModeSourceRateLimit = 'rsHttpFloodManModeSourceRateLimit'
            self.rsHttpFloodManModeUriRateLimit = 'rsHttpFloodManModeUriRateLimit'
            self.rsHttpFloodMitigationFailureCond = 'rsHttpFloodMitigationFailureCond'
            self.rsHttpFloodsResetServerLearning = 'rsHttpFloodsResetServerLearning'
            self.rsHttpFloodInitialGetPostAverage = 'rsHttpFloodInitialGetPostAverage'
            self.rsHttpFloodInitialGetPostMax = 'rsHttpFloodInitialGetPostMax'
            self.rsHttpFloodInitialRequestsMax = 'rsHttpFloodInitialRequestsMax'
            self.rsHttpFloodInitialRequestsConnectionMax = 'rsHttpFloodInitialRequestsConnectionMax'
            self.rsHttpFloodInitialOutbound = 'rsHttpFloodInitialOutbound'
            self.rsHttpFloodInitialOutboundMax = 'rsHttpFloodInitialOutboundMax'
            self.rsHttpFloodGetPostSensitivityHigh = 'rsHttpFloodGetPostSensitivityHigh'
            self.rsHttpFloodGetPostSensitivityMedium = 'rsHttpFloodGetPostSensitivityMedium'
            self.rsHttpFloodGetPostSensitivityLow = 'rsHttpFloodGetPostSensitivityLow'
            self.rsHttpFloodGetPostSensitivityMinor = 'rsHttpFloodGetPostSensitivityMinor'
            self.rsHttpFloodOtherSensitivityHigh = 'rsHttpFloodOtherSensitivityHigh'
            self.rsHttpFloodOtherSensitivityMedium = 'rsHttpFloodOtherSensitivityMedium'
            self.rsHttpFloodOtherSensitivityLow = 'rsHttpFloodOtherSensitivityLow'
            self.rsHttpFloodOtherSensitivityMinor = 'rsHttpFloodOtherSensitivityMinor'
            self.rsHttpFloodOutboundSensitivityHigh = 'rsHttpFloodOutboundSensitivityHigh'
            self.rsHttpFloodOutboundSensitivityMedium = 'rsHttpFloodOutboundSensitivityMedium'
            self.rsHttpFloodOutboundSensitivityLow = 'rsHttpFloodOutboundSensitivityLow'
            self.rsHttpFloodOutboundSensitivityMinor = 'rsHttpFloodOutboundSensitivityMinor'
            self.rsHttpFloodOutRPSensitivityHigh = 'rsHttpFloodOutRPSensitivityHigh'
            self.rsHttpFloodOutRPSensitivityMedium = 'rsHttpFloodOutRPSensitivityMedium'
            self.rsHttpFloodOutRPSensitivityLow = 'rsHttpFloodOutRPSensitivityLow'
            self.rsHttpFloodOutRPSensitivityMinor = 'rsHttpFloodOutRPSensitivityMinor'
            self.rsHttpFloodExpSizeConfidenceHigh = 'rsHttpFloodExpSizeConfidenceHigh'
            self.rsHttpFloodExpSizeConfidenceMedium = 'rsHttpFloodExpSizeConfidenceMedium'
            self.rsHttpFloodExpSizeConfidenceLow = 'rsHttpFloodExpSizeConfidenceLow'
            self.rsHttpFloodExpSizeConfidenceMinor = 'rsHttpFloodExpSizeConfidenceMinor'
            self.rsHttpFloodRequestPerConnectionConfidenceHigh = 'rsHttpFloodRequestPerConnectionConfidenceHigh'
            self.rsHttpFloodRequestPerConnectionConfidenceMedium = 'rsHttpFloodRequestPerConnectionConfidenceMedium'
            self.rsHttpFloodRequestPerConnectionConfidenceLow = 'rsHttpFloodRequestPerConnectionConfidenceLow'
            self.rsHttpFloodRequestPerConnectionConfidenceMinor = 'rsHttpFloodRequestPerConnectionConfidenceMinor'
            self.rsHttpFloodRequestPerSourceConfidenceHigh = 'rsHttpFloodRequestPerSourceConfidenceHigh'
            self.rsHttpFloodRequestPerSourceConfidenceMedium = 'rsHttpFloodRequestPerSourceConfidenceMedium'
            self.rsHttpFloodRequestPerSourceConfidenceLow = 'rsHttpFloodRequestPerSourceConfidenceLow'
            self.rsHttpFloodRequestPerSourceConfidenceMinor = 'rsHttpFloodRequestPerSourceConfidenceMinor'
            self.rsHttpFloodExpSizeSensitivityHigh = 'rsHttpFloodExpSizeSensitivityHigh'
            self.rsHttpFloodExpSizeSensitivityMedium = 'rsHttpFloodExpSizeSensitivityMedium'
            self.rsHttpFloodExpSizeSensitivityLow = 'rsHttpFloodExpSizeSensitivityLow'
            self.rsHttpFloodExpSizeSensitivityMinor = 'rsHttpFloodExpSizeSensitivityMinor'
            self.rsHttpFloodRequestPerConnectionSensitivityHigh = 'rsHttpFloodRequestPerConnectionSensitivityHigh'
            self.rsHttpFloodRequestPerConnectionSensitivityMedium = 'rsHttpFloodRequestPerConnectionSensitivityMedium'
            self.rsHttpFloodRequestPerConnectionSensitivityLow = 'rsHttpFloodRequestPerConnectionSensitivityLow'
            self.rsHttpFloodRequestPerConnectionSensitivityMinor = 'rsHttpFloodRequestPerConnectionSensitivityMinor'
            self.rsHttpFloodRequestPerSourceSensitivityHigh = 'rsHttpFloodRequestPerSourceSensitivityHigh'
            self.rsHttpFloodRequestPerSourceSensitivityMedium = 'rsHttpFloodRequestPerSourceSensitivityMedium'
            self.rsHttpFloodRequestPerSourceSensitivityLow = 'rsHttpFloodRequestPerSourceSensitivityLow'
            self.rsHttpFloodRequestPerSourceSensitivityMinor = 'rsHttpFloodRequestPerSourceSensitivityMinor'
            self.rsHttpFloodMaxSourceConnectionFading = 'rsHttpFloodMaxSourceConnectionFading'
            self.rsHttpFloodMinGetPostLearn = 'rsHttpFloodMinGetPostLearn'
            self.rsHttpFloodMinOtherLearn = 'rsHttpFloodMinOtherLearn'
            self.rsHttpFloodMinOutboundLearn = 'rsHttpFloodMinOutboundLearn'
            self.rsHttpFloodMinRequestConLearn = 'rsHttpFloodMinRequestConLearn'
            self.rsHttpFloodMinRequestSrcLearn = 'rsHttpFloodMinRequestSrcLearn'
            self.rsHttpFloodTrapBufferLowThreshold = 'rsHttpFloodTrapBufferLowThreshold'
            self.rsHttpFloodLowHitRate = 'rsHttpFloodLowHitRate'
            self.rsHttpFloodHitRate = 'rsHttpFloodHitRate'
            self.rsHttpFloodSingleRqstAttck = 'rsHttpFloodSingleRqstAttck'
            self.rsHttpCharPersist = 'rsHttpCharPersist'
            self.rsHttpCharExpir = 'rsHttpCharExpir'
            self.rsHTTPFClearAuthUserOnNegFeedback = 'rsHTTPFClearAuthUserOnNegFeedback'
            self.rsIDSHttpfldPipelineStatus = 'rsIDSHttpfldPipelineStatus'

        def __call__(self):
            return 'RsHttpFlood'

    class RsSignalingPolicyEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.status = 'status'
            self.name = 'name'
            self.sourceNwPoliciesAll = 'sourceNwPoliciesAll'
            self.sourceNwPolicyGroupId = 'sourceNwPolicyGroupId'
            self.sourceServersAll = 'sourceServersAll'
            self.sourceServerGroupId = 'sourceServerGroupId'
            self.mode = 'mode'
            self.customerName = 'customerName'
            self.customerInformation = 'customerInformation'
            self.pipeSize = 'pipeSize'
            self.bdosCategory = 'bdosCategory'
            self.dnsCategory = 'dnsCategory'
            self.antiscanCategory = 'antiscanCategory'
            self.sigprotCategory = 'sigprotCategory'
            self.conlimitCategory = 'conlimitCategory'
            self.synfloodCategory = 'synfloodCategory'
            self.ppsCategory = 'ppsCategory'
            self.httpfloodCategory = 'httpfloodCategory'
            self.crackingCategory = 'crackingCategory'
            self.oosCategory = 'oosCategory'
            self.accessCategory = 'accessCategory'
            self.syslogServer = 'syslogServer'
            self.id = 'id'

        def __call__(self):
            return 'RsSignalingPolicyEntry'

    class Interfaces:
        def __init__(self):
            self.ifNumber = 'ifNumber'

        def __call__(self):
            return 'Interfaces'

    class RsCPTerminalHostnameEntry:
        def __init__(self):
            self.status = 'status'
            self.dispString = 'dispString'

        def __call__(self):
            return 'RsCPTerminalHostnameEntry'

    class RdwrSnmpErrorTbEntry:
        def __init__(self):
            self.varId = 'varId'
            self.description = 'description'
            self.errorIndex = 'errorIndex'
            self.type = 'type'
            self.status = 'status'
            self.fieldInEntry = 'fieldInEntry'
            self.time = 'time'
            self.date = 'date'
            self.requestId = 'requestId'

        def __call__(self):
            return 'RdwrSnmpErrorTbEntry'

    class RsAPMGlobalParameters:
        def __init__(self):
            self.rsAPMSamplingAlgorithm = 'rsAPMSamplingAlgorithm'
            self.rsAPMSamplingRate = 'rsAPMSamplingRate'
            self.rsAPMUsePreciseSampling = 'rsAPMUsePreciseSampling'
            self.rsAPMTimerMode = 'rsAPMTimerMode'
            self.rsAPMInsiteConfigurationId = 'rsAPMInsiteConfigurationId'

        def __call__(self):
            return 'RsAPMGlobalParameters'

    class RsAPMAlertVariables:
        def __init__(self):
            self.rsAPMAlertVariableMonitorDataItemValueList = 'rsAPMAlertVariableMonitorDataItemValueList'

        def __call__(self):
            return 'RsAPMAlertVariables'

    class LreVnResposibilityEntry:
        def __init__(self):
            self.respStatus = 'respStatus'
            self.respVn = 'respVn'

        def __call__(self):
            return 'LreVnResposibilityEntry'

    class RsBWMRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.status = 'status'
            self.action = 'action'
            self.direction = 'direction'
            self.priority = 'priority'
            self.physicalPort = 'physicalPort'
            self.type = 'type'
            self.description = 'description'
            self.guaranteedBW = 'guaranteedBW'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.operationalStatus = 'operationalStatus'
            self.dSCPMarking = 'dSCPMarking'
            self.reportBlockedPackets = 'reportBlockedPackets'
            self.maxBW = 'maxBW'
            self.specific = 'specific'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.policyGroup = 'policyGroup'
            self.radiusRule = 'radiusRule'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMRulesEntry'

    class RsDnsrStaticResEntry:
        def __init__(self):
            self.sIp = 'sIp'
            self.srowStatus = 'srowStatus'
            self.sUrl = 'sUrl'

        def __call__(self):
            return 'RsDnsrStaticResEntry'

    class RndMng:
        def __init__(self):
            self.rndSysId = 'rndSysId'
            self.rndAction = 'rndAction'
            self.rndFileName = 'rndFileName'
            self.removeViewTablePermissionReductionCheck = 'removeViewTablePermissionReductionCheck'
            self.rsConfigurationAuditStatus = 'rsConfigurationAuditStatus'
            self.rdwrPrintToLogAndCli = 'rdwrPrintToLogAndCli'
            self.rdwrClearTheLogFile = 'rdwrClearTheLogFile'
            self.rdwrAutoRowGenerationStatus = 'rdwrAutoRowGenerationStatus'
            self.rsConfigurationAuditingType = 'rsConfigurationAuditingType'

        def __call__(self):
            return 'RndMng'

    class RsIDSSignaturesAttributeAttackListEntry:
        def __init__(self):
            self.attackName = 'attackName'
            self.attackSourceType = 'attackSourceType'
            self.status = 'status'
            self.attributeType = 'attributeType'
            self.attributeName = 'attributeName'
            self.attackID = 'attackID'

        def __call__(self):
            return 'RsIDSSignaturesAttributeAttackListEntry'

    class SnmpTargetAddrExtEntry:
        def __init__(self):
            self.tMask = 'tMask'
            self.mms = 'mms'
            self.security = 'security'
            self.health = 'health'
            self.audit = 'audit'
            self.name = 'name'

        def __call__(self):
            return 'SnmpTargetAddrExtEntry'

    class RsWSDPingPortsEntry:
        def __init__(self):
            self.physicalPortState = 'physicalPortState'
            self.physicalPortNumber = 'physicalPortNumber'

        def __call__(self):
            return 'RsWSDPingPortsEntry'

    class RsIDSFilterEntry:
        def __init__(self):
            self.protocol = 'protocol'
            self.oMPCOffset = 'oMPCOffset'
            self.oMPCMask = 'oMPCMask'
            self.oMPCPattern = 'oMPCPattern'
            self.oMPCCondition = 'oMPCCondition'
            self.oMPCLength = 'oMPCLength'
            self.contentOffset = 'contentOffset'
            self.content = 'content'
            self.contentType = 'contentType'
            self.type = 'type'
            self.status = 'status'
            self.contentEnd = 'contentEnd'
            self.contentData = 'contentData'
            self.contentCoding = 'contentCoding'
            self.contentDataCoding = 'contentDataCoding'
            self.oMPCOffsetBase = 'oMPCOffsetBase'
            self.sourceAppPortGroup = 'sourceAppPortGroup'
            self.destinationAppPortGroup = 'destinationAppPortGroup'
            self.distanceRange = 'distanceRange'
            self.regExpContent = 'regExpContent'
            self.regExpContentData = 'regExpContentData'
            self.packetSizeType = 'packetSizeType'
            self.packetSizeRange = 'packetSizeRange'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSFilterEntry'

    class RsIDSSignaturesProfileParamsEntry:
        def __init__(self):
            self.simulationStatus = 'simulationStatus'
            self.simulationDuration = 'simulationDuration'
            self.simulationStopAtAttackEnd = 'simulationStopAtAttackEnd'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSignaturesProfileParamsEntry'

    class RsBWMCurrentAppPortGroupEntry:
        def __init__(self):
            self.type = 'type'
            self.name = 'name'
            self.fromPort = 'fromPort'
            self.toPort = 'toPort'

        def __call__(self):
            return 'RsBWMCurrentAppPortGroupEntry'

    class RsTrafficUtilizationPerPortEntrySCTP:
        def __init__(self):
            self.droppedPacketsPerPortSCTP = 'droppedPacketsPerPortSCTP'
            self.droppedBytesPerPortSCTP = 'droppedBytesPerPortSCTP'
            self.receivedPacketsPerPortSCTP = 'receivedPacketsPerPortSCTP'
            self.receivedBytesPerPortSCTP = 'receivedBytesPerPortSCTP'
            self.excludedPacketsPerPortSCTP = 'excludedPacketsPerPortSCTP'
            self.excludedBytesPerPortSCTP = 'excludedBytesPerPortSCTP'
            self.portPerPortSCTP = 'portPerPortSCTP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntrySCTP'

    class RsSESSIONSynProtectionTuning:
        def __init__(self):
            self.rsSESSIONSynProtectionEntries = 'rsSESSIONSynProtectionEntries'
            self.rsSESSIONSynProtectionEntriesAfterReset = 'rsSESSIONSynProtectionEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSynProtectionTuning'

    class RsScheduleEntry:
        def __init__(self):
            self.frequency = 'frequency'
            self.time = 'time'
            self.days = 'days'
            self.date = 'date'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsScheduleEntry'

    class RsMLBRemoteConnectivityEntry:
        def __init__(self):
            self.mLBRmtConStatus = 'mLBRmtConStatus'
            self.mLBRmtConOperStatus = 'mLBRmtConOperStatus'
            self.mLBRmtConSrvrAddr = 'mLBRmtConSrvrAddr'
            self.mLBRmtConIpAddr = 'mLBRmtConIpAddr'

        def __call__(self):
            return 'RsMLBRemoteConnectivityEntry'

    class RsBWMGroupTuning:
        def __init__(self):
            self.rsBWMGroupEntries = 'rsBWMGroupEntries'
            self.rsBWMGroupEntriesAfterReset = 'rsBWMGroupEntriesAfterReset'

        def __call__(self):
            return 'RsBWMGroupTuning'

    class VirtualLan:
        def __init__(self):
            self.virtualLanAutoConfAgingTimeout = 'virtualLanAutoConfAgingTimeout'

        def __call__(self):
            return 'VirtualLan'

    class RsIDSFPRisk:
        def __init__(self):
            self.rsIDSFPRiskStatus = 'rsIDSFPRiskStatus'
            self.rsIDSFPRiskReportPeriod = 'rsIDSFPRiskReportPeriod'

        def __call__(self):
            return 'RsIDSFPRisk'

    class RsMLBStaticNatEntry:
        def __init__(self):
            self.fromNatAddress = 'fromNatAddress'
            self.toNatAddress = 'toNatAddress'
            self.status = 'status'
            self.mode = 'mode'
            self.fromLclServerAddress = 'fromLclServerAddress'
            self.toLclServerAddress = 'toLclServerAddress'
            self.routerAddress = 'routerAddress'

        def __call__(self):
            return 'RsMLBStaticNatEntry'

    class RsAPMPolicyEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.name = 'name'
            self.enabledStatus = 'enabledStatus'
            self.description = 'description'
            self.destination = 'destination'
            self.source = 'source'
            self.filter = 'filter'
            self.filterType = 'filterType'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.l4Protocol = 'l4Protocol'
            self.l7Protocol = 'l7Protocol'
            self.reportInterval = 'reportInterval'
            self.reportSubInterval = 'reportSubInterval'
            self.nextReportIntervalID = 'nextReportIntervalID'
            self.remainingTimeTillNextReportIntervalStart = 'remainingTimeTillNextReportIntervalStart'
            self.reportViaSrp = 'reportViaSrp'
            self.insiteInfo = 'insiteInfo'
            self.id = 'id'

        def __call__(self):
            return 'RsAPMPolicyEntry'

    class RsSignalingReportBdosEntry:
        def __init__(self):
            self.sigRprtBdosDeviceName = 'sigRprtBdosDeviceName'
            self.sigRprtBdosTimestamp = 'sigRprtBdosTimestamp'
            self.sigRprtBdosCustomerName = 'sigRprtBdosCustomerName'
            self.sigRprtBdosCustomerDesc = 'sigRprtBdosCustomerDesc'
            self.sigRprtBdosProtectedNw = 'sigRprtBdosProtectedNw'
            self.sigRprtBdosUdpInXml = 'sigRprtBdosUdpInXml'
            self.sigRprtBdosUdpOutXml = 'sigRprtBdosUdpOutXml'
            self.sigRprtBdosIcmpInXml = 'sigRprtBdosIcmpInXml'
            self.sigRprtBdosIcmpOutXml = 'sigRprtBdosIcmpOutXml'
            self.sigRprtBdosIgmpInXml = 'sigRprtBdosIgmpInXml'
            self.sigRprtBdosIgmpOutXml = 'sigRprtBdosIgmpOutXml'
            self.sigRprtBdosSynInXml = 'sigRprtBdosSynInXml'
            self.sigRprtBdosSynOutXml = 'sigRprtBdosSynOutXml'
            self.sigRprtBdosRstInXml = 'sigRprtBdosRstInXml'
            self.sigRprtBdosRstOutXml = 'sigRprtBdosRstOutXml'
            self.sigRprtBdosAckInXml = 'sigRprtBdosAckInXml'
            self.sigRprtBdosAckOutXml = 'sigRprtBdosAckOutXml'
            self.sigRprtBdosAckPushInXml = 'sigRprtBdosAckPushInXml'
            self.sigRprtBdosAckPushOutXml = 'sigRprtBdosAckPushOutXml'
            self.sigRprtBdosAckFinInXml = 'sigRprtBdosAckFinInXml'
            self.sigRprtBdosAckFinOutXml = 'sigRprtBdosAckFinOutXml'
            self.sigRprtBdosSynAckInXml = 'sigRprtBdosSynAckInXml'
            self.sigRprtBdosSynAckOutXml = 'sigRprtBdosSynAckOutXml'
            self.sigRprtBdosTcpFragInXml = 'sigRprtBdosTcpFragInXml'
            self.sigRprtBdosTcpFragOutXml = 'sigRprtBdosTcpFragOutXml'
            self.sigRprtBdosUdpFragInXml = 'sigRprtBdosUdpFragInXml'
            self.sigRprtBdosUdpFragOutXml = 'sigRprtBdosUdpFragOutXml'
            self.sigRprtBdosNwPolicyName = 'sigRprtBdosNwPolicyName'

        def __call__(self):
            return 'RsSignalingReportBdosEntry'

    class RsMaxIpxSapEntriesTuning:
        def __init__(self):
            self.rsMaxIpxSapEntries = 'rsMaxIpxSapEntries'
            self.rsMaxIpxSapEntriesAfterReset = 'rsMaxIpxSapEntriesAfterReset'

        def __call__(self):
            return 'RsMaxIpxSapEntriesTuning'

    class RsIDSMPLSRDTableEntry:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.rd = 'rd'
            self.upperTag = 'upperTag'
            self.lowerTag = 'lowerTag'

        def __call__(self):
            return 'RsIDSMPLSRDTableEntry'

    class RsAPMMonitorEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.type = 'type'
            self.farmID = 'farmID'
            self.directionOrientation = 'directionOrientation'
            self.itemsToCollect = 'itemsToCollect'
            self.policyID = 'policyID'
            self.id = 'id'

        def __call__(self):
            return 'RsAPMMonitorEntry'

    class RsBWMPolicyEntry:
        def __init__(self):
            self.name = 'name'
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.action = 'action'
            self.direction = 'direction'
            self.priority = 'priority'
            self.type = 'type'
            self.description = 'description'
            self.guaranteedBW = 'guaranteedBW'
            self.filterType = 'filterType'
            self.filter = 'filter'
            self.operationalStatus = 'operationalStatus'
            self.reportBlockedPackets = 'reportBlockedPackets'
            self.maxBW = 'maxBW'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.specific = 'specific'
            self.status = 'status'
            self.radiusRule = 'radiusRule'
            self.key = 'key'

        def __call__(self):
            return 'RsBWMPolicyEntry'

    class RndIfEntry:
        def __init__(self):
            self.boardNum = 'boardNum'
            self.netAddress = 'netAddress'
            self.status = 'status'
            self.clockType = 'clockType'
            self.baudRate = 'baudRate'
            self.cost = 'cost'
            self.compression = 'compression'
            self.compressionStatus = 'compressionStatus'
            self.compressionRate = 'compressionRate'
            self.lATCompression = 'lATCompression'
            self.compressionType = 'compressionType'
            self.filterMode = 'filterMode'
            self.channelType = 'channelType'
            self.bridge = 'bridge'
            self.highPriorityIf = 'highPriorityIf'
            self.wanHeader = 'wanHeader'
            self.duplexMode = 'duplexMode'
            self.index = 'index'

        def __call__(self):
            return 'RndIfEntry'

    class RsMLBDailyStatisticsEntry:
        def __init__(self):
            self.discardedSessionsNumber = 'discardedSessionsNumber'
            self.status = 'status'
            self.month = 'month'
            self.day = 'day'

        def __call__(self):
            return 'RsMLBDailyStatisticsEntry'

    class Dot3adAggEntry:
        def __init__(self):
            self.mACAddress = 'mACAddress'
            self.actorSystemPriority = 'actorSystemPriority'
            self.actorSystemID = 'actorSystemID'
            self.aggregateOrIndividual = 'aggregateOrIndividual'
            self.actorAdminKey = 'actorAdminKey'
            self.actorOperKey = 'actorOperKey'
            self.partnerSystemID = 'partnerSystemID'
            self.partnerSystemPriority = 'partnerSystemPriority'
            self.partnerOperKey = 'partnerOperKey'
            self.collectorMaxDelay = 'collectorMaxDelay'
            self.index = 'index'

        def __call__(self):
            return 'Dot3adAggEntry'

    class RsIDSFootprintEvent:
        def __init__(self):
            self.rsIDSFootprintErrorDesc = 'rsIDSFootprintErrorDesc'
            self.rsIDSFootprintErrorSeverity = 'rsIDSFootprintErrorSeverity'

        def __call__(self):
            return 'RsIDSFootprintEvent'

    class RsSmeEngineUtilizationEntry:
        def __init__(self):
            self.nfaUtilization = 'nfaUtilization'
            self.dfaUtilization = 'dfaUtilization'
            self.dMaUtilization = 'dMaUtilization'
            self.cntTotalTime = 'cntTotalTime'
            self.dfaBusy = 'dfaBusy'
            self.dfaBusyDmaDataStarve = 'dfaBusyDmaDataStarve'
            self.dfaBusyNfaDataStall = 'dfaBusyNfaDataStall'
            self.dfaMemStall = 'dfaMemStall'
            self.nfaBusyReadState = 'nfaBusyReadState'
            self.nfaStateProcessed = 'nfaStateProcessed'
            self.nfaBytesProcessed = 'nfaBytesProcessed'
            self.cntTotalBytes = 'cntTotalBytes'
            self.nfaMemStall = 'nfaMemStall'
            self.nfaStatesAverage = 'nfaStatesAverage'
            self.nfaMemStallsPerByteProc = 'nfaMemStallsPerByteProc'
            self.nfaSatesWhenNfaBusy = 'nfaSatesWhenNfaBusy'
            self.utilizationInstanceId = 'utilizationInstanceId'
            self.sMEEnginesUtilId = 'sMEEnginesUtilId'

        def __call__(self):
            return 'RsSmeEngineUtilizationEntry'

    class RspRadiusRuleEntry:
        def __init__(self):
            self.radiusrowStatus = 'radiusrowStatus'
            self.radiusattId = 'radiusattId'
            self.radiusattValue = 'radiusattValue'
            self.networkName = 'networkName'

        def __call__(self):
            return 'RspRadiusRuleEntry'

    class RsIDSNetfloodWarningEvent:
        def __init__(self):
            self.rsIDSNetfloodWarningErrorDesc = 'rsIDSNetfloodWarningErrorDesc'
            self.rsIDSNetfloodWarningErrorSeverity = 'rsIDSNetfloodWarningErrorSeverity'

        def __call__(self):
            return 'RsIDSNetfloodWarningEvent'

    class RsIDSSignaturesAttributeTypesEntry:
        def __init__(self):
            self.multipleValuesInAttack = 'multipleValuesInAttack'
            self.multipleValuesInRule = 'multipleValuesInRule'
            self.configurableInStatic = 'configurableInStatic'
            self.matchMethod = 'matchMethod'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSignaturesAttributeTypesEntry'

    class RsMLBSubnetGroupEntry:
        def __init__(self):
            self.srvrStatus = 'srvrStatus'
            self.srvrOperMode = 'srvrOperMode'
            self.mLBDestSubnetAddr = 'mLBDestSubnetAddr'
            self.mLBDestSubnetMask = 'mLBDestSubnetMask'
            self.srvrAddr = 'srvrAddr'

        def __call__(self):
            return 'RsMLBSubnetGroupEntry'

    class RdwrMasterInterfaceGroupingPortsEntry:
        def __init__(self):
            self.state = 'state'
            self.number = 'number'

        def __call__(self):
            return 'RdwrMasterInterfaceGroupingPortsEntry'

    class ReaBridgeFftEntry:
        def __init__(self):
            self.brgFftMacAddr = 'brgFftMacAddr'
            self.brgFftReNum = 'brgFftReNum'
            self.brgFftPortNum = 'brgFftPortNum'
            self.brgFftFacsSrcIndex = 'brgFftFacsSrcIndex'
            self.brgFftFacsDstIndex = 'brgFftFacsDstIndex'
            self.brgFftEntryNum = 'brgFftEntryNum'

        def __call__(self):
            return 'ReaBridgeFftEntry'

    class RdwrLastConfigurationChangesEntry:
        def __init__(self):
            self.status = 'status'
            self.mibOid = 'mibOid'
            self.changeType = 'changeType'
            self.keys = 'keys'
            self.id = 'id'

        def __call__(self):
            return 'RdwrLastConfigurationChangesEntry'

    class RsBWMTrafficFlowBWTuning:
        def __init__(self):
            self.rsBWMTrafficFlowBWEntries = 'rsBWMTrafficFlowBWEntries'
            self.rsBWMTrafficFlowBWEntriesAfterReset = 'rsBWMTrafficFlowBWEntriesAfterReset'

        def __call__(self):
            return 'RsBWMTrafficFlowBWTuning'

    class RsMaxRoutingEntriesTuning:
        def __init__(self):
            self.rsMaxRoutingEntries = 'rsMaxRoutingEntries'
            self.rsMaxRoutingEntriesAfterReset = 'rsMaxRoutingEntriesAfterReset'

        def __call__(self):
            return 'RsMaxRoutingEntriesTuning'

    class RsWSDSshParams:
        def __init__(self):
            self.rsWSDSshPort = 'rsWSDSshPort'
            self.rsWSDSshStatus = 'rsWSDSshStatus'
            self.rsWSDSshAllowPwdAndPubKey = 'rsWSDSshAllowPwdAndPubKey'

        def __call__(self):
            return 'RsWSDSshParams'

    class RsSESSIONSynActivationEntry:
        def __init__(self):
            self.time = 'time'
            self.lastSecSYN = 'lastSecSYN'
            self.lastSecRqst = 'lastSecRqst'
            self.avrgSYN = 'avrgSYN'
            self.avrgRqst = 'avrgRqst'
            self.totalSYN = 'totalSYN'
            self.totalDropped = 'totalDropped'
            self.type = 'type'
            self.ip = 'ip'
            self.port = 'port'
            self.rxport = 'rxport'

        def __call__(self):
            return 'RsSESSIONSynActivationEntry'

    class RsSignalingServerSrcGroupEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.id = 'id'
            self.name = 'name'

        def __call__(self):
            return 'RsSignalingServerSrcGroupEntry'

    class RsVWSDDataPermissionsTableEntry:
        def __init__(self):
            self.status = 'status'
            self.vWSDUserGroup = 'vWSDUserGroup'
            self.type = 'type'
            self.items = 'items'

        def __call__(self):
            return 'RsVWSDDataPermissionsTableEntry'

    class RsBWMExtRulesEntry:
        def __init__(self):
            self.fromFarm = 'fromFarm'
            self.toFarm = 'toFarm'
            self.classificationPoint = 'classificationPoint'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.maxRqstsPerSec = 'maxRqstsPerSec'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.status = 'status'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.forceBestFit = 'forceBestFit'
            self.packetMarkingType = 'packetMarkingType'
            self.packetMarkingValue = 'packetMarkingValue'
            self.reportMaxBw = 'reportMaxBw'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMExtRulesEntry'

    class RsWhiteListEntry:
        def __init__(self):
            self.state = 'state'
            self.status = 'status'
            self.allModules = 'allModules'
            self.direction = 'direction'
            self.synModule = 'synModule'
            self.statefulModule = 'statefulModule'
            self.scanningModule = 'scanningModule'
            self.signatureModule = 'signatureModule'
            self.httpFloodModule = 'httpFloodModule'
            self.source = 'source'

        def __call__(self):
            return 'RsWhiteListEntry'

    class RsStatisticsProtocolReportTuning:
        def __init__(self):
            self.rsStatisticsProtocolReportEntries = 'rsStatisticsProtocolReportEntries'
            self.rsStatisticsProtocolReportEntriesAfterReset = 'rsStatisticsProtocolReportEntriesAfterReset'

        def __call__(self):
            return 'RsStatisticsProtocolReportTuning'

    class RsIDSynSSLMitigationEntry:
        def __init__(self):
            self.rsSSLMitigationVIP = 'rsSSLMitigationVIP'
            self.aDCserverDstIP = 'aDCserverDstIP'
            self.inboundPort = 'inboundPort'
            self.outboundPort = 'outboundPort'
            self.mac = 'mac'
            self.policyName = 'policyName'
            self.state = 'state'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSynSSLMitigationEntry'

    class VnsPacketEntry:
        def __init__(self):
            self.protocolTypeMask = 'protocolTypeMask'
            self.iPAddress = 'iPAddress'
            self.iPNetMask = 'iPNetMask'
            self.iPXnetwork = 'iPXnetwork'
            self.stationType = 'stationType'
            self.portGroupId = 'portGroupId'
            self.portId = 'portId'
            self.backbonePort = 'backbonePort'
            self.expectedVLAN = 'expectedVLAN'
            self.detectedVLAN = 'detectedVLAN'
            self.boxAgentIP = 'boxAgentIP'
            self.mACAddress = 'mACAddress'

        def __call__(self):
            return 'VnsPacketEntry'

    class RsSignalingReportDnsEntry:
        def __init__(self):
            self.sigRprtDnsDeviceName = 'sigRprtDnsDeviceName'
            self.sigRprtDnsTimestamp = 'sigRprtDnsTimestamp'
            self.sigRprtDnsCustomerName = 'sigRprtDnsCustomerName'
            self.sigRprtDnsCustomerDesc = 'sigRprtDnsCustomerDesc'
            self.sigRprtDnsProtectedNw = 'sigRprtDnsProtectedNw'
            self.sigRprtDnsAInXml = 'sigRprtDnsAInXml'
            self.sigRprtDnsMxInXml = 'sigRprtDnsMxInXml'
            self.sigRprtDnsPtrInXml = 'sigRprtDnsPtrInXml'
            self.sigRprtDnsAaaaInXml = 'sigRprtDnsAaaaInXml'
            self.sigRprtDnsTextInXml = 'sigRprtDnsTextInXml'
            self.sigRprtDnsSoaInXml = 'sigRprtDnsSoaInXml'
            self.sigRprtDnsNaptrInXml = 'sigRprtDnsNaptrInXml'
            self.sigRprtDnsSrvInXml = 'sigRprtDnsSrvInXml'
            self.sigRprtDnsOtherInXml = 'sigRprtDnsOtherInXml'
            self.sigRprtDnsNwPolicyName = 'sigRprtDnsNwPolicyName'

        def __call__(self):
            return 'RsSignalingReportDnsEntry'

    class RdwrDPTunnelEntry:
        def __init__(self):
            self.ipPrefixLen = 'ipPrefixLen'
            self.desc = 'desc'
            self.ifIndex = 'ifIndex'
            self.primSrcIp = 'primSrcIp'
            self.primDstIp = 'primDstIp'
            self.scndSrcIp = 'scndSrcIp'
            self.scndDstIp = 'scndDstIp'
            self.redundancyState = 'redundancyState'
            self.keepaliveState = 'keepaliveState'
            self.rowStatus = 'rowStatus'
            self.ip = 'ip'

        def __call__(self):
            return 'RdwrDPTunnelEntry'

    class RsStatisticsDiscoveryProtocolEntry:
        def __init__(self):
            self.lastPeriodUsedBW = 'lastPeriodUsedBW'
            self.lastPeriodPeakBW = 'lastPeriodPeakBW'
            self.lastPeriodMatchedPackets = 'lastPeriodMatchedPackets'
            self.name = 'name'
            self.rsStatisticsDiscoveryProtocol = 'rsStatisticsDiscoveryProtocol'
            self.port = 'port'

        def __call__(self):
            return 'RsStatisticsDiscoveryProtocolEntry'

    class RndIpHost:
        def __init__(self):
            self.rndICMPTransmitionEnable = 'rndICMPTransmitionEnable'

        def __call__(self):
            return 'RndIpHost'

    class RsMLBRemoteVIPEntry:
        def __init__(self):
            self.vIPMode = 'vIPMode'
            self.vIPStatus = 'vIPStatus'
            self.vIPAddr = 'vIPAddr'

        def __call__(self):
            return 'RsMLBRemoteVIPEntry'

    class RsIdsDeployment:
        def __init__(self):
            self.rsIdsDeploymentBackToDefault = 'rsIdsDeploymentBackToDefault'

        def __call__(self):
            return 'RsIdsDeployment'

    class RsMLBLocalStationEntry:
        def __init__(self):
            self.mLBIocalStationEntryStatus = 'mLBIocalStationEntryStatus'
            self.serviceName = 'serviceName'
            self.internalStationAddr = 'internalStationAddr'

        def __call__(self):
            return 'RsMLBLocalStationEntry'

    class RsBWMDynamicNetworkTuning:
        def __init__(self):
            self.rsBWMDynamicNetworkEntries = 'rsBWMDynamicNetworkEntries'
            self.rsBWMDynamicNetworkEntriesAfterReset = 'rsBWMDynamicNetworkEntriesAfterReset'

        def __call__(self):
            return 'RsBWMDynamicNetworkTuning'

    class RsIDSConnectionLimitPolicyEntry:
        def __init__(self):
            self.profileName = 'profileName'
            self.source = 'source'
            self.destination = 'destination'
            self.direction = 'direction'
            self.portmask = 'portmask'
            self.state = 'state'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.packetReportingStatus = 'packetReportingStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSConnectionLimitPolicyEntry'

    class RsIDSCountersReportInfoTuning:
        def __init__(self):
            self.rsIDSCountersReportInfoTableSize = 'rsIDSCountersReportInfoTableSize'
            self.rsIDSCountersReportInfoSizeAfterReset = 'rsIDSCountersReportInfoSizeAfterReset'

        def __call__(self):
            return 'RsIDSCountersReportInfoTuning'

    class RsAPMLegFarmEntry:
        def __init__(self):
            self.farmID = 'farmID'
            self.rowStatus = 'rowStatus'
            self.policyID = 'policyID'
            self.index = 'index'

        def __call__(self):
            return 'RsAPMLegFarmEntry'

    class IfEntry:
        def __init__(self):
            self.descr = 'descr'
            self.type = 'type'
            self.mtu = 'mtu'
            self.speed = 'speed'
            self.physAddress = 'physAddress'
            self.adminStatus = 'adminStatus'
            self.operStatus = 'operStatus'
            self.lastChange = 'lastChange'
            self.inOctets = 'inOctets'
            self.inUcastPkts = 'inUcastPkts'
            self.inDiscards = 'inDiscards'
            self.inErrors = 'inErrors'
            self.inUnknownProtos = 'inUnknownProtos'
            self.outOctets = 'outOctets'
            self.outUcastPkts = 'outUcastPkts'
            self.outDiscards = 'outDiscards'
            self.outErrors = 'outErrors'
            self.index = 'index'

        def __call__(self):
            return 'IfEntry'

    class RsTrafficUtilizationPerPolicyEntryUDP:
        def __init__(self):
            self.newConnectionsPerPolicyUDP = 'newConnectionsPerPolicyUDP'
            self.concurConnectionsPerPolicyUDP = 'concurConnectionsPerPolicyUDP'
            self.droppedPacketsPerPolicyUDP = 'droppedPacketsPerPolicyUDP'
            self.droppedBytesPerPolicyUDP = 'droppedBytesPerPolicyUDP'
            self.receivedPacketsPerPolicyUDP = 'receivedPacketsPerPolicyUDP'
            self.receivedBytesPerPolicyUDP = 'receivedBytesPerPolicyUDP'
            self.policyNamePerPolicyUDP = 'policyNamePerPolicyUDP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntryUDP'

    class RsDebugFileEntry:
        def __init__(self):
            self.size = 'size'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsDebugFileEntry'

    class RsExcludeIpEntry:
        def __init__(self):
            self.attackName = 'attackName'
            self.source = 'source'
            self.dest = 'dest'
            self.status = 'status'
            self.attackId = 'attackId'

        def __call__(self):
            return 'RsExcludeIpEntry'

    class SnmpTargetParamsEntry:
        def __init__(self):
            self.mPModel = 'mPModel'
            self.securityModel = 'securityModel'
            self.securityName = 'securityName'
            self.securityLevel = 'securityLevel'
            self.storageType = 'storageType'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'SnmpTargetParamsEntry'

    class RsStatisticsProtocolPolicyTuning:
        def __init__(self):
            self.rsStatisticsProtocolPolicyEntries = 'rsStatisticsProtocolPolicyEntries'
            self.rsStatisticsProtocolPolicyEntriesAfterReset = 'rsStatisticsProtocolPolicyEntriesAfterReset'

        def __call__(self):
            return 'RsStatisticsProtocolPolicyTuning'

    class RsBWMFilterTuning:
        def __init__(self):
            self.rsBWMFilterEntries = 'rsBWMFilterEntries'
            self.rsBWMFilterEntriesAfterReset = 'rsBWMFilterEntriesAfterReset'

        def __call__(self):
            return 'RsBWMFilterTuning'

    class RsIDSSynProtection:
        def __init__(self):
            self.rsIDSSynAttackNextID = 'rsIDSSynAttackNextID'
            self.rsIDSSynProtStatus = 'rsIDSSynProtStatus'
            self.rsIDSSynSrcMonitoring = 'rsIDSSynSrcMonitoring'
            self.rsIDSSynSrcSampling = 'rsIDSSynSrcSampling'
            self.rsIDSSynMaliciousTableAging = 'rsIDSSynMaliciousTableAging'
            self.rsIDSSynTrustedTableAging = 'rsIDSSynTrustedTableAging'
            self.rsIDSSynServerTableAging = 'rsIDSSynServerTableAging'
            self.rsIDSSynSuspeciousToMalicious = 'rsIDSSynSuspeciousToMalicious'
            self.rsIDSSynSuspeciousToTrusted = 'rsIDSSynSuspeciousToTrusted'
            self.rsIDSSynTrustedToMalicious = 'rsIDSSynTrustedToMalicious'
            self.rsIDSSynSessionTableFullPercent = 'rsIDSSynSessionTableFullPercent'
            self.rsIDSSynMaliciousSourceBlockingStatus = 'rsIDSSynMaliciousSourceBlockingStatus'
            self.rsIDSSynTrackingTime = 'rsIDSSynTrackingTime'
            self.rsIDSSynFpga = 'rsIDSSynFpga'
            self.rsIDSynSSLMitigationAlteonMngIP = 'rsIDSynSSLMitigationAlteonMngIP'
            self.rsIDSynSSLMitigationAlteonStatus = 'rsIDSynSSLMitigationAlteonStatus'
            self.rsIDSynSSLMitigationAlteonSnmpAlertPort = 'rsIDSynSSLMitigationAlteonSnmpAlertPort'
            self.rsIDSSynSafeResetLegitRetransmitRangeMin = 'rsIDSSynSafeResetLegitRetransmitRangeMin'
            self.rsIDSSynSafeResetLegitRetransmitRangeMax = 'rsIDSSynSafeResetLegitRetransmitRangeMax'

        def __call__(self):
            return 'RsIDSSynProtection'

    class RndVisionDriver:
        def __init__(self):
            self.rndVisionDriverActiveName = 'rndVisionDriverActiveName'
            self.rndVisionDriverRestoreFromBackup = 'rndVisionDriverRestoreFromBackup'

        def __call__(self):
            return 'RndVisionDriver'

    class RsBWMPPCInboundPortOnlyEntry:
        def __init__(self):
            self.bWMPPCOperationStatus = 'bWMPPCOperationStatus'
            self.rsBWMPPCInboundPort = 'rsBWMPPCInboundPort'

        def __call__(self):
            return 'RsBWMPPCInboundPortOnlyEntry'

    class RsIDSNonTuneableMemory:
        def __init__(self):
            self.rsIDSNonTunableMemorySize = 'rsIDSNonTunableMemorySize'
            self.rsIDSNonTunableMemorySizeAfterReset = 'rsIDSNonTunableMemorySizeAfterReset'

        def __call__(self):
            return 'RsIDSNonTuneableMemory'

    class RsTrafficUtilizationPerPortEntryUDP:
        def __init__(self):
            self.droppedPacketsPerPortUDP = 'droppedPacketsPerPortUDP'
            self.droppedBytesPerPortUDP = 'droppedBytesPerPortUDP'
            self.receivedPacketsPerPortUDP = 'receivedPacketsPerPortUDP'
            self.receivedBytesPerPortUDP = 'receivedBytesPerPortUDP'
            self.excludedPacketsPerPortUDP = 'excludedPacketsPerPortUDP'
            self.excludedBytesPerPortUDP = 'excludedBytesPerPortUDP'
            self.portPerPortUDP = 'portPerPortUDP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntryUDP'

    class RsWSDThresholdWarnings:
        def __init__(self):
            self.rsWSDThreshTrapFloodDelay = 'rsWSDThreshTrapFloodDelay'
            self.rsWSDCriticalTrapFloodDelay = 'rsWSDCriticalTrapFloodDelay'

        def __call__(self):
            return 'RsWSDThresholdWarnings'

    class RsCPPeerPhysicalInterfaceEntry:
        def __init__(self):
            self.neighborIPAddress = 'neighborIPAddress'
            self.localRouterIPAddress = 'localRouterIPAddress'
            self.capacity = 'capacity'
            self.incomingLoad = 'incomingLoad'
            self.index = 'index'
            self.operStatus = 'operStatus'
            self.description = 'description'
            self.status = 'status'
            self.interfaceIPAddress = 'interfaceIPAddress'

        def __call__(self):
            return 'RsCPPeerPhysicalInterfaceEntry'

    class RdwrFtpParameters:
        def __init__(self):
            self.rdwrFtpPort = 'rdwrFtpPort'
            self.rdwrFtpStatus = 'rdwrFtpStatus'

        def __call__(self):
            return 'RdwrFtpParameters'

    class RndBridgeAlarm:
        def __init__(self):
            self.rndErrorDesc = 'rndErrorDesc'
            self.rndErrorSeverity = 'rndErrorSeverity'

        def __call__(self):
            return 'RndBridgeAlarm'

    class RdwrDualPowerSupplyParams:
        def __init__(self):
            self.rdwrPowerSupply1Status = 'rdwrPowerSupply1Status'
            self.rdwrPowerSupply2Status = 'rdwrPowerSupply2Status'
            self.rdwrPowerSupplyTrapStatus = 'rdwrPowerSupplyTrapStatus'
            self.rdwrPowerSupplyStatus = 'rdwrPowerSupplyStatus'

        def __call__(self):
            return 'RdwrDualPowerSupplyParams'

    class RsTrafficUtilizationPerPortEntryICMP:
        def __init__(self):
            self.droppedPacketsPerPortICMP = 'droppedPacketsPerPortICMP'
            self.droppedBytesPerPortICMP = 'droppedBytesPerPortICMP'
            self.receivedPacketsPerPortICMP = 'receivedPacketsPerPortICMP'
            self.receivedBytesPerPortICMP = 'receivedBytesPerPortICMP'
            self.excludedPacketsPerPortICMP = 'excludedPacketsPerPortICMP'
            self.excludedBytesPerPortICMP = 'excludedBytesPerPortICMP'
            self.portPerPortICMP = 'portPerPortICMP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntryICMP'

    class RsMLBRemoteNatEntriesTuning:
        def __init__(self):
            self.rsRNatMaxLclServiceEntries = 'rsRNatMaxLclServiceEntries'
            self.rsRNatMaxLclServiceEntriesAfterReset = 'rsRNatMaxLclServiceEntriesAfterReset'
            self.rsRNatMaxRemServiceEntries = 'rsRNatMaxRemServiceEntries'
            self.rsRNatMaxRemServiceEntriesAfterReset = 'rsRNatMaxRemServiceEntriesAfterReset'
            self.rsRNatMaxTunnelEntries = 'rsRNatMaxTunnelEntries'
            self.rsRNatMaxTunnelEntriesAfterReset = 'rsRNatMaxTunnelEntriesAfterReset'
            self.rsRNatMaxLclStationEntries = 'rsRNatMaxLclStationEntries'
            self.rsRNatMaxLclStationEntriesAfterReset = 'rsRNatMaxLclStationEntriesAfterReset'
            self.rsRNatMaxRemStationEntries = 'rsRNatMaxRemStationEntries'
            self.rsRNatMaxRemStationEntriesAfterReset = 'rsRNatMaxRemStationEntriesAfterReset'

        def __call__(self):
            return 'RsMLBRemoteNatEntriesTuning'

    class RsIDSLoopConfigurationTableEntry:
        def __init__(self):
            self.lOOPTblEntryPortName = 'lOOPTblEntryPortName'
            self.lOOPTblEntryPortInbound = 'lOOPTblEntryPortInbound'
            self.lOOPTblEntryPortOutbound = 'lOOPTblEntryPortOutbound'
            self.lOOPTblEntryPortIndex = 'lOOPTblEntryPortIndex'

        def __call__(self):
            return 'RsIDSLoopConfigurationTableEntry'

    class RsHWCPUTemperatureEntry:
        def __init__(self):
            self.value = 'value'
            self.index = 'index'

        def __call__(self):
            return 'RsHWCPUTemperatureEntry'

    class RndFACSEntry:
        def __init__(self):
            self.fACSSrcAdd = 'fACSSrcAdd'
            self.fACSSrcAddMask = 'fACSSrcAddMask'
            self.fACSDesAdd = 'fACSDesAdd'
            self.fACSDesAddMask = 'fACSDesAddMask'
            self.fACSOperation = 'fACSOperation'
            self.fACSNetFiltering = 'fACSNetFiltering'
            self.fACSSoketNum = 'fACSSoketNum'
            self.fACSMask1Id = 'fACSMask1Id'
            self.fACSMask2Id = 'fACSMask2Id'
            self.fACSStatus = 'fACSStatus'
            self.fACSIfIndex = 'fACSIfIndex'
            self.fACSProtocolType = 'fACSProtocolType'
            self.fACSType = 'fACSType'
            self.fACSIndex = 'fACSIndex'

        def __call__(self):
            return 'RndFACSEntry'

    class RsIDSStaticGroupEntry:
        def __init__(self):
            self.name = 'name'

        def __call__(self):
            return 'RsIDSStaticGroupEntry'

    class RsBWMDynamicNetworkIPTuning:
        def __init__(self):
            self.rsBWMDynamicNetworkIPHashEntries = 'rsBWMDynamicNetworkIPHashEntries'
            self.rsBWMDynamicNetworkIPHashEntriesAfterReset = 'rsBWMDynamicNetworkIPHashEntriesAfterReset'

        def __call__(self):
            return 'RsBWMDynamicNetworkIPTuning'

    class RsIDSSignaturesAttackAttributesEntry:
        def __init__(self):
            self.typeId = 'typeId'
            self.value = 'value'
            self.status = 'status'
            self.attackId = 'attackId'
            self.type = 'type'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSignaturesAttackAttributesEntry'

    class RsCP:
        def __init__(self):
            self.prependInterval = 'prependInterval'
            self.redistributeInterval = 'redistributeInterval'
            self.criticalPeerLoadThreshold = 'criticalPeerLoadThreshold'
            self.optimalPeerLoad = 'optimalPeerLoad'
            self.adequateTotalPeakLoad = 'adequateTotalPeakLoad'
            self.optimalTotalPeakLoad = 'optimalTotalPeakLoad'
            self.subPeriodInterval = 'subPeriodInterval'
            self.routerPollingInterval = 'routerPollingInterval'
            self.routerPollingIntervalTimeout = 'routerPollingIntervalTimeout'
            self.initializeInterval = 'initializeInterval'
            self.localASNumber = 'localASNumber'
            self.prefixListPrefix = 'prefixListPrefix'
            self.prependsNumber = 'prependsNumber'
            self.prevStatisticsWeight = 'prevStatisticsWeight'
            self.operationMode = 'operationMode'
            self.flowExportPort = 'flowExportPort'
            self.statisticsCollectionMethod = 'statisticsCollectionMethod'
            self.pDRedundancyStatus = 'pDRedundancyStatus'
            self.costAdminStatus = 'costAdminStatus'
            self.costWeight = 'costWeight'
            self.loadWeight = 'loadWeight'

        def __call__(self):
            return 'RsCP'

    class RsHTTPFServerEntry:
        def __init__(self):
            self.ip = 'ip'
            self.sensitivity = 'sensitivity'
            self.action = 'action'
            self.packetReport = 'packetReport'
            self.setManTriggers = 'setManTriggers'
            self.getPostTrs = 'getPostTrs'
            self.otherTrs = 'otherTrs'
            self.outboundBandwidth = 'outboundBandwidth'
            self.requestsPerSource = 'requestsPerSource'
            self.requestsPerConnection = 'requestsPerConnection'
            self.status = 'status'
            self.uriOnlyMitigation = 'uriOnlyMitigation'
            self.name = 'name'

        def __call__(self):
            return 'RsHTTPFServerEntry'

    class RsMLBRemoteServiceEntry:
        def __init__(self):
            self.password = 'password'
            self.domainName = 'domainName'
            self.loadBalanceMethod = 'loadBalanceMethod'
            self.localServiceName = 'localServiceName'
            self.operStatus = 'operStatus'
            self.trpOperationStatus = 'trpOperationStatus'
            self.hMOperationStatus = 'hMOperationStatus'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBRemoteServiceEntry'

    class SnmpSet:
        def __init__(self):
            self.snmpSetSerialNo = 'snmpSetSerialNo'

        def __call__(self):
            return 'SnmpSet'

    class RsTrafficUtilizationPerPortEntryTCP:
        def __init__(self):
            self.droppedPacketsPerPortTCP = 'droppedPacketsPerPortTCP'
            self.droppedBytesPerPortTCP = 'droppedBytesPerPortTCP'
            self.receivedPacketsPerPortTCP = 'receivedPacketsPerPortTCP'
            self.receivedBytesPerPortTCP = 'receivedBytesPerPortTCP'
            self.excludedPacketsPerPortTCP = 'excludedPacketsPerPortTCP'
            self.excludedBytesPerPortTCP = 'excludedBytesPerPortTCP'
            self.portPerPortTCP = 'portPerPortTCP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntryTCP'

    class RsIDSIntrusionEvent:
        def __init__(self):
            self.rsIDSIntrusionErrorDesc = 'rsIDSIntrusionErrorDesc'
            self.rsIDSIntrusionErrorSeverity = 'rsIDSIntrusionErrorSeverity'

        def __call__(self):
            return 'RsIDSIntrusionEvent'

    class RsWSDPrivateCheckEntry:
        def __init__(self):
            self.specialCheckPeriod = 'specialCheckPeriod'
            self.extraVar1ID = 'extraVar1ID'
            self.extraVar1Weight = 'extraVar1Weight'
            self.extraVar2ID = 'extraVar2ID'
            self.extraVar2Weight = 'extraVar2Weight'
            self.retries = 'retries'
            self.community = 'community'
            self.extraVar1Mode = 'extraVar1Mode'
            self.extraVar2Mode = 'extraVar2Mode'
            self.serialNum = 'serialNum'

        def __call__(self):
            return 'RsWSDPrivateCheckEntry'

    class VrrpOperations:
        def __init__(self):
            self.vrrpNodeVersion = 'vrrpNodeVersion'
            self.vrrpNotificationCntl = 'vrrpNotificationCntl'

        def __call__(self):
            return 'VrrpOperations'

    class RsGeneric:
        def __init__(self):
            self.rsTunnelingMode = 'rsTunnelingMode'
            self.rsIpVersionMode = 'rsIpVersionMode'
            self.dpFtpStatus = 'dpFtpStatus'
            self.dpFtpControlAgingTime = 'dpFtpControlAgingTime'
            self.dpFtpDataAgingTime = 'dpFtpDataAgingTime'
            self.dpFtpControlPorts = 'dpFtpControlPorts'
            self.dpTftpStatus = 'dpTftpStatus'
            self.dpTftpDataAgingTime = 'dpTftpDataAgingTime'
            self.dpTftpControlPorts = 'dpTftpControlPorts'
            self.dpRshellStatus = 'dpRshellStatus'
            self.dpRshellControlAgingTime = 'dpRshellControlAgingTime'
            self.dpRshellDataAgingTime = 'dpRshellDataAgingTime'
            self.dpRshellControlPorts = 'dpRshellControlPorts'
            self.dpRexecStatus = 'dpRexecStatus'
            self.dpRexecControlAgingTime = 'dpRexecControlAgingTime'
            self.dpRexecDataAgingTime = 'dpRexecDataAgingTime'
            self.dpRexecControlPorts = 'dpRexecControlPorts'
            self.dpH225Status = 'dpH225Status'
            self.dpH225ControlAgingTime = 'dpH225ControlAgingTime'
            self.dpH225DataAgingTime = 'dpH225DataAgingTime'
            self.dpH225ControlPorts = 'dpH225ControlPorts'
            self.dpSIPStatus = 'dpSIPStatus'
            self.dpSIPSignalAgingTime = 'dpSIPSignalAgingTime'
            self.dpSIPRTCPAgingTime = 'dpSIPRTCPAgingTime'
            self.dpSIPControlPorts = 'dpSIPControlPorts'
            self.dpsTCPSegmentAgingTime = 'dpsTCPSegmentAgingTime'
            self.dpRTSPStatus = 'dpRTSPStatus'
            self.dpRTSPControlAgingTime = 'dpRTSPControlAgingTime'
            self.dpRTSPDataAgingTime = 'dpRTSPDataAgingTime'
            self.dpRTSPControlPorts = 'dpRTSPControlPorts'
            self.rsDebugSnapshotStatus = 'rsDebugSnapshotStatus'
            self.rsDebugSnapshotOutputToFile = 'rsDebugSnapshotOutputToFile'
            self.rsDebugSnapshotOutputToTerm = 'rsDebugSnapshotOutputToTerm'
            self.rsDebugTraceStatus = 'rsDebugTraceStatus'
            self.rsDebugTraceOutputToFile = 'rsDebugTraceOutputToFile'
            self.rsDebugTraceOutputToTerm = 'rsDebugTraceOutputToTerm'
            self.rsDebugTraceOutputToSysLog = 'rsDebugTraceOutputToSysLog'
            self.rsDebugTraceMsgFormatDate = 'rsDebugTraceMsgFormatDate'
            self.rsDebugTraceMsgFormatTime = 'rsDebugTraceMsgFormatTime'
            self.rsDebugTraceMsgFormatPlatform = 'rsDebugTraceMsgFormatPlatform'
            self.rsDebugTraceMsgFormatFile = 'rsDebugTraceMsgFormatFile'
            self.rsDebugTraceMsgFormatLine = 'rsDebugTraceMsgFormatLine'
            self.rsDebugTraceMsgFormatPcktId = 'rsDebugTraceMsgFormatPcktId'
            self.rsDebugTraceMsgFormatModule = 'rsDebugTraceMsgFormatModule'
            self.rsDebugTraceMsgFormatTask = 'rsDebugTraceMsgFormatTask'
            self.rsDebugSnapshotPoint = 'rsDebugSnapshotPoint'
            self.rsDebugFileTFTPSendSrc = 'rsDebugFileTFTPSendSrc'
            self.rsDebugFileDelete = 'rsDebugFileDelete'
            self.rsDebugFileTFTPSendDst = 'rsDebugFileTFTPSendDst'
            self.rsDebugSnapshotMode = 'rsDebugSnapshotMode'
            self.rsPortStatsTotalInMbitsPerSec = 'rsPortStatsTotalInMbitsPerSec'
            self.rsDebugSnapshotRate = 'rsDebugSnapshotRate'
            self.rsTunnelingModeProtocolGre = 'rsTunnelingModeProtocolGre'
            self.rsTunnelingModeProtocolGtp = 'rsTunnelingModeProtocolGtp'
            self.rsTunnelingModeProtocolL2tp = 'rsTunnelingModeProtocolL2tp'
            self.rsTunnelingModeProtocolVlan = 'rsTunnelingModeProtocolVlan'
            self.rsTunnelingModeProtocolIpInIp = 'rsTunnelingModeProtocolIpInIp'
            self.rsTunnelingModeProtocolInner = 'rsTunnelingModeProtocolInner'
            self.rsTunnelingModeProtocolIpsecBypass = 'rsTunnelingModeProtocolIpsecBypass'
            self.rdwrIntConfSyncConfigTimestamp = 'rdwrIntConfSyncConfigTimestamp'

        def __call__(self):
            return 'RsGeneric'

    class EventMessageEntry:
        def __init__(self):
            self.desc = 'desc'
            self.num = 'num'

        def __call__(self):
            return 'EventMessageEntry'

    class RsHttpFloodUriBypassEntry:
        def __init__(self):
            self.status = 'status'
            self.serverName = 'serverName'
            self.name = 'name'

        def __call__(self):
            return 'RsHttpFloodUriBypassEntry'

    class RsBWMAppPortGroupTuning:
        def __init__(self):
            self.rsBWMAppPortGroupTuningEntries = 'rsBWMAppPortGroupTuningEntries'
            self.rsBWMAppPortGroupTuningEntriesAfterReset = 'rsBWMAppPortGroupTuningEntriesAfterReset'

        def __call__(self):
            return 'RsBWMAppPortGroupTuning'

    class RdwrTerminalParams:
        def __init__(self):
            self.rdwrTerminalPrompt = 'rdwrTerminalPrompt'

        def __call__(self):
            return 'RdwrTerminalParams'

    class RsMaxIpForwardingEntriesTuning:
        def __init__(self):
            self.rsMaxIpFrwEntries = 'rsMaxIpFrwEntries'
            self.rsMaxIpFrwEntriesAfterReset = 'rsMaxIpFrwEntriesAfterReset'

        def __call__(self):
            return 'RsMaxIpForwardingEntriesTuning'

    class RsMaxRadiusEntriesTuning:
        def __init__(self):
            self.rsMaxRadiusUsersEntries = 'rsMaxRadiusUsersEntries'
            self.rsMaxRadiusUsersEntriesAfterReset = 'rsMaxRadiusUsersEntriesAfterReset'
            self.rsMaxRadiusNasAuthEntries = 'rsMaxRadiusNasAuthEntries'
            self.rsMaxRadiusNasAuthEntriesAfterReset = 'rsMaxRadiusNasAuthEntriesAfterReset'

        def __call__(self):
            return 'RsMaxRadiusEntriesTuning'

    class RsBWMExtPolicyEntry:
        def __init__(self):
            self.name = 'name'
            self.fromFarm = 'fromFarm'
            self.toFarm = 'toFarm'
            self.classificationPoint = 'classificationPoint'
            self.trafficIdentification = 'trafficIdentification'
            self.trafficFlowMaxBW = 'trafficFlowMaxBW'
            self.maxConcurrentSessions = 'maxConcurrentSessions'
            self.maxRqstsPerSec = 'maxRqstsPerSec'
            self.trafficIDCookieField = 'trafficIDCookieField'
            self.status = 'status'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.forceBestFit = 'forceBestFit'
            self.packetMarkingType = 'packetMarkingType'
            self.packetMarkingValue = 'packetMarkingValue'
            self.reportMaxBw = 'reportMaxBw'
            self.key = 'key'

        def __call__(self):
            return 'RsBWMExtPolicyEntry'

    class WsdRedundEntry:
        def __init__(self):
            self.operStatus = 'operStatus'
            self.pollInterval = 'pollInterval'
            self.timeout = 'timeout'
            self.status = 'status'
            self.farmAddr = 'farmAddr'
            self.mainWsdAddr = 'mainWsdAddr'

        def __call__(self):
            return 'WsdRedundEntry'

    class RsTrafficUtilizationPerPolicyEntryICMP:
        def __init__(self):
            self.newConnectionsPerPolicyICMP = 'newConnectionsPerPolicyICMP'
            self.concurConnectionsPerPolicyICMP = 'concurConnectionsPerPolicyICMP'
            self.droppedPacketsPerPolicyICMP = 'droppedPacketsPerPolicyICMP'
            self.droppedBytesPerPolicyICMP = 'droppedBytesPerPolicyICMP'
            self.receivedPacketsPerPolicyICMP = 'receivedPacketsPerPolicyICMP'
            self.receivedBytesPerPolicyICMP = 'receivedBytesPerPolicyICMP'
            self.policyNamePerPolicyICMP = 'policyNamePerPolicyICMP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntryICMP'

    class RsMLBStaticProximityEntry:
        def __init__(self):
            self.rangeTo = 'rangeTo'
            self.status = 'status'
            self.server1 = 'server1'
            self.server2 = 'server2'
            self.server3 = 'server3'
            self.rangeFrom = 'rangeFrom'

        def __call__(self):
            return 'RsMLBStaticProximityEntry'

    class RsMLBDNSIPAddressEntry:
        def __init__(self):
            self.status = 'status'
            self.rsMLBDNSIPAddress = 'rsMLBDNSIPAddress'

        def __call__(self):
            return 'RsMLBDNSIPAddressEntry'

    class RsIDSSLTNewRulesEntry:
        def __init__(self):
            self.iDSSLTServiceName = 'iDSSLTServiceName'
            self.source = 'source'
            self.destination = 'destination'
            self.direction = 'direction'
            self.portmask = 'portmask'
            self.state = 'state'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSLTNewRulesEntry'

    class RsIDSPPSProfileEntry:
        def __init__(self):
            self.attackId = 'attackId'
            self.status = 'status'
            self.name = 'name'
            self.attackName = 'attackName'

        def __call__(self):
            return 'RsIDSPPSProfileEntry'

    class RsBlackList:
        def __init__(self):
            self.rsNewBlackListPacketTraceStatus = 'rsNewBlackListPacketTraceStatus'
            self.rsNewAccessListListsPriority = 'rsNewAccessListListsPriority'

        def __call__(self):
            return 'RsBlackList'

    class RsBlackListEntry:
        def __init__(self):
            self.state = 'state'
            self.status = 'status'
            self.source = 'source'

        def __call__(self):
            return 'RsBlackListEntry'

    class IpSpecRouteEntry:
        def __init__(self):
            self.metric = 'metric'
            self.port = 'port'
            self.label = 'label'
            self.status = 'status'
            self.dest = 'dest'
            self.pfxLen = 'pfxLen'
            self.nextHop = 'nextHop'

        def __call__(self):
            return 'IpSpecRouteEntry'

    class RsPacketReportData:
        def __init__(self):
            self.rsIDSPacketReportDestPort = 'rsIDSPacketReportDestPort'
            self.rsSystemInternalDataReportMaxPoliciesInSingleIrp = 'rsSystemInternalDataReportMaxPoliciesInSingleIrp'

        def __call__(self):
            return 'RsPacketReportData'

    class System:
        def __init__(self):
            self.sysDescr = 'sysDescr'
            self.sysObjectID = 'sysObjectID'
            self.sysUpTime = 'sysUpTime'
            self.sysContact = 'sysContact'
            self.sysName = 'sysName'
            self.sysLocation = 'sysLocation'
            self.sysServices = 'sysServices'
            self.sysORLastChange = 'sysORLastChange'

        def __call__(self):
            return 'System'

    class RsCPPriceEntry:
        def __init__(self):
            self.method = 'method'
            self.bWUnit = 'bWUnit'
            self.price = 'price'
            self.status = 'status'
            self.neighborIPAddress = 'neighborIPAddress'
            self.routerLocalIPAddress = 'routerLocalIPAddress'
            self.threshold = 'threshold'

        def __call__(self):
            return 'RsCPPriceEntry'

    class RsHttpFloodUriBinDistEntry:
        def __init__(self):
            self.currStat = 'currStat'
            self.learnStat = 'learnStat'
            self.serverName = 'serverName'
            self.maxBin = 'maxBin'

        def __call__(self):
            return 'RsHttpFloodUriBinDistEntry'

    class RsMLBAgingTimeEntry:
        def __init__(self):
            self.rsMLBAgingTime = 'rsMLBAgingTime'
            self.status = 'status'
            self.applPort = 'applPort'

        def __call__(self):
            return 'RsMLBAgingTimeEntry'

    class RsBWMNetworkIPTuning:
        def __init__(self):
            self.rsBWMNetworkIPHashEntries = 'rsBWMNetworkIPHashEntries'
            self.rsBWMNetworkIPHashEntriesAfterReset = 'rsBWMNetworkIPHashEntriesAfterReset'

        def __call__(self):
            return 'RsBWMNetworkIPTuning'

    class RsSESSIONSynProtectionTriggerTuning:
        def __init__(self):
            self.rsSESSIONSynProtectionTriggerEntries = 'rsSESSIONSynProtectionTriggerEntries'
            self.rsSESSIONSynProtectionTriggerEntriesAfterReset = 'rsSESSIONSynProtectionTriggerEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSynProtectionTriggerTuning'

    class RsIDSIpFragments:
        def __init__(self):
            self.rsIDSIpFragMinFragmentStatus = 'rsIDSIpFragMinFragmentStatus'
            self.rsIDSIpFragMinFragmentMode = 'rsIDSIpFragMinFragmentMode'
            self.rsIDSIpFragReassemblyAgingTimeFreq = 'rsIDSIpFragReassemblyAgingTimeFreq'
            self.rsIDSIpFragReassemblyStatus = 'rsIDSIpFragReassemblyStatus'
            self.rsIDSIpFragReassemblyMode = 'rsIDSIpFragReassemblyMode'
            self.rsIDSIpFragReassemblyOverlapStatus = 'rsIDSIpFragReassemblyOverlapStatus'
            self.rsIDSIpFragReassemblyOverlapMode = 'rsIDSIpFragReassemblyOverlapMode'

        def __call__(self):
            return 'RsIDSIpFragments'

    class RsACC:
        def __init__(self):
            self.useFlowTable = 'useFlowTable'
            self.fFTRouteIgnore = 'fFTRouteIgnore'
            self.hardwareClassification = 'hardwareClassification'
            self.switchMode = 'switchMode'
            self.trunkMode = 'trunkMode'
            self.workingMode = 'workingMode'

        def __call__(self):
            return 'RsACC'

    class RsBWMCurrentPhysicalPortGroupEntry:
        def __init__(self):
            self.name = 'name'
            self.port = 'port'

        def __call__(self):
            return 'RsBWMCurrentPhysicalPortGroupEntry'

    class RsSESSIONSessionTableEntry:
        def __init__(self):
            self.srcIP = 'srcIP'
            self.dstIP = 'dstIP'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.physicalPort = 'physicalPort'
            self.lifetime = 'lifetime'
            self.agingType = 'agingType'
            self.sYNData = 'sYNData'
            self.rplyPhysicalPort = 'rplyPhysicalPort'
            self.iPProtocol = 'iPProtocol'
            self.index = 'index'

        def __call__(self):
            return 'RsSESSIONSessionTableEntry'

    class RsCCKDiameterArgsEntry:
        def __init__(self):
            self.originHost = 'originHost'
            self.originRealm = 'originRealm'
            self.productName = 'productName'
            self.authAppID = 'authAppID'
            self.authSessState = 'authSessState'
            self.destRealm = 'destRealm'
            self.destHost = 'destHost'
            self.publicID = 'publicID'
            self.disconnectCause = 'disconnectCause'
            self.appMessType = 'appMessType'
            self.appMessPresent = 'appMessPresent'
            self.description = 'description'
            self.resultCodes = 'resultCodes'
            self.vendorID = 'vendorID'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsCCKDiameterArgsEntry'

    class RdwrIkeEntry:
        def __init__(self):
            self.phase1EncryptionAlg = 'phase1EncryptionAlg'
            self.phase1HashAlg = 'phase1HashAlg'
            self.phase1DhKeyGroup = 'phase1DhKeyGroup'
            self.phase1LifeTime = 'phase1LifeTime'
            self.phase1Psk = 'phase1Psk'
            self.phase2Protocol = 'phase2Protocol'
            self.phase2EncryptionAlg = 'phase2EncryptionAlg'
            self.phase2HashAlg = 'phase2HashAlg'
            self.pfsKeyGroup = 'pfsKeyGroup'
            self.saLifeTime = 'saLifeTime'
            self.ipCompression = 'ipCompression'
            self.manualKeyMode = 'manualKeyMode'
            self.encrypKey = 'encrypKey'
            self.authntKey = 'authntKey'
            self.inSpi = 'inSpi'
            self.outSpi = 'outSpi'
            self.dPDCheckInterval = 'dPDCheckInterval'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RdwrIkeEntry'

    class RsTrafficUtilizationPerPolicyEntryTCP:
        def __init__(self):
            self.newConnectionsPerPolicyTCP = 'newConnectionsPerPolicyTCP'
            self.concurConnectionsPerPolicyTCP = 'concurConnectionsPerPolicyTCP'
            self.droppedPacketsPerPolicyTCP = 'droppedPacketsPerPolicyTCP'
            self.droppedBytesPerPolicyTCP = 'droppedBytesPerPolicyTCP'
            self.receivedPacketsPerPolicyTCP = 'receivedPacketsPerPolicyTCP'
            self.receivedBytesPerPolicyTCP = 'receivedBytesPerPolicyTCP'
            self.policyNamePerPolicyTCP = 'policyNamePerPolicyTCP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntryTCP'

    class RsMLBServiceLinkBindEntry:
        def __init__(self):
            self.lclLinkNhrMode = 'lclLinkNhrMode'
            self.status = 'status'
            self.setMode = 'setMode'
            self.rowStatus = 'rowStatus'
            self.remoteServiceName = 'remoteServiceName'
            self.lclNhrAddr = 'lclNhrAddr'

        def __call__(self):
            return 'RsMLBServiceLinkBindEntry'

    class RsStpInstanceEntry:
        def __init__(self):
            self.bridgePriority = 'bridgePriority'
            self.helloTime = 'helloTime'
            self.maxAgingTime = 'maxAgingTime'
            self.forwardDelayTime = 'forwardDelayTime'
            self.enabled = 'enabled'
            self.rootId = 'rootId'
            self.rootPathCost = 'rootPathCost'
            self.designatedBridgeId = 'designatedBridgeId'
            self.designatedPortId = 'designatedPortId'
            self.vlanId = 'vlanId'

        def __call__(self):
            return 'RsStpInstanceEntry'

    class RsHTTPFReportsContinuousLearningStatisticsEntry:
        def __init__(self):
            self.gETAndPOSTRequestsRate = 'gETAndPOSTRequestsRate'
            self.otherRequestsRate = 'otherRequestsRate'
            self.requestsRatePerSource = 'requestsRatePerSource'
            self.requestsRatePerConn = 'requestsRatePerConn'
            self.outboundBandwidthKbps = 'outboundBandwidthKbps'
            self.serverName = 'serverName'

        def __call__(self):
            return 'RsHTTPFReportsContinuousLearningStatisticsEntry'

    class RsIDSScanning:
        def __init__(self):
            self.rsIDSScanningMechanismStatus = 'rsIDSScanningMechanismStatus'
            self.rsIDSScanningSensitivity = 'rsIDSScanningSensitivity'
            self.rsIDSScanningSlowScans = 'rsIDSScanningSlowScans'
            self.rsIDSScanningMaxIPPairs = 'rsIDSScanningMaxIPPairs'
            self.rsIDSScanningMaxIPPairsAfterReset = 'rsIDSScanningMaxIPPairsAfterReset'
            self.rsIDSScanningFirewall = 'rsIDSScanningFirewall'
            self.rsIDSScanningHighPortResp = 'rsIDSScanningHighPortResp'
            self.rsIDSScanningMaxBlockingTime = 'rsIDSScanningMaxBlockingTime'

        def __call__(self):
            return 'RsIDSScanning'

    class RsNewWhiteListEntryTwo:
        def __init__(self):
            self.descriptionTwo = 'descriptionTwo'
            self.allModulesTwo = 'allModulesTwo'
            self.synModuleTwo = 'synModuleTwo'
            self.statefulModuleTwo = 'statefulModuleTwo'
            self.scanningModuleTwo = 'scanningModuleTwo'
            self.signatureModuleTwo = 'signatureModuleTwo'
            self.httpFloodModuleTwo = 'httpFloodModuleTwo'
            self.serverCrackingModuleTwo = 'serverCrackingModuleTwo'
            self.statusTwo = 'statusTwo'
            self.nameTwo = 'nameTwo'

        def __call__(self):
            return 'RsNewWhiteListEntryTwo'

    class RdwrDPHighAvailability:
        def __init__(self):
            self.rdwrDPHighAvailabilityDevicePriority = 'rdwrDPHighAvailabilityDevicePriority'
            self.rdwrDPHighAvailabilityKeepAliveTimeout = 'rdwrDPHighAvailabilityKeepAliveTimeout'
            self.rdwrDPHighAvailabilityLinkDownTimeout = 'rdwrDPHighAvailabilityLinkDownTimeout'
            self.rdwrDPHighAvailabilityLineDetectStatus = 'rdwrDPHighAvailabilityLineDetectStatus'
            self.rdwrDPHighAvailabilityBW = 'rdwrDPHighAvailabilityBW'
            self.rdwrDPHighAvailabilityIdleLineTimeout = 'rdwrDPHighAvailabilityIdleLineTimeout'
            self.rdwrDPHighAvailabilitySwitchOverTimeout = 'rdwrDPHighAvailabilitySwitchOverTimeout'
            self.rdwrDPHighAvailabilitySwitchOverAction = 'rdwrDPHighAvailabilitySwitchOverAction'
            self.rdwrDPHighAvailabilityCurrentState = 'rdwrDPHighAvailabilityCurrentState'
            self.rdwrDPHighAvailabilityProtectionState = 'rdwrDPHighAvailabilityProtectionState'
            self.rdwrDPHighAvailabilityForceSyncAction = 'rdwrDPHighAvailabilityForceSyncAction'
            self.rdwrDPHighAvailabilityLastSyncTime = 'rdwrDPHighAvailabilityLastSyncTime'
            self.rdwrDPHighAvailabilityPeerIpAddrMngOne = 'rdwrDPHighAvailabilityPeerIpAddrMngOne'
            self.rdwrDPHighAvailabilityPeerIpAddrMngTwo = 'rdwrDPHighAvailabilityPeerIpAddrMngTwo'
            self.rdwrDPHighAvailabilityPeerUserName = 'rdwrDPHighAvailabilityPeerUserName'
            self.rdwrDPHighAvailabilityPeerPassword = 'rdwrDPHighAvailabilityPeerPassword'
            self.rdwrDPHighAvailabilityBaseLineSyncInterval = 'rdwrDPHighAvailabilityBaseLineSyncInterval'
            self.rdwrDPHighAvailabilityDevicePriorityDisplay = 'rdwrDPHighAvailabilityDevicePriorityDisplay'
            self.rdwrDPHighAvailabilityPairAction = 'rdwrDPHighAvailabilityPairAction'
            self.rdwrDPHighAvailabilityImmediateSync = 'rdwrDPHighAvailabilityImmediateSync'
            self.rdwrDPHighAvailabilityStatus = 'rdwrDPHighAvailabilityStatus'
            self.rdwrDPHighAvailabilityFailBack = 'rdwrDPHighAvailabilityFailBack'

        def __call__(self):
            return 'RdwrDPHighAvailability'

    class RsSESSIONSynProtectionPolicyTuning:
        def __init__(self):
            self.rsSESSIONSynProtectionPolicyEntries = 'rsSESSIONSynProtectionPolicyEntries'
            self.rsSESSIONSynProtectionPolicyEntriesAfterReset = 'rsSESSIONSynProtectionPolicyEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSynProtectionPolicyTuning'

    class RsIpFragmentTuning:
        def __init__(self):
            self.rsIpFragmentTableEntries = 'rsIpFragmentTableEntries'
            self.rsIpFragmentTableEntriesAfterReset = 'rsIpFragmentTableEntriesAfterReset'

        def __call__(self):
            return 'RsIpFragmentTuning'

    class RsIDSPacketTrace:
        def __init__(self):
            self.rsIDSPacketTraceStatus = 'rsIDSPacketTraceStatus'
            self.rsIDSPacketTracePort = 'rsIDSPacketTracePort'
            self.rsIDSPacketTraceMaxPacketRate = 'rsIDSPacketTraceMaxPacketRate'
            self.rsIDSPacketTracePacketLength = 'rsIDSPacketTracePacketLength'

        def __call__(self):
            return 'RsIDSPacketTrace'

    class RsIDSServAttackEntry:
        def __init__(self):
            self.sERVAttackName = 'sERVAttackName'
            self.sERVAttackStatus = 'sERVAttackStatus'
            self.sERVAttackReportMode = 'sERVAttackReportMode'
            self.sERVAttackPacketReport = 'sERVAttackPacketReport'
            self.sERVAttackRisk = 'sERVAttackRisk'
            self.sERVAttackState = 'sERVAttackState'
            self.sERVAttackDirection = 'sERVAttackDirection'
            self.sERVAttackSuspendAction = 'sERVAttackSuspendAction'
            self.sERVAttackTracingType = 'sERVAttackTracingType'
            self.sERVAttackCounterType = 'sERVAttackCounterType'
            self.sERVAttackFuzzyProf = 'sERVAttackFuzzyProf'
            self.sERVAttackSensProf = 'sERVAttackSensProf'
            self.sERVAttackId = 'sERVAttackId'

        def __call__(self):
            return 'RsIDSServAttackEntry'

    class RsTrafficUtilization:
        def __init__(self):
            self.rsTrafficUtilizationConcurrentConnectionsTCP = 'rsTrafficUtilizationConcurrentConnectionsTCP'
            self.rsTrafficUtilizationConcurrentConnectionsUDP = 'rsTrafficUtilizationConcurrentConnectionsUDP'

        def __call__(self):
            return 'RsTrafficUtilization'

    class RsStatefulProtocolAgingEntry:
        def __init__(self):
            self.sTATFULProtocolName = 'sTATFULProtocolName'
            self.sTATFULProtocolAgingValue = 'sTATFULProtocolAgingValue'
            self.sTATFULProtocolAgingIndex = 'sTATFULProtocolAgingIndex'

        def __call__(self):
            return 'RsStatefulProtocolAgingEntry'

    class RsSESSIONAckReflectionTableTuning:
        def __init__(self):
            self.rsSESSIONAckReflectionTableEntries = 'rsSESSIONAckReflectionTableEntries'
            self.rsSESSIONAckReflectionTableEntriesAfterReset = 'rsSESSIONAckReflectionTableEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONAckReflectionTableTuning'

    class RsUpdatePolicies:
        def __init__(self):
            self.rdwrPoliciesIsolationMode = 'rdwrPoliciesIsolationMode'
            self.rdwrUpdatePoliciesRequired = 'rdwrUpdatePoliciesRequired'
            self.rsUpdatePoliciesInProgress = 'rsUpdatePoliciesInProgress'

        def __call__(self):
            return 'RsUpdatePolicies'

    class RsDnsProtDynamicStateFpEntry:
        def __init__(self):
            self.rsDnsProtDynamicState = 'rsDnsProtDynamicState'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'
            self.fpType = 'fpType'

        def __call__(self):
            return 'RsDnsProtDynamicStateFpEntry'

    class RsSESSIONTableEntry:
        def __init__(self):
            self.srcIP = 'srcIP'
            self.dstIP = 'dstIP'
            self.srcPort = 'srcPort'
            self.dstPort = 'dstPort'
            self.physicalPort = 'physicalPort'
            self.lifetime = 'lifetime'
            self.agingType = 'agingType'
            self.sYNData = 'sYNData'
            self.rplyPhysicalPort = 'rplyPhysicalPort'
            self.iPProtocol = 'iPProtocol'
            self.policyName = 'policyName'
            self.index = 'index'

        def __call__(self):
            return 'RsSESSIONTableEntry'

    class RsStatisticsProbePostVariablesEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.rsStatisticsProbePostVariable = 'rsStatisticsProbePostVariable'

        def __call__(self):
            return 'RsStatisticsProbePostVariablesEntry'

    class RsBWMChainRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.status = 'status'
            self.direction = 'direction'
            self.description = 'description'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.operationalStatus = 'operationalStatus'
            self.specific = 'specific'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.dSCPMarking = 'dSCPMarking'
            self.radiusRule = 'radiusRule'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMChainRulesEntry'

    class RsIDSNCPNFTableSizeTuning:
        def __init__(self):
            self.rsIDSNCPNFTableSize = 'rsIDSNCPNFTableSize'
            self.rsIDSNCPNFTableSizeAfterReset = 'rsIDSNCPNFTableSizeAfterReset'

        def __call__(self):
            return 'RsIDSNCPNFTableSizeTuning'

    class RsLinkAggregationHash:
        def __init__(self):
            self.rsLinkAggregationL2Hash = 'rsLinkAggregationL2Hash'
            self.rsLinkAggregationL3Hash = 'rsLinkAggregationL3Hash'
            self.rsLinkAggregationL4Hash = 'rsLinkAggregationL4Hash'

        def __call__(self):
            return 'RsLinkAggregationHash'

    class RsMLBPrxyStatisticsEntry:
        def __init__(self):
            self.firstNhr = 'firstNhr'
            self.firstLatency = 'firstLatency'
            self.firstHops = 'firstHops'
            self.secondNhr = 'secondNhr'
            self.secondLatency = 'secondLatency'
            self.secondHops = 'secondHops'
            self.thirdNhr = 'thirdNhr'
            self.thirdLatency = 'thirdLatency'
            self.thirdHops = 'thirdHops'
            self.counter = 'counter'
            self.subnet = 'subnet'

        def __call__(self):
            return 'RsMLBPrxyStatisticsEntry'

    class RsFSapplEntry:
        def __init__(self):
            self.index = 'index'
            self.valid = 'valid'
            self.active = 'active'
            self.version = 'version'
            self.startup = 'startup'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsFSapplEntry'

    class UsmUser:
        def __init__(self):
            self.usmUserSpinLock = 'usmUserSpinLock'

        def __call__(self):
            return 'UsmUser'

    class RsIDSLoopConfigurationDeviceTableEntry:
        def __init__(self):
            self.lOOPDeviceTblEntryPortName = 'lOOPDeviceTblEntryPortName'
            self.lOOPDeviceTblEntryPortInbound = 'lOOPDeviceTblEntryPortInbound'
            self.lOOPDeviceTblEntryPortOutbound = 'lOOPDeviceTblEntryPortOutbound'
            self.lOOPDeviceTblEntryPortIndex = 'lOOPDeviceTblEntryPortIndex'

        def __call__(self):
            return 'RsIDSLoopConfigurationDeviceTableEntry'

    class RsIDSGroupCategoryEntry:
        def __init__(self):
            self.rsIDSGroupCategory = 'rsIDSGroupCategory'
            self.catName = 'catName'

        def __call__(self):
            return 'RsIDSGroupCategoryEntry'

    class RsCCKElementEntry:
        def __init__(self):
            self.description = 'description'
            self.group = 'group'
            self.isActive = 'isActive'
            self.isAvailable = 'isAvailable'
            self.dftAddr = 'dftAddr'
            self.rowStatus = 'rowStatus'
            self.loadFactor = 'loadFactor'
            self.uptimePct = 'uptimePct'
            self.successCnt = 'successCnt'
            self.failCnt = 'failCnt'
            self.id = 'id'

        def __call__(self):
            return 'RsCCKElementEntry'

    class RsNetFloodPolicyEntry:
        def __init__(self):
            self.profileName = 'profileName'
            self.sourceNet = 'sourceNet'
            self.destinationNet = 'destinationNet'
            self.direction = 'direction'
            self.physicalPortGroup = 'physicalPortGroup'
            self.operationalStatus = 'operationalStatus'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.packetReportingStatus = 'packetReportingStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsNetFloodPolicyEntry'

    class RdwrBgpPeerDestRouteEntry:
        def __init__(self):
            self.prefix = 'prefix'
            self.updateStatus = 'updateStatus'
            self.rowStatus = 'rowStatus'
            self.ip = 'ip'
            self.network = 'network'

        def __call__(self):
            return 'RdwrBgpPeerDestRouteEntry'

    class RsMaxDspFrmEntriesTuning:
        def __init__(self):
            self.rsMaxDspFrmEntries = 'rsMaxDspFrmEntries'
            self.rsMaxDspFrmEntriesAfterReset = 'rsMaxDspFrmEntriesAfterReset'

        def __call__(self):
            return 'RsMaxDspFrmEntriesTuning'

    class RsIpZhrVirtAddressEntry:
        def __init__(self):
            self._from = 'from'
            self.status = 'status'
            self.ipIntf = 'ipIntf'
            self.to = 'to'

        def __call__(self):
            return 'RsIpZhrVirtAddressEntry'

    class RsNetFloodDynamicStateTwoEntry:
        def __init__(self):
            self.anyTypeFlag = 'anyTypeFlag'
            self.typeThreshold = 'typeThreshold'
            self.valThreshold = 'valThreshold'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'

        def __call__(self):
            return 'RsNetFloodDynamicStateTwoEntry'

    class RsIpZhrConnectionEntry:
        def __init__(self):
            self.virtualIp = 'virtualIp'
            self.type = 'type'
            self.age = 'age'
            self.status = 'status'
            self.ipIntf = 'ipIntf'
            self.srcIp = 'srcIp'
            self.destIp = 'destIp'

        def __call__(self):
            return 'RsIpZhrConnectionEntry'

    class RsIDSNewRulesEntry:
        def __init__(self):
            self.iDSServiceName = 'iDSServiceName'
            self.source = 'source'
            self.destination = 'destination'
            self.direction = 'direction'
            self.portmask = 'portmask'
            self.state = 'state'
            self.status = 'status'
            self.vlanTagGroup = 'vlanTagGroup'
            self.action = 'action'
            self.packetReportingStatus = 'packetReportingStatus'
            self.profileAppsec = 'profileAppsec'
            self.profileConlmt = 'profileConlmt'
            self.profileStateful = 'profileStateful'
            self.profileScanning = 'profileScanning'
            self.profileNetflood = 'profileNetflood'
            self.profileSynprotection = 'profileSynprotection'
            self.profileServprotection = 'profileServprotection'
            self.profilePPS = 'profilePPS'
            self.mPLSRDGroup = 'mPLSRDGroup'
            self.packetTraceStatus = 'packetTraceStatus'
            self.packetTraceEnforcement = 'packetTraceEnforcement'
            self.packetReportingEnforcement = 'packetReportingEnforcement'
            self.profileDNS = 'profileDNS'
            self.iDSQuarantineStatusInPolicy = 'iDSQuarantineStatusInPolicy'
            self.profileServiceDiscovery = 'profileServiceDiscovery'
            self.instanceId = 'instanceId'
            self.priority = 'priority'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSNewRulesEntry'

    class RsTunning:
        def __init__(self):
            self.rsHighPriority = 'rsHighPriority'
            self.rsLowPriority = 'rsLowPriority'
            self.rsDbgLevel = 'rsDbgLevel'
            self.rsDiagnostic = 'rsDiagnostic'
            self.rsConfirmMessagTab = 'rsConfirmMessagTab'
            self.rsTuneCheckMemory = 'rsTuneCheckMemory'
            self.rsTuneLastCheckResult = 'rsTuneLastCheckResult'

        def __call__(self):
            return 'RsTunning'

    class RsIDSImmediateChecks:
        def __init__(self):
            self.rsIDSImmediateChecksPacketTraceStatus = 'rsIDSImmediateChecksPacketTraceStatus'

        def __call__(self):
            return 'RsIDSImmediateChecks'

    class RsBWMDynamicNetworkRangeTuning:
        def __init__(self):
            self.rsBWMDynamicNetworkRangeEntries = 'rsBWMDynamicNetworkRangeEntries'
            self.rsBWMDynamicNetworkRangeEntriesAfterReset = 'rsBWMDynamicNetworkRangeEntriesAfterReset'

        def __call__(self):
            return 'RsBWMDynamicNetworkRangeTuning'

    class RsDebugTraceApplEntry:
        def __init__(self):
            self.status = 'status'
            self.severity = 'severity'
            self.name = 'name'

        def __call__(self):
            return 'RsDebugTraceApplEntry'

    class RsAntiFraud:
        def __init__(self):
            self.rsIDSAntiFraudProtectionStatus = 'rsIDSAntiFraudProtectionStatus'
            self.rsIDSAntiFraudPhishingAgingTime = 'rsIDSAntiFraudPhishingAgingTime'
            self.rsIDSAntiFraudDropPointsAgingTime = 'rsIDSAntiFraudDropPointsAgingTime'
            self.rsIDSAntiFraudMalDwnldAgingTime = 'rsIDSAntiFraudMalDwnldAgingTime'
            self.rsIDSAntiFraudCheckForUpdatesFreq = 'rsIDSAntiFraudCheckForUpdatesFreq'
            self.rsIDSAntiFraudLastUpdate = 'rsIDSAntiFraudLastUpdate'
            self.rsIDSAntiFraudInternalLastUpdate = 'rsIDSAntiFraudInternalLastUpdate'

        def __call__(self):
            return 'RsAntiFraud'

    class RsIDSIpFragmentsTuning:
        def __init__(self):
            self.rsIDSIpFragReassemblyMemorySize = 'rsIDSIpFragReassemblyMemorySize'
            self.rsIDSIpFragReassemblyMemorySizeAfterReset = 'rsIDSIpFragReassemblyMemorySizeAfterReset'

        def __call__(self):
            return 'RsIDSIpFragmentsTuning'

    class RsNewWhiteListEntry:
        def __init__(self):
            self.srcNetwork = 'srcNetwork'
            self.dstNetwork = 'dstNetwork'
            self.srcPortGroup = 'srcPortGroup'
            self.dstPortGroup = 'dstPortGroup'
            self.physicalPort = 'physicalPort'
            self.vLANTag = 'vLANTag'
            self.protocol = 'protocol'
            self.state = 'state'
            self.direction = 'direction'
            self.action = 'action'
            self.reportAction = 'reportAction'
            self.description = 'description'
            self.status = 'status'
            self.allModules = 'allModules'
            self.synModule = 'synModule'
            self.statefulModule = 'statefulModule'
            self.scanningModule = 'scanningModule'
            self.signatureModule = 'signatureModule'
            self.httpFloodModule = 'httpFloodModule'
            self.serverCrackingModule = 'serverCrackingModule'
            self.name = 'name'

        def __call__(self):
            return 'RsNewWhiteListEntry'

    class RsSigReportTotalTrafficEntry:
        def __init__(self):
            self.pollingTimestamp = 'pollingTimestamp'
            self.ttlTrffcCurrtBw = 'ttlTrffcCurrtBw'
            self.ttlTrffcAvrgBw = 'ttlTrffcAvrgBw'
            self.ttlTrffcAvrgDiscardBw = 'ttlTrffcAvrgDiscardBw'
            self.ttlTrffcCurrPackets = 'ttlTrffcCurrPackets'
            self.ttlTrffcAvrgPackets = 'ttlTrffcAvrgPackets'
            self.ttlTrffcAvrgDiscardPackets = 'ttlTrffcAvrgDiscardPackets'
            self.ttlTrffcCurrentCons = 'ttlTrffcCurrentCons'
            self.ttlTrffcAvrgCons = 'ttlTrffcAvrgCons'
            self.ttlTrffcDeviceName = 'ttlTrffcDeviceName'

        def __call__(self):
            return 'RsSigReportTotalTrafficEntry'

    class RdwrRedundancyInfoEntry:
        def __init__(self):
            self._interface = '_interface'
            self.vrid = 'vrid'
            self.mode = 'mode'
            self.myAddress = 'myAddress'
            self.neighborAddress = 'neighborAddress'
            self.status = 'status'
            self.idx = 'idx'

        def __call__(self):
            return 'RdwrRedundancyInfoEntry'

    class GenGroup:
        def __init__(self):
            self.genGroupHWVersion = 'genGroupHWVersion'
            self.genGroupConfigurationSymbol = 'genGroupConfigurationSymbol'
            self.genGroupHWStatus = 'genGroupHWStatus'

        def __call__(self):
            return 'GenGroup'

    class RsSSDvirtualLanEntry:
        def __init__(self):
            self.sSDvlProto = 'sSDvlProto'
            self.sSDvlAutoConfigEnable = 'sSDvlAutoConfigEnable'
            self.sSDvlStatus = 'sSDvlStatus'
            self.sSDvlType = 'sSDvlType'
            self.sSDvlTag = 'sSDvlTag'
            self.sSDvlPriority = 'sSDvlPriority'
            self.sSDvlUpCriterion = 'sSDvlUpCriterion'
            self.sSDvlDownCriterion = 'sSDvlDownCriterion'
            self.sSDvlIfIndex = 'sSDvlIfIndex'

        def __call__(self):
            return 'RsSSDvirtualLanEntry'

    class RsIfConfEntry:
        def __init__(self):
            self.type = 'type'
            self.name = 'name'
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'RsIfConfEntry'

    class RsMLBRulesEntry:
        def __init__(self):
            self.leavingPort = 'leavingPort'
            self.numOfServers = 'numOfServers'
            self.portNumber = 'portNumber'

        def __call__(self):
            return 'RsMLBRulesEntry'

    class RsIDSNewSuspendTableEntry:
        def __init__(self):
            self.expType = 'expType'
            self.expTime = 'expTime'
            self.srcIp = 'srcIp'
            self.dstIp = 'dstIp'
            self.dstPort = 'dstPort'
            self.protocol = 'protocol'
            self.module = 'module'

        def __call__(self):
            return 'RsIDSNewSuspendTableEntry'

    class RsSSLCertificateEntry:
        def __init__(self):
            self.type = 'type'
            self.keySize = 'keySize'
            self.keyPassphrase = 'keyPassphrase'
            self.common = 'common'
            self.locality = 'locality'
            self.stateOrProvince = 'stateOrProvince'
            self.organization = 'organization'
            self.organizationUnit = 'organizationUnit'
            self.countryName = 'countryName'
            self.eMail = 'eMail'
            self.expiry = 'expiry'
            self.oCSPUrl = 'oCSPUrl'
            self.status = 'status'
            self.requestedValidityPeriod = 'requestedValidityPeriod'
            self.name = 'name'

        def __call__(self):
            return 'RsSSLCertificateEntry'

    class RsMLBDNSRegexpURLtoIPEntry:
        def __init__(self):
            self.uRLLocDeviceIP = 'uRLLocDeviceIP'
            self.uRLIndex = 'uRLIndex'
            self.uRLStatus = 'uRLStatus'
            self.rsMLBDNSRegexpURL = 'rsMLBDNSRegexpURL'

        def __call__(self):
            return 'RsMLBDNSRegexpURLtoIPEntry'

    class RsREACCReasonCounters:
        def __init__(self):
            self.rsACCReasonUnknownCounter = 'rsACCReasonUnknownCounter'
            self.rsACCReasonETHBroadcastCounter = 'rsACCReasonETHBroadcastCounter'
            self.rsACCReasonProtolcolTypeCounter = 'rsACCReasonProtolcolTypeCounter'
            self.rsACCReasonIPVERCounter = 'rsACCReasonIPVERCounter'
            self.rsACCReasonIPHeaderLenCounter = 'rsACCReasonIPHeaderLenCounter'
            self.rsACCReasonIPFragmentedCounter = 'rsACCReasonIPFragmentedCounter'
            self.rsACCReasonTTLCounter = 'rsACCReasonTTLCounter'
            self.rsACCReasonNoFlowCounter = 'rsACCReasonNoFlowCounter'
            self.rsACCReasonMACCFGCounter = 'rsACCReasonMACCFGCounter'
            self.rsACCReasonSYNcookieOKCounter = 'rsACCReasonSYNcookieOKCounter'
            self.rsACCReasonSYNcookieInvalidCounter = 'rsACCReasonSYNcookieInvalidCounter'
            self.rsACCReasonInconsistentPktLenCounter = 'rsACCReasonInconsistentPktLenCounter'
            self.rsACCReasonNoReasonCounter = 'rsACCReasonNoReasonCounter'
            self.rsACCReasonFTPportCounter = 'rsACCReasonFTPportCounter'
            self.rsACCReasonFTP227Counter = 'rsACCReasonFTP227Counter'
            self.rsACCReasonIPLenghtCounter = 'rsACCReasonIPLenghtCounter'
            self.rsACCReasonFINorRSTCounter = 'rsACCReasonFINorRSTCounter'
            self.rsACCReasonClassifyCounter = 'rsACCReasonClassifyCounter'
            self.rsACCReasonVlanReplyCounter = 'rsACCReasonVlanReplyCounter'
            self.rsACCReasonDBindNewSYNCounter = 'rsACCReasonDBindNewSYNCounter'
            self.rsACCReasonAllToMasterCounter = 'rsACCReasonAllToMasterCounter'

        def __call__(self):
            return 'RsREACCReasonCounters'

    class RsIDSNetworkPolicyEvent:
        def __init__(self):
            self.rsIDSServProtPolicyInactiveErrorDesc = 'rsIDSServProtPolicyInactiveErrorDesc'
            self.rsIDSServProtPolicyInactiveErrorSeverity = 'rsIDSServProtPolicyInactiveErrorSeverity'

        def __call__(self):
            return 'RsIDSNetworkPolicyEvent'

    class IpSpec:
        def __init__(self):
            self.rsRipEnable = 'rsRipEnable'
            self.lreBoxAgentIP = 'lreBoxAgentIP'

        def __call__(self):
            return 'IpSpec'

    class RsRip2IfConfEntry:
        def __init__(self):
            self.virtualDis = 'virtualDis'
            self.autoSend = 'autoSend'
            self.address = 'address'

        def __call__(self):
            return 'RsRip2IfConfEntry'

    class RsIDSServiceEntry:
        def __init__(self):
            self.entName = 'entName'
            self.tableType = 'tableType'
            self.type = 'type'
            self.id = 'id'

        def __call__(self):
            return 'RsIDSServiceEntry'

    class RsIDSWebQuarantineEntry:
        def __init__(self):
            self.policy = 'policy'
            self.timeHours = 'timeHours'
            self.timeMin = 'timeMin'
            self.attack = 'attack'
            self.insertionTime = 'insertionTime'
            self.status = 'status'
            self.address = 'address'

        def __call__(self):
            return 'RsIDSWebQuarantineEntry'

    class RsAPM:
        def __init__(self):
            self.enabledStatus = 'enabledStatus'
            self.updateAllPolicies = 'updateAllPolicies'
            self.updatePolicy = 'updatePolicy'
            self.resetApm = 'resetApm'
            self.resetApmFromDatabase = 'resetApmFromDatabase'

        def __call__(self):
            return 'RsAPM'

    class VirtualLanAutoConfEntry:
        def __init__(self):
            self.vlAutoConfStatus = 'vlAutoConfStatus'
            self.vlAutoConfPortIfIndex = 'vlAutoConfPortIfIndex'
            self.vlAutoConfProto = 'vlAutoConfProto'

        def __call__(self):
            return 'VirtualLanAutoConfEntry'

    class RsIDSSignaturesProfileAttackNumberEntry:
        def __init__(self):
            self.attackNumber = 'attackNumber'
            self.status = 'status'
            self.profileName = 'profileName'

        def __call__(self):
            return 'RsIDSSignaturesProfileAttackNumberEntry'

    class RsMLBDNSVirtualEntry:
        def __init__(self):
            self.mLBDNSVirIPMode = 'mLBDNSVirIPMode'
            self.mLBDNSStatus = 'mLBDNSStatus'
            self.ip = 'ip'

        def __call__(self):
            return 'RsMLBDNSVirtualEntry'

    class RsMLBMaxBasicNatEntriesTuning:
        def __init__(self):
            self.rsMLBMaxBasicNatEntries = 'rsMLBMaxBasicNatEntries'
            self.rsMLBMaxBasicNatEntriesAfterReset = 'rsMLBMaxBasicNatEntriesAfterReset'

        def __call__(self):
            return 'RsMLBMaxBasicNatEntriesTuning'

    class RsIpZhrStatusEntry:
        def __init__(self):
            self.adminStatus = 'adminStatus'
            self.ipIntf = 'ipIntf'

        def __call__(self):
            return 'RsIpZhrStatusEntry'

    class RsCCKChkMethodEntry:
        def __init__(self):
            self.description = 'description'
            self.rowStatus = 'rowStatus'
            self.id = 'id'

        def __call__(self):
            return 'RsCCKChkMethodEntry'

    class RsIpRipFilterGlbEntry:
        def __init__(self):
            self.status = 'status'
            self.ipAddr = 'ipAddr'
            self.networkMaskBits = 'networkMaskBits'
            self.matchBits = 'matchBits'
            self.action = 'action'
            self.type = 'type'
            self.number = 'number'

        def __call__(self):
            return 'RsIpRipFilterGlbEntry'

    class RdwrClientsTableStatistics:
        def __init__(self):
            self.rdwrClientsTableNumEntries = 'rdwrClientsTableNumEntries'
            self.rdwrClientsTableNumEntries5SecAvg = 'rdwrClientsTableNumEntries5SecAvg'
            self.rdwrClientsTableNumEntries60SecAvg = 'rdwrClientsTableNumEntries60SecAvg'

        def __call__(self):
            return 'RdwrClientsTableStatistics'

    class RsBWMPolicyGroupEntry:
        def __init__(self):
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMPolicyGroupEntry'

    class RsCPPasswordPromptEntry:
        def __init__(self):
            self.status = 'status'
            self.dispString = 'dispString'

        def __call__(self):
            return 'RsCPPasswordPromptEntry'

    class RndMonitoredElementEntry:
        def __init__(self):
            self.community = 'community'
            self.label = 'label'
            self.defaultPollingInterval = 'defaultPollingInterval'
            self.defaultLogFile = 'defaultLogFile'
            self.status = 'status'
            self.address = 'address'

        def __call__(self):
            return 'RndMonitoredElementEntry'

    class RsSESSIONSynProtectionPolicyEntry:
        def __init__(self):
            self.triggerPolicyIndex = 'triggerPolicyIndex'
            self.triggerPolicyDescription = 'triggerPolicyDescription'
            self.triggerPolicyDestination = 'triggerPolicyDestination'
            self.triggerPolicyPhysicalPortGroup = 'triggerPolicyPhysicalPortGroup'
            self.triggerPolicyService = 'triggerPolicyService'
            self.triggerPolicyProtectionMode = 'triggerPolicyProtectionMode'
            self.triggerPolicyOperationalStatus = 'triggerPolicyOperationalStatus'
            self.triggerPolicyStatus = 'triggerPolicyStatus'
            self.triggerPolicyVerificationType = 'triggerPolicyVerificationType'
            self.triggerPolicyActivationThreshold = 'triggerPolicyActivationThreshold'
            self.triggerPolicyDeactivationThreshold = 'triggerPolicyDeactivationThreshold'
            self.triggerPolicyCountStatistics = 'triggerPolicyCountStatistics'
            self.triggerPolicyName = 'triggerPolicyName'

        def __call__(self):
            return 'RsSESSIONSynProtectionPolicyEntry'

    class RsIDSSourceTableParams:
        def __init__(self):
            self.rsIDSSourceTableSize = 'rsIDSSourceTableSize'
            self.rsIDSSourceTableSizeAfterReset = 'rsIDSSourceTableSizeAfterReset'

        def __call__(self):
            return 'RsIDSSourceTableParams'

    class RsIDSUserGroupsNumberTuning:
        def __init__(self):
            self.rsIDSUserGroupsNumber = 'rsIDSUserGroupsNumber'
            self.rsIDSUserGroupsNumberAfterReset = 'rsIDSUserGroupsNumberAfterReset'

        def __call__(self):
            return 'RsIDSUserGroupsNumberTuning'

    class RsTrafficUtilizationPerPolicyEntrySCTP:
        def __init__(self):
            self.newConnectionsPerPolicySCTP = 'newConnectionsPerPolicySCTP'
            self.concurConnectionsPerPolicySCTP = 'concurConnectionsPerPolicySCTP'
            self.droppedPacketsPerPolicySCTP = 'droppedPacketsPerPolicySCTP'
            self.droppedBytesPerPolicySCTP = 'droppedBytesPerPolicySCTP'
            self.receivedPacketsPerPolicySCTP = 'receivedPacketsPerPolicySCTP'
            self.receivedBytesPerPolicySCTP = 'receivedBytesPerPolicySCTP'
            self.policyNamePerPolicySCTP = 'policyNamePerPolicySCTP'

        def __call__(self):
            return 'RsTrafficUtilizationPerPolicyEntrySCTP'

    class RsWSDTelnetUserEntry:
        def __init__(self):
            self.password = 'password'
            self.eAddr = 'eAddr'
            self.severity = 'severity'
            self.status = 'status'
            self.group = 'group'
            self.configurationTraceStatus = 'configurationTraceStatus'
            self.configurationTraceInf = 'configurationTraceInf'
            self.webAccessLevel = 'webAccessLevel'
            self.sshPublicKeyName = 'sshPublicKeyName'
            self.name = 'name'

        def __call__(self):
            return 'RsWSDTelnetUserEntry'

    class RsCPLegalStringEntry:
        def __init__(self):
            self.status = 'status'
            self.dispString = 'dispString'

        def __call__(self):
            return 'RsCPLegalStringEntry'

    class RsImportBaselineBdosEntry:
        def __init__(self):
            self.icmpInBpsIpv4 = 'icmpInBpsIpv4'
            self.icmpOutBpsIpv4 = 'icmpOutBpsIpv4'
            self.tcpInBpsIpv4 = 'tcpInBpsIpv4'
            self.tcpOutBpsIpv4 = 'tcpOutBpsIpv4'
            self.udpInBpsIpv4 = 'udpInBpsIpv4'
            self.udpOutBpsIpv4 = 'udpOutBpsIpv4'
            self.igmpInBpsIpv4 = 'igmpInBpsIpv4'
            self.igmpOutBpsIpv4 = 'igmpOutBpsIpv4'
            self.tcpSynInBpsIpv4 = 'tcpSynInBpsIpv4'
            self.tcpSynOutBpsIpv4 = 'tcpSynOutBpsIpv4'
            self.tcpRstInBpsIpv4 = 'tcpRstInBpsIpv4'
            self.tcpRstOutBpsIpv4 = 'tcpRstOutBpsIpv4'
            self.tcpAckInBpsIpv4 = 'tcpAckInBpsIpv4'
            self.tcpAckOutBpsIpv4 = 'tcpAckOutBpsIpv4'
            self.tcpAckPshInBpsIpv4 = 'tcpAckPshInBpsIpv4'
            self.tcpAckPshOutBpsIpv4 = 'tcpAckPshOutBpsIpv4'
            self.tcpAckFinInBpsIpv4 = 'tcpAckFinInBpsIpv4'
            self.tcpAckFinOutBpsIpv4 = 'tcpAckFinOutBpsIpv4'
            self.tcpSynAckInBpsIpv4 = 'tcpSynAckInBpsIpv4'
            self.tcpSynAckOutBpsIpv4 = 'tcpSynAckOutBpsIpv4'
            self.tcpFragInBpsIpv4 = 'tcpFragInBpsIpv4'
            self.tcpFragOutBpsIpv4 = 'tcpFragOutBpsIpv4'
            self.icmpInPpsIpv4 = 'icmpInPpsIpv4'
            self.icmpOutPpsIpv4 = 'icmpOutPpsIpv4'
            self.tcpInPpsIpv4 = 'tcpInPpsIpv4'
            self.tcpOutPpsIpv4 = 'tcpOutPpsIpv4'
            self.udpInPpsIpv4 = 'udpInPpsIpv4'
            self.udpOutPpsIpv4 = 'udpOutPpsIpv4'
            self.igmpInPpsIpv4 = 'igmpInPpsIpv4'
            self.igmpOutPpsIpv4 = 'igmpOutPpsIpv4'
            self.tcpSynInPpsIpv4 = 'tcpSynInPpsIpv4'
            self.tcpSynOutPpsIpv4 = 'tcpSynOutPpsIpv4'
            self.tcpRstInPpsIpv4 = 'tcpRstInPpsIpv4'
            self.tcpRstOutPpsIpv4 = 'tcpRstOutPpsIpv4'
            self.tcpAckInPpsIpv4 = 'tcpAckInPpsIpv4'
            self.tcpAckOutPpsIpv4 = 'tcpAckOutPpsIpv4'
            self.tcpAckPshInPpsIpv4 = 'tcpAckPshInPpsIpv4'
            self.tcpAckPshOutPpsIpv4 = 'tcpAckPshOutPpsIpv4'
            self.tcpAckFinInPpsIpv4 = 'tcpAckFinInPpsIpv4'
            self.tcpAckFinOutPpsIpv4 = 'tcpAckFinOutPpsIpv4'
            self.tcpSynAckInPpsIpv4 = 'tcpSynAckInPpsIpv4'
            self.tcpSynAckOutPpsIpv4 = 'tcpSynAckOutPpsIpv4'
            self.tcpFragInPpsIpv4 = 'tcpFragInPpsIpv4'
            self.tcpFragOutPpsIpv4 = 'tcpFragOutPpsIpv4'
            self.icmpInBpsIpv6 = 'icmpInBpsIpv6'
            self.icmpOutBpsIpv6 = 'icmpOutBpsIpv6'
            self.tcpInBpsIpv6 = 'tcpInBpsIpv6'
            self.tcpOutBpsIpv6 = 'tcpOutBpsIpv6'
            self.udpInBpsIpv6 = 'udpInBpsIpv6'
            self.udpOutBpsIpv6 = 'udpOutBpsIpv6'
            self.igmpInBpsIpv6 = 'igmpInBpsIpv6'
            self.igmpOutBpsIpv6 = 'igmpOutBpsIpv6'
            self.tcpSynInBpsIpv6 = 'tcpSynInBpsIpv6'
            self.tcpSynOutBpsIpv6 = 'tcpSynOutBpsIpv6'
            self.tcpRstInBpsIpv6 = 'tcpRstInBpsIpv6'
            self.tcpRstOutBpsIpv6 = 'tcpRstOutBpsIpv6'
            self.tcpAckInBpsIpv6 = 'tcpAckInBpsIpv6'
            self.tcpAckOutBpsIpv6 = 'tcpAckOutBpsIpv6'
            self.tcpAckPshInBpsIpv6 = 'tcpAckPshInBpsIpv6'
            self.tcpAckPshOutBpsIpv6 = 'tcpAckPshOutBpsIpv6'
            self.tcpAckFinInBpsIpv6 = 'tcpAckFinInBpsIpv6'
            self.tcpAckFinOutBpsIpv6 = 'tcpAckFinOutBpsIpv6'
            self.tcpSynAckInBpsIpv6 = 'tcpSynAckInBpsIpv6'
            self.tcpSynAckOutBpsIpv6 = 'tcpSynAckOutBpsIpv6'
            self.tcpFragInBpsIpv6 = 'tcpFragInBpsIpv6'
            self.tcpFragOutBpsIpv6 = 'tcpFragOutBpsIpv6'
            self.icmpInPpsIpv6 = 'icmpInPpsIpv6'
            self.icmpOutPpsIpv6 = 'icmpOutPpsIpv6'
            self.tcpInPpsIpv6 = 'tcpInPpsIpv6'
            self.tcpOutPpsIpv6 = 'tcpOutPpsIpv6'
            self.udpInPpsIpv6 = 'udpInPpsIpv6'
            self.udpOutPpsIpv6 = 'udpOutPpsIpv6'
            self.igmpInPpsIpv6 = 'igmpInPpsIpv6'
            self.igmpOutPpsIpv6 = 'igmpOutPpsIpv6'
            self.tcpSynInPpsIpv6 = 'tcpSynInPpsIpv6'
            self.tcpSynOutPpsIpv6 = 'tcpSynOutPpsIpv6'
            self.tcpRstInPpsIpv6 = 'tcpRstInPpsIpv6'
            self.tcpRstOutPpsIpv6 = 'tcpRstOutPpsIpv6'
            self.tcpAckInPpsIpv6 = 'tcpAckInPpsIpv6'
            self.tcpAckOutPpsIpv6 = 'tcpAckOutPpsIpv6'
            self.tcpAckPshInPpsIpv6 = 'tcpAckPshInPpsIpv6'
            self.tcpAckPshOutPpsIpv6 = 'tcpAckPshOutPpsIpv6'
            self.tcpAckFinInPpsIpv6 = 'tcpAckFinInPpsIpv6'
            self.tcpAckFinOutPpsIpv6 = 'tcpAckFinOutPpsIpv6'
            self.tcpSynAckInPpsIpv6 = 'tcpSynAckInPpsIpv6'
            self.tcpSynAckOutPpsIpv6 = 'tcpSynAckOutPpsIpv6'
            self.tcpFragInPpsIpv6 = 'tcpFragInPpsIpv6'
            self.tcpFragOutPpsIpv6 = 'tcpFragOutPpsIpv6'
            self.udpFragInBpsIpv4 = 'udpFragInBpsIpv4'
            self.udpFragOutBpsIpv4 = 'udpFragOutBpsIpv4'
            self.udpFragInPpsIpv4 = 'udpFragInPpsIpv4'
            self.udpFragOutPpsIpv4 = 'udpFragOutPpsIpv4'
            self.udpFragInBpsIpv6 = 'udpFragInBpsIpv6'
            self.udpFragOutBpsIpv6 = 'udpFragOutBpsIpv6'
            self.udpFragInPpsIpv6 = 'udpFragInPpsIpv6'
            self.udpFragOutPpsIpv6 = 'udpFragOutPpsIpv6'
            self.name = 'name'

        def __call__(self):
            return 'RsImportBaselineBdosEntry'

    class RsMLBMaxNoNatEntriesTuning:
        def __init__(self):
            self.rsMLBMaxNoNatEntries = 'rsMLBMaxNoNatEntries'
            self.rsMLBMaxNoNatEntriesAfterReset = 'rsMLBMaxNoNatEntriesAfterReset'

        def __call__(self):
            return 'RsMLBMaxNoNatEntriesTuning'

    class RsIDSSignaturesAttributesEntry:
        def __init__(self):
            self.source = 'source'
            self.typeId = 'typeId'
            self.value = 'value'
            self.status = 'status'
            self.type = 'type'
            self.name = 'name'

        def __call__(self):
            return 'RsIDSSignaturesAttributesEntry'

    class SnmpCommunityEntry:
        def __init__(self):
            self.name = 'name'
            self.securityName = 'securityName'
            self.contextEngineID = 'contextEngineID'
            self.contextName = 'contextName'
            self.transportTag = 'transportTag'
            self.storageType = 'storageType'
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'SnmpCommunityEntry'

    class SnmpNotifyEntry:
        def __init__(self):
            self.tag = 'tag'
            self.type = 'type'
            self.storageType = 'storageType'
            self.rowStatus = 'rowStatus'
            self.name = 'name'

        def __call__(self):
            return 'SnmpNotifyEntry'

    class RsBWMACL:
        def __init__(self):
            self.rsBWMACLStatus = 'rsBWMACLStatus'
            self.rsBWMACLLearningPeriod = 'rsBWMACLLearningPeriod'
            self.rsBWMACLTCPHandshakeTimeout = 'rsBWMACLTCPHandshakeTimeout'
            self.rsBWMACLTCPEstablishedTimeout = 'rsBWMACLTCPEstablishedTimeout'
            self.rsBWMACLTCPFinTimeout = 'rsBWMACLTCPFinTimeout'
            self.rsBWMACLTCPRstTimeout = 'rsBWMACLTCPRstTimeout'
            self.rsBWMACLTCPMidSessMode = 'rsBWMACLTCPMidSessMode'
            self.rsBWMACLTCPRstValidationMode = 'rsBWMACLTCPRstValidationMode'
            self.rsBWMACLUDPTimeout = 'rsBWMACLUDPTimeout'
            self.rsBWMACLICMPTimeout = 'rsBWMACLICMPTimeout'
            self.rsBWMACLOtherTimeout = 'rsBWMACLOtherTimeout'
            self.rsBWMACLReportMaxTraps = 'rsBWMACLReportMaxTraps'
            self.rsBWMACLReportPeriod = 'rsBWMACLReportPeriod'
            self.rsBWMACLReportSendSrp = 'rsBWMACLReportSendSrp'
            self.rsBWMACLDetailedReportType = 'rsBWMACLDetailedReportType'
            self.rsBWMACLGRETimeout = 'rsBWMACLGRETimeout'
            self.rsBWMACLSCTPTimeout = 'rsBWMACLSCTPTimeout'
            self.rsBWMACLAllowICMPSmurf = 'rsBWMACLAllowICMPSmurf'
            self.rsBWMACLL2TPTimeout = 'rsBWMACLL2TPTimeout'
            self.rsBWMACLGTPTimeout = 'rsBWMACLGTPTimeout'
            self.rsBWMACLPacketTraceStatus = 'rsBWMACLPacketTraceStatus'
            self.rsBWMACLIPinIPTimeout = 'rsBWMACLIPinIPTimeout'
            self.rsBWMACLDefaultAction = 'rsBWMACLDefaultAction'

        def __call__(self):
            return 'RsBWMACL'

    class RsWSDSCProtcolsEntry:
        def __init__(self):
            self.wSDSCProtocolStatus = 'wSDSCProtocolStatus'
            self.wSDSCProtocol = 'wSDSCProtocol'

        def __call__(self):
            return 'RsWSDSCProtcolsEntry'

    class RdwrRip2IfConfEntry:
        def __init__(self):
            self.authType = 'authType'
            self.authKey = 'authKey'
            self.send = 'send'
            self.receive = 'receive'
            self.defaultMetric = 'defaultMetric'
            self.status = 'status'
            self.srcAddress = 'srcAddress'
            self.virtualDis = 'virtualDis'
            self.autoSend = 'autoSend'
            self.address = 'address'

        def __call__(self):
            return 'RdwrRip2IfConfEntry'

    class RsIDSConnectionLimitAttackEntry:
        def __init__(self):
            self.name = 'name'
            self.appPort = 'appPort'
            self.protocol = 'protocol'
            self.threshold = 'threshold'
            self.trackingType = 'trackingType'
            self.reportMode = 'reportMode'
            self.packetReport = 'packetReport'
            self.risk = 'risk'
            self.suspendAction = 'suspendAction'
            self.status = 'status'
            self.packetTrace = 'packetTrace'
            self.id = 'id'

        def __call__(self):
            return 'RsIDSConnectionLimitAttackEntry'

    class IfXEntry:
        def __init__(self):
            self.name = 'name'
            self.inMulticastPkts = 'inMulticastPkts'
            self.inBroadcastPkts = 'inBroadcastPkts'
            self.outMulticastPkts = 'outMulticastPkts'
            self.outBroadcastPkts = 'outBroadcastPkts'
            self.hCInOctets = 'hCInOctets'
            self.hCInUcastPkts = 'hCInUcastPkts'
            self.hCInMulticastPkts = 'hCInMulticastPkts'
            self.hCInBroadcastPkts = 'hCInBroadcastPkts'
            self.hCOutOctets = 'hCOutOctets'
            self.hCOutUcastPkts = 'hCOutUcastPkts'
            self.hCOutMulticastPkts = 'hCOutMulticastPkts'
            self.hCOutBroadcastPkts = 'hCOutBroadcastPkts'
            self.linkUpDownTrapEnable = 'linkUpDownTrapEnable'
            self.highSpeed = 'highSpeed'
            self.promiscuousMode = 'promiscuousMode'
            self.connectorPresent = 'connectorPresent'
            self.alias = 'alias'
            self.counterDiscontinuityTime = 'counterDiscontinuityTime'
            self.index = 'index'

        def __call__(self):
            return 'IfXEntry'

    class RsBWMCurrentFarmRulesEntry:
        def __init__(self):
            self.index = 'index'
            self.destination = 'destination'
            self.source = 'source'
            self.direction = 'direction'
            self.description = 'description'
            self.policyType = 'policyType'
            self.policy = 'policy'
            self.specific = 'specific'
            self.bandwidthLastSec = 'bandwidthLastSec'
            self.packetsLastSec = 'packetsLastSec'
            self.physicalPortGroup = 'physicalPortGroup'
            self.vLANTagGroup = 'vLANTagGroup'
            self.dSCPMarking = 'dSCPMarking'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMCurrentFarmRulesEntry'

    class RsSignaling:
        def __init__(self):
            self.rsSignalingStatus = 'rsSignalingStatus'

        def __call__(self):
            return 'RsSignaling'

    class RsMLBLocalServiceEntry:
        def __init__(self):
            self.password = 'password'
            self.dnsDomain = 'dnsDomain'
            self.persistenceMode = 'persistenceMode'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBLocalServiceEntry'

    class RsCCKDiameterBinaryFileEntry:
        def __init__(self):
            self.data1 = 'data1'
            self.data2 = 'data2'
            self.data3 = 'data3'
            self.data4 = 'data4'
            self.totalLength = 'totalLength'
            self.rowStatus = 'rowStatus'
            self.argsSetName = 'argsSetName'

        def __call__(self):
            return 'RsCCKDiameterBinaryFileEntry'

    class RsPhysPortMirrorEntry:
        def __init__(self):
            self.rxTx = 'rxTx'
            self.rxBroadCast = 'rxBroadCast'
            self.status = 'status'
            self.backupDstPort = 'backupDstPort'
            self.dstStatus = 'dstStatus'
            self.backupStatus = 'backupStatus'
            self.activeDstPort = 'activeDstPort'
            self.mode = 'mode'
            self.threshold = 'threshold'
            self.thresholdStatus = 'thresholdStatus'
            self.srcInf = 'srcInf'
            self.dstPort = 'dstPort'

        def __call__(self):
            return 'RsPhysPortMirrorEntry'

    class RsStatisticsProtocolEntry:
        def __init__(self):
            self.lastPeriodUsedBW = 'lastPeriodUsedBW'
            self.lastPeriodPeakBW = 'lastPeriodPeakBW'
            self.lastPeriodMatchedPackets = 'lastPeriodMatchedPackets'
            self.rsStatisticsProtocol = 'rsStatisticsProtocol'
            self.port = 'port'

        def __call__(self):
            return 'RsStatisticsProtocolEntry'

    class RsRadiusServer:
        def __init__(self):
            self.rsRadiusMainServerAddr = 'rsRadiusMainServerAddr'
            self.rsRadiusMainServerPort = 'rsRadiusMainServerPort'
            self.rsRadiusMainServerSecret = 'rsRadiusMainServerSecret'
            self.rsRadiusBackupServerAddr = 'rsRadiusBackupServerAddr'
            self.rsRadiusBackupServerPort = 'rsRadiusBackupServerPort'
            self.rsRadiusBackupServerSecret = 'rsRadiusBackupServerSecret'
            self.rsAuthenticationMethod = 'rsAuthenticationMethod'
            self.rsRadiusServerTimeout = 'rsRadiusServerTimeout'
            self.rsRadiusServerRetries = 'rsRadiusServerRetries'
            self.rsLockUserAfterLoginFailure = 'rsLockUserAfterLoginFailure'
            self.rsRadiusClientLifeTime = 'rsRadiusClientLifeTime'
            self.rsRadiusMainServerUrl = 'rsRadiusMainServerUrl'
            self.rsRadiusBackupServerUrl = 'rsRadiusBackupServerUrl'

        def __call__(self):
            return 'RsRadiusServer'

    class UsmStats:
        def __init__(self):
            self.usmStatsUnsupportedSecLevels = 'usmStatsUnsupportedSecLevels'
            self.usmStatsNotInTimeWindows = 'usmStatsNotInTimeWindows'
            self.usmStatsUnknownUserNames = 'usmStatsUnknownUserNames'
            self.usmStatsUnknownEngineIDs = 'usmStatsUnknownEngineIDs'
            self.usmStatsWrongDigests = 'usmStatsWrongDigests'
            self.usmStatsDecryptionErrors = 'usmStatsDecryptionErrors'

        def __call__(self):
            return 'UsmStats'

    class RdwrDPRoutingIpForwardingEntry:
        def __init__(self):
            self.egressVif = 'egressVif'
            self.nextHop = 'nextHop'
            self.nextHopMac = 'nextHopMac'
            self.adminStatus = 'adminStatus'
            self.operStatus = 'operStatus'
            self.rowStatus = 'rowStatus'
            self.ingressVif = 'ingressVif'

        def __call__(self):
            return 'RdwrDPRoutingIpForwardingEntry'

    class RsIDSImmediateChecksAttackEntry:
        def __init__(self):
            self.iDSImmChkName = 'iDSImmChkName'
            self.iDSImmChkAction = 'iDSImmChkAction'
            self.iDSImmChkRisk = 'iDSImmChkRisk'
            self.iDSImmChkStatus = 'iDSImmChkStatus'
            self.iDSImmChkReportAction = 'iDSImmChkReportAction'
            self.iDSImmChkId = 'iDSImmChkId'

        def __call__(self):
            return 'RsIDSImmediateChecksAttackEntry'

    class RsCCKChkBindingEntry:
        def __init__(self):
            self.group = 'group'
            self.mandatory = 'mandatory'
            self.rowStatus = 'rowStatus'
            self.healthChk = 'healthChk'
            self.element = 'element'

        def __call__(self):
            return 'RsCCKChkBindingEntry'

    class RsAPMMonitorDataItemEntry:
        def __init__(self):
            self.farmID = 'farmID'
            self.numberOfServerTcpResponses = 'numberOfServerTcpResponses'
            self.numberOfIncompleteServerTcpResponses = 'numberOfIncompleteServerTcpResponses'
            self.numberOfClientTcpResponses = 'numberOfClientTcpResponses'
            self.numberOfIncompleteClientTcpResponses = 'numberOfIncompleteClientTcpResponses'
            self.numberOfAlternateClientTcpResponses = 'numberOfAlternateClientTcpResponses'
            self.numberOfIncompleteAlternateClientTcpResponses = 'numberOfIncompleteAlternateClientTcpResponses'
            self.numberOfServerFullSslHandshakeResponses = 'numberOfServerFullSslHandshakeResponses'
            self.numberOfIncompleteServerFullSslHandshakeResponses = 'numberOfIncompleteServerFullSslHandshakeResponses'
            self.numberOfServerResumedSslHandshakeResponses = 'numberOfServerResumedSslHandshakeResponses'
            self.numberOfIncompleteServerResumedSslHandshakeResponses = 'numberOfIncompleteServerResumedSslHandshakeResponses'
            self.numberOfServerTransactionResponses = 'numberOfServerTransactionResponses'
            self.numberOfIncompleteServerTransactionResponses = 'numberOfIncompleteServerTransactionResponses'
            self.numberOfServerTransactionCompletedBytes = 'numberOfServerTransactionCompletedBytes'
            self.numberOfNewSessions = 'numberOfNewSessions'
            self.numberOfNewTransactions = 'numberOfNewTransactions'
            self.numberOfConcurrentSessions = 'numberOfConcurrentSessions'
            self.numberOfTransactionFailures = 'numberOfTransactionFailures'
            self.numberOfReceivedRequestPackets = 'numberOfReceivedRequestPackets'
            self.numberOfReceivedResponsePackets = 'numberOfReceivedResponsePackets'
            self.numberOfTransmittedRequestPackets = 'numberOfTransmittedRequestPackets'
            self.numberOfTransmittedResponsePackets = 'numberOfTransmittedResponsePackets'
            self.numberOfReceivedRetransmittedRequestPackets = 'numberOfReceivedRetransmittedRequestPackets'
            self.numberOfReceivedRetransmittedResponsePackets = 'numberOfReceivedRetransmittedResponsePackets'
            self.numberOfNewDelayedBindingSessions = 'numberOfNewDelayedBindingSessions'
            self.numberOfSkippedSessions = 'numberOfSkippedSessions'
            self.numberOfUnsampledSessions = 'numberOfUnsampledSessions'
            self.numberOfSkippedTransactions = 'numberOfSkippedTransactions'
            self.totalServerTcpResponseTime = 'totalServerTcpResponseTime'
            self.totalClientTcpResponseTime = 'totalClientTcpResponseTime'
            self.totalAlternateClientTcpResponseTime = 'totalAlternateClientTcpResponseTime'
            self.totalServerFullSslHandshakeResponseTime = 'totalServerFullSslHandshakeResponseTime'
            self.totalServerResumedSslHandshakeResponseTime = 'totalServerResumedSslHandshakeResponseTime'
            self.totalServerTransactionResponseTime = 'totalServerTransactionResponseTime'
            self.totalServerTransactionCompletedResponseTime = 'totalServerTransactionCompletedResponseTime'
            self.numberOfReceivedRequestBytes = 'numberOfReceivedRequestBytes'
            self.numberOfReceivedResponseBytes = 'numberOfReceivedResponseBytes'
            self.numberOfTransmittedRequestBytes = 'numberOfTransmittedRequestBytes'
            self.numberOfTransmittedResponseBytes = 'numberOfTransmittedResponseBytes'
            self.averageServerTcpResponseTime = 'averageServerTcpResponseTime'
            self.averageEffectiveServerTcpResponseTime = 'averageEffectiveServerTcpResponseTime'
            self.averageClientTcpResponseTime = 'averageClientTcpResponseTime'
            self.averageEffectiveClientTcpResponseTime = 'averageEffectiveClientTcpResponseTime'
            self.averageAlternateClientTcpResponseTime = 'averageAlternateClientTcpResponseTime'
            self.averageEffectiveAlternateClientTcpResponseTime = 'averageEffectiveAlternateClientTcpResponseTime'
            self.averageAllClientTcpResponseTime = 'averageAllClientTcpResponseTime'
            self.averageEffectiveAllClientTcpResponseTime = 'averageEffectiveAllClientTcpResponseTime'
            self.averageServerFullSslHandshakeResponseTime = 'averageServerFullSslHandshakeResponseTime'
            self.averageEffectiveServerFullSslHandshakeResponseTime = 'averageEffectiveServerFullSslHandshakeResponseTime'
            self.averageServerResumedSslHandshakeResponseTime = 'averageServerResumedSslHandshakeResponseTime'
            self.averageEffectiveServerResumedSslHandshakeResponseTime = 'averageEffectiveServerResumedSslHandshakeResponseTime'
            self.averageServerTransactionResponseTime = 'averageServerTransactionResponseTime'
            self.averageEffectiveServerTransactionResponseTime = 'averageEffectiveServerTransactionResponseTime'
            self.averageServerTransactionCompletedResponseTimePerByte = 'averageServerTransactionCompletedResponseTimePerByte'
            self.averageEffectiveServerTransactionCompletedResponseTimePerByte = 'averageEffectiveServerTransactionCompletedResponseTimePerByte'
            self.averageNumberOfConcurrentSessions = 'averageNumberOfConcurrentSessions'
            self.intervalId = 'intervalId'
            self.samplingAlgorithm = 'samplingAlgorithm'
            self.samplingRate = 'samplingRate'
            self.usePreciseSampling = 'usePreciseSampling'
            self.policyID = 'policyID'
            self.farmMonitorID = 'farmMonitorID'
            self.farmElementMonitorID = 'farmElementMonitorID'
            self.setNumber = 'setNumber'

        def __call__(self):
            return 'RsAPMMonitorDataItemEntry'

    class RsBWMFilterEntry:
        def __init__(self):
            self.description = 'description'
            self.protocol = 'protocol'
            self.destinationPort = 'destinationPort'
            self.sourceFromPort = 'sourceFromPort'
            self.sourceToPort = 'sourceToPort'
            self.oMPCOffset = 'oMPCOffset'
            self.oMPCMask = 'oMPCMask'
            self.oMPCPattern = 'oMPCPattern'
            self.oMPCCondition = 'oMPCCondition'
            self.oMPCLength = 'oMPCLength'
            self.contentOffset = 'contentOffset'
            self.content = 'content'
            self.contentType = 'contentType'
            self.type = 'type'
            self.status = 'status'
            self.contentEnd = 'contentEnd'
            self.contentData = 'contentData'
            self.contentCoding = 'contentCoding'
            self.contentDataCoding = 'contentDataCoding'
            self.oMPCOffsetBase = 'oMPCOffsetBase'
            self.destinationMaxPort = 'destinationMaxPort'
            self.sourceAppPortGroup = 'sourceAppPortGroup'
            self.destinationAppPortGroup = 'destinationAppPortGroup'
            self.sessionType = 'sessionType'
            self.sessionTypeDirection = 'sessionTypeDirection'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMFilterEntry'

    class RsServiceDiscoveryProfileEntry:
        def __init__(self):
            self.hTTPProfileName = 'hTTPProfileName'
            self.responseRate = 'responseRate'
            self.autoRemoval = 'autoRemoval'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsServiceDiscoveryProfileEntry'

    class RsMLBProximityTuning:
        def __init__(self):
            self.rsMLBMaxDynEntries = 'rsMLBMaxDynEntries'
            self.rsMLBMaxDynEntriesAfterReset = 'rsMLBMaxDynEntriesAfterReset'

        def __call__(self):
            return 'RsMLBProximityTuning'

    class VacmViewTreeFamilyEntry:
        def __init__(self):
            self.mask = 'mask'
            self.type = 'type'
            self.storageType = 'storageType'
            self.status = 'status'
            self.viewName = 'viewName'
            self.subtree = 'subtree'

        def __call__(self):
            return 'VacmViewTreeFamilyEntry'

    class IpForward:
        def __init__(self):
            self.ipCidrRouteNumber = 'ipCidrRouteNumber'

        def __call__(self):
            return 'IpForward'

    class RsBWMMacGroupCurrentEntry:
        def __init__(self):
            self.name = 'name'
            self.address = 'address'

        def __call__(self):
            return 'RsBWMMacGroupCurrentEntry'

    class RsDOS:
        def __init__(self):
            self.samplingRatio = 'samplingRatio'
            self.samplerOverloadMode = 'samplerOverloadMode'

        def __call__(self):
            return 'RsDOS'

    class RsMLBTunnelEntry:
        def __init__(self):
            self.operStatus = 'operStatus'
            self.mode = 'mode'
            self.latency = 'latency'
            self.remoteServiceName = 'remoteServiceName'
            self.remoteLinkAddress = 'remoteLinkAddress'
            self.localLinkAddress = 'localLinkAddress'

        def __call__(self):
            return 'RsMLBTunnelEntry'

    class RsMLBApplicationServerEntry:
        def __init__(self):
            self.mLBServerName = 'mLBServerName'
            self.mLBServerOperStatus = 'mLBServerOperStatus'
            self.mLBServerWeight = 'mLBServerWeight'
            self.mLBServerAttachedUsersNumber = 'mLBServerAttachedUsersNumber'
            self.mLBServerPeakLoad = 'mLBServerPeakLoad'
            self.mLBServerFramesRate = 'mLBServerFramesRate'
            self.mLBServerFramesLoad = 'mLBServerFramesLoad'
            self.mLBServerStatus = 'mLBServerStatus'
            self.mLBServerOperMode = 'mLBServerOperMode'
            self.mLBServerConnectionLimit = 'mLBServerConnectionLimit'
            self.mLBServerAdminStatus = 'mLBServerAdminStatus'
            self.mLBServerType = 'mLBServerType'
            self.mLBServerMacStatus = 'mLBServerMacStatus'
            self.mLBServerPortNumber = 'mLBServerPortNumber'
            self.mLBServerPeakBytesLoad = 'mLBServerPeakBytesLoad'
            self.mLBServerBytesRate = 'mLBServerBytesRate'
            self.mLBServerBytesLoad = 'mLBServerBytesLoad'
            self.mLBServerRecoveryTime = 'mLBServerRecoveryTime'
            self.mLBServerWarmUpTime = 'mLBServerWarmUpTime'
            self.mLBServerTotalFramesLoad = 'mLBServerTotalFramesLoad'
            self.mLBServerProximityCheck = 'mLBServerProximityCheck'
            self.mLBServerInBytesRate = 'mLBServerInBytesRate'
            self.mLBServerOutBytesRate = 'mLBServerOutBytesRate'
            self.mLBServerInBytesLoad = 'mLBServerInBytesLoad'
            self.mLBServerOutBytesLoad = 'mLBServerOutBytesLoad'
            self.mLBServerBytesLimit = 'mLBServerBytesLimit'
            self.mLBServerInBytesLimit = 'mLBServerInBytesLimit'
            self.mLBServerOutBytesLimit = 'mLBServerOutBytesLimit'
            self.mLBServerTos = 'mLBServerTos'
            self.mLBServerCCKId = 'mLBServerCCKId'
            self.mLBServerDiscardFlag = 'mLBServerDiscardFlag'
            self.mLBServerDiscardedPacketNum = 'mLBServerDiscardedPacketNum'
            self.mLBServerBillingMode = 'mLBServerBillingMode'
            self.mLBServerAddr = 'mLBServerAddr'

        def __call__(self):
            return 'RsMLBApplicationServerEntry'

    class RsIDSSignaturesAttributeAttackNumberEntry:
        def __init__(self):
            self.attackNumber = 'attackNumber'
            self.status = 'status'
            self.attributeType = 'attributeType'
            self.attributeName = 'attributeName'

        def __call__(self):
            return 'RsIDSSignaturesAttributeAttackNumberEntry'

    class RsIDSAdvancedFilterEntry:
        def __init__(self):
            self.type = 'type'
            self.status = 'status'
            self.name = 'name'
            self.basicName = 'basicName'

        def __call__(self):
            return 'RsIDSAdvancedFilterEntry'

    class RsSESSIONSynProtectionStatsTuning:
        def __init__(self):
            self.rsSESSIONSynProtectionStatsEntries = 'rsSESSIONSynProtectionStatsEntries'
            self.rsSESSIONSynProtectionStatsEntriesAfterReset = 'rsSESSIONSynProtectionStatsEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSynProtectionStatsTuning'

    class RsBWMDSCPEntry:
        def __init__(self):
            self.bWMDSCPPriority = 'bWMDSCPPriority'
            self.bWMDSCPGuaranteedBW = 'bWMDSCPGuaranteedBW'
            self.bWMDSCPMaxBW = 'bWMDSCPMaxBW'
            self.rsBWMDSCP = 'rsBWMDSCP'

        def __call__(self):
            return 'RsBWMDSCPEntry'

    class RsBWMAdvancedTuning:
        def __init__(self):
            self.rsBWMAdvancedEntries = 'rsBWMAdvancedEntries'
            self.rsBWMAdvancedEntriesAfterReset = 'rsBWMAdvancedEntriesAfterReset'

        def __call__(self):
            return 'RsBWMAdvancedTuning'

    class RsMLBURLtoIPEntry:
        def __init__(self):
            self.mLBURLLocDeviceIP = 'mLBURLLocDeviceIP'
            self.mLBURLStatus = 'mLBURLStatus'
            self.rsMLBURL = 'rsMLBURL'

        def __call__(self):
            return 'RsMLBURLtoIPEntry'

    class ReaIpFftEntry:
        def __init__(self):
            self.dstIpAddr = 'dstIpAddr'
            self.dstIpMask = 'dstIpMask'
            self.rangeType = 'rangeType'
            self.srcMacAddr = 'srcMacAddr'
            self.dstMacAddr = 'dstMacAddr'
            self.reNum = 'reNum'
            self.portNum = 'portNum'
            self.facsSrcIndex = 'facsSrcIndex'
            self.facsDstIndex = 'facsDstIndex'
            self.applFlags = 'applFlags'
            self.num = 'num'

        def __call__(self):
            return 'ReaIpFftEntry'

    class RsBWMPortBandwidthEntry:
        def __init__(self):
            self.rsBWMPortBandwidth = 'rsBWMPortBandwidth'
            self.bwmPortUsedBandwidth = 'bwmPortUsedBandwidth'
            self.index = 'index'

        def __call__(self):
            return 'RsBWMPortBandwidthEntry'

    class RsIDSScanningTrustedPorts:
        def __init__(self):
            self.status = 'status'
            self.profileName = 'profileName'
            self.port = 'port'

        def __call__(self):
            return 'RsIDSScanningTrustedPorts'

    class RsMLBMaxFragmentTableEntriesTuning:
        def __init__(self):
            self.rsMLBMaxFragmentTableSize = 'rsMLBMaxFragmentTableSize'
            self.rsMLBMaxFragmentTableSizeAfterReset = 'rsMLBMaxFragmentTableSizeAfterReset'

        def __call__(self):
            return 'RsMLBMaxFragmentTableEntriesTuning'

    class RsImportPolicyEntry:
        def __init__(self):
            self.update = 'update'
            self.override = 'override'
            self.instanceSelect = 'instanceSelect'
            self.file = 'file'

        def __call__(self):
            return 'RsImportPolicyEntry'

    class IfMIBObjects:
        def __init__(self):
            self.ifTableLastChange = 'ifTableLastChange'
            self.ifStackLastChange = 'ifStackLastChange'

        def __call__(self):
            return 'IfMIBObjects'

    class IpIfEntry:
        def __init__(self):
            self.prefix = 'prefix'
            self.index = 'index'
            self.fwdBroadcast = 'fwdBroadcast'
            self.bcastAddr = 'bcastAddr'
            self.vlanTag = 'vlanTag'
            self.label = 'label'
            self.status = 'status'
            self.backupAddr = 'backupAddr'
            self.addr = 'addr'

        def __call__(self):
            return 'IpIfEntry'

    class RsTrafficUtilizationPerPortEntryOTHER:
        def __init__(self):
            self.droppedPacketsPerPortOTHER = 'droppedPacketsPerPortOTHER'
            self.droppedBytesPerPortOTHER = 'droppedBytesPerPortOTHER'
            self.receivedPacketsPerPortOTHER = 'receivedPacketsPerPortOTHER'
            self.receivedBytesPerPortOTHER = 'receivedBytesPerPortOTHER'
            self.excludedPacketsPerPortOTHER = 'excludedPacketsPerPortOTHER'
            self.excludedBytesPerPortOTHER = 'excludedBytesPerPortOTHER'
            self.portPerPortOTHER = 'portPerPortOTHER'

        def __call__(self):
            return 'RsTrafficUtilizationPerPortEntryOTHER'

    class RsBWMACLModifyPolicyEntry:
        def __init__(self):
            self.index = 'index'
            self.description = 'description'
            self.destination = 'destination'
            self.source = 'source'
            self.service = 'service'
            self.vLANTagGroup = 'vLANTagGroup'
            self.portGroup = 'portGroup'
            self.activate = 'activate'
            self.inactivate = 'inactivate'
            self.action = 'action'
            self.protocol = 'protocol'
            self.icmpFlags = 'icmpFlags'
            self.classificationPoint = 'classificationPoint'
            self.operationalStatus = 'operationalStatus'
            self.status = 'status'
            self.packetReportStatus = 'packetReportStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMACLModifyPolicyEntry'

    class RsDnsServerParameters:
        def __init__(self):
            self.rsDnsServerEnable = 'rsDnsServerEnable'

        def __call__(self):
            return 'RsDnsServerParameters'

    class IpRouteLeaking:
        def __init__(self):
            self.ipLeakStaticToRip = 'ipLeakStaticToRip'
            self.ipLeakStaticToOspf = 'ipLeakStaticToOspf'
            self.ipLeakOspfToRip = 'ipLeakOspfToRip'
            self.ipLeakRipToOspf = 'ipLeakRipToOspf'
            self.ipLeakExtDirectToOspf = 'ipLeakExtDirectToOspf'
            self.ipLeakOverrideOSPFLeakonFailure = 'ipLeakOverrideOSPFLeakonFailure'
            self.ipLeakAdvertiseOSPFAccordingtoPortRules = 'ipLeakAdvertiseOSPFAccordingtoPortRules'

        def __call__(self):
            return 'IpRouteLeaking'

    class RsDnsProtBypassEntry:
        def __init__(self):
            self.status = 'status'
            self.values = 'values'
            self.rowStatus = 'rowStatus'
            self.controller = 'controller'
            self.type = 'type'

        def __call__(self):
            return 'RsDnsProtBypassEntry'

    class RsMLBRemoteLinkEntry:
        def __init__(self):
            self.name = 'name'
            self.operStatus = 'operStatus'
            self.mode = 'mode'
            self.dynamicLinkWeight = 'dynamicLinkWeight'
            self.setMode = 'setMode'
            self.status = 'status'
            self.remoteServiceName = 'remoteServiceName'
            self.address = 'address'

        def __call__(self):
            return 'RsMLBRemoteLinkEntry'

    class ReaTunning:
        def __init__(self):
            self.reaIpRemoteAgingTime = 'reaIpRemoteAgingTime'
            self.reaFftHashMaxChain = 'reaFftHashMaxChain'
            self.reaMltcstBitOn = 'reaMltcstBitOn'
            self.reaIpForwardEnable = 'reaIpForwardEnable'
            self.reaIpxForwardEnable = 'reaIpxForwardEnable'
            self.reaBridgeEnable = 'reaBridgeEnable'
            self.reaFacsEnable = 'reaFacsEnable'
            self.reaIpForwardDatagrams = 'reaIpForwardDatagrams'
            self.reaIpInDiscards = 'reaIpInDiscards'
            self.reaIpxForwardDatagrams = 'reaIpxForwardDatagrams'
            self.reaIpxInDiscards = 'reaIpxInDiscards'
            self.reaBrgDiscards = 'reaBrgDiscards'
            self.reaBrgForwards = 'reaBrgForwards'
            self.reaSrcViolationEnable = 'reaSrcViolationEnable'
            self.reaSrcViolationTrapEnable = 'reaSrcViolationTrapEnable'
            self.reaSrcAddrValidationEnable = 'reaSrcAddrValidationEnable'
            self.reaRsQueueDiscards = 'reaRsQueueDiscards'
            self.reaBufFree = 'reaBufFree'
            self.lreResetDstMacBit46 = 'lreResetDstMacBit46'
            self.lreQueSourceSelect = 'lreQueSourceSelect'
            self.lreResetDstMacBit47 = 'lreResetDstMacBit47'

        def __call__(self):
            return 'ReaTunning'

    class RsBWMCurrentFilterEntry:
        def __init__(self):
            self.description = 'description'
            self.protocol = 'protocol'
            self.destinationPort = 'destinationPort'
            self.sourceFromPort = 'sourceFromPort'
            self.sourceToPort = 'sourceToPort'
            self.oMPCOffset = 'oMPCOffset'
            self.oMPCMask = 'oMPCMask'
            self.oMPCPattern = 'oMPCPattern'
            self.oMPCCondition = 'oMPCCondition'
            self.oMPCLength = 'oMPCLength'
            self.contentOffset = 'contentOffset'
            self.content = 'content'
            self.contentType = 'contentType'
            self.type = 'type'
            self.contentEnd = 'contentEnd'
            self.contentData = 'contentData'
            self.contentCoding = 'contentCoding'
            self.contentDataCoding = 'contentDataCoding'
            self.oMPCOffsetBase = 'oMPCOffsetBase'
            self.destinationMaxPort = 'destinationMaxPort'
            self.sourceAppPortGroup = 'sourceAppPortGroup'
            self.destinationAppPortGroup = 'destinationAppPortGroup'
            self.sessionType = 'sessionType'
            self.sessionTypeDirection = 'sessionTypeDirection'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMCurrentFilterEntry'

    class RsMLBFarmEntry:
        def __init__(self):
            self.adminStatus = 'adminStatus'
            self.type = 'type'
            self.dispatchMethod = 'dispatchMethod'
            self.clientsLifeTime = 'clientsLifeTime'
            self.checkConnectivityStatus = 'checkConnectivityStatus'
            self.checkConnectivityMethod = 'checkConnectivityMethod'
            self.checkConnectivityInterval = 'checkConnectivityInterval'
            self.checkConnectivityRetries = 'checkConnectivityRetries'
            self.clientsConnectDenials = 'clientsConnectDenials'
            self.directionInChain = 'directionInChain'
            self.bypassInChain = 'bypassInChain'
            self.status = 'status'
            self.name = 'name'

        def __call__(self):
            return 'RsMLBFarmEntry'

    class RsHTTPFProfileEntry:
        def __init__(self):
            self.sensitivity = 'sensitivity'
            self.action = 'action'
            self.packetReport = 'packetReport'
            self.setManTriggers = 'setManTriggers'
            self.getPostTrs = 'getPostTrs'
            self.otherTrs = 'otherTrs'
            self.outboundBandwidth = 'outboundBandwidth'
            self.requestsPerSource = 'requestsPerSource'
            self.requestsPerConnection = 'requestsPerConnection'
            self.status = 'status'
            self.uriOnlyMitigation = 'uriOnlyMitigation'
            self.srcSuspTrs = 'srcSuspTrs'
            self.conSuspTrs = 'conSuspTrs'
            self.packetTrace = 'packetTrace'
            self.httpFloodSourceChallengeStatus = 'httpFloodSourceChallengeStatus'
            self.httpFloodCollectiveChallengeStatus = 'httpFloodCollectiveChallengeStatus'
            self.httpFloodMitigationBlockingStatus = 'httpFloodMitigationBlockingStatus'
            self.httpFloodChallengeMode = 'httpFloodChallengeMode'
            self.httpFloodOtherEngineStatus = 'httpFloodOtherEngineStatus'
            self.httpFloodPerSrcEngineStatus = 'httpFloodPerSrcEngineStatus'
            self.httpFloodGetPostEngineStatus = 'httpFloodGetPostEngineStatus'
            self.httpFloodOutboundBWEngineStatus = 'httpFloodOutboundBWEngineStatus'
            self.httpFloodPerConnectionEngineStatus = 'httpFloodPerConnectionEngineStatus'
            self.name = 'name'

        def __call__(self):
            return 'RsHTTPFProfileEntry'

    class RsREStateMonitoring:
        def __init__(self):
            self.rsREStateResetCounter = 'rsREStateResetCounter'

        def __call__(self):
            return 'RsREStateMonitoring'

    class SnmpNotifyFilterProfileEntry:
        def __init__(self):
            self.name = 'name'
            self.storType = 'storType'
            self.rowStatus = 'rowStatus'
            self.targetParamsName = 'targetParamsName'

        def __call__(self):
            return 'SnmpNotifyFilterProfileEntry'

    class RsAPMAlertSpecEntry:
        def __init__(self):
            self.rowStatus = 'rowStatus'
            self.enabledStatus = 'enabledStatus'
            self.description = 'description'
            self.expression = 'expression'
            self.evaluationInterval = 'evaluationInterval'
            self.reportedMonitorDataItemList = 'reportedMonitorDataItemList'
            self.id = 'id'

        def __call__(self):
            return 'RsAPMAlertSpecEntry'

    class DpsRTSPControlTableTuning:
        def __init__(self):
            self.dpsRTSPControlTableEntries = 'dpsRTSPControlTableEntries'
            self.dpsRTSPControlTableEntriesAfterReset = 'dpsRTSPControlTableEntriesAfterReset'

        def __call__(self):
            return 'DpsRTSPControlTableTuning'

    class RsMLBBasicNatEntry:
        def __init__(self):
            self.status = 'status'
            self.mode = 'mode'
            self.fromLclAddress = 'fromLclAddress'
            self.toLclAddress = 'toLclAddress'
            self.portNumber = 'portNumber'
            self.routerAddress = 'routerAddress'
            self.fromNatAddress = 'fromNatAddress'
            self.toNatAddress = 'toNatAddress'

        def __call__(self):
            return 'RsMLBBasicNatEntry'

    class RsBWMCurrentNetworkEntry:
        def __init__(self):
            self.address = 'address'
            self.mask = 'mask'
            self.fromIP = 'fromIP'
            self.toIP = 'toIP'
            self.mode = 'mode'
            self.name = 'name'
            self.subIndex = 'subIndex'

        def __call__(self):
            return 'RsBWMCurrentNetworkEntry'

    class RsIpFragment:
        def __init__(self):
            self.rsIpFragmentStatus = 'rsIpFragmentStatus'
            self.rsIpFragmentQueuingLimit = 'rsIpFragmentQueuingLimit'
            self.rsIpFragmentAging = 'rsIpFragmentAging'
            self.rsIpFragmentForwardAgedPacket = 'rsIpFragmentForwardAgedPacket'

        def __call__(self):
            return 'RsIpFragment'

    class RsOverloadThresholdsEntry:
        def __init__(self):
            self.value = 'value'
            self.rowStatus = 'rowStatus'
            self.moduleType = 'moduleType'
            self.congestionElement = 'congestionElement'
            self.type = 'type'

        def __call__(self):
            return 'RsOverloadThresholdsEntry'

    class RsCCKPktSequenceEntry:
        def __init__(self):
            self.type = 'type'
            self.string = 'string'
            self.description = 'description'
            self.rowStatus = 'rowStatus'
            self.compareMtd = 'compareMtd'
            self.seqId = 'seqId'
            self.pktId = 'pktId'

        def __call__(self):
            return 'RsCCKPktSequenceEntry'

    class RdwrClientsEntry:
        def __init__(self):
            self.sourceAddr = 'sourceAddr'
            self.sourcePort = 'sourcePort'
            self.requestedAddr = 'requestedAddr'
            self.requestedPort = 'requestedPort'
            self.farmAddr = 'farmAddr'
            self.serverAddr = 'serverAddr'
            self.serverPort = 'serverPort'
            self.attachedTime = 'attachedTime'
            self.nATaddr = 'nATaddr'
            self.nATPort = 'nATPort'
            self.timeToLive = 'timeToLive'
            self.clientType = 'clientType'
            self.clientMode = 'clientMode'
            self.userData1 = 'userData1'
            self.userData2 = 'userData2'
            self.status = 'status'
            self.index = 'index'

        def __call__(self):
            return 'RdwrClientsEntry'

    class RsStatefulReportThresholdEntry:
        def __init__(self):
            self.sTATFULReportThresholdValue = 'sTATFULReportThresholdValue'
            self.sTATFULReportThresholdRisk = 'sTATFULReportThresholdRisk'

        def __call__(self):
            return 'RsStatefulReportThresholdEntry'

    class RndMidLevelManagement:
        def __init__(self):
            self.rndHardwareConfiguration = 'rndHardwareConfiguration'
            self.rndEraseSimulatedConfiguration = 'rndEraseSimulatedConfiguration'

        def __call__(self):
            return 'RndMidLevelManagement'

    class RsBWMNetworkRangeTuning:
        def __init__(self):
            self.rsBWMNetworkRangeEntries = 'rsBWMNetworkRangeEntries'
            self.rsBWMNetworkRangeEntriesAfterReset = 'rsBWMNetworkRangeEntriesAfterReset'

        def __call__(self):
            return 'RsBWMNetworkRangeTuning'

    class RsBWMDestinationTuning:
        def __init__(self):
            self.rsBWMDestinationEntries = 'rsBWMDestinationEntries'
            self.rsBWMDestinationEntriesAfterReset = 'rsBWMDestinationEntriesAfterReset'

        def __call__(self):
            return 'RsBWMDestinationTuning'

    class RsSESSIONPasvProtocolsTuning:
        def __init__(self):
            self.rsSESSIONPasvProtocolsEntries = 'rsSESSIONPasvProtocolsEntries'
            self.rsSESSIONPasvProtocolsEntriesAfterReset = 'rsSESSIONPasvProtocolsEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONPasvProtocolsTuning'

    class VirtualLanEntry:
        def __init__(self):
            self.vlProto = 'vlProto'
            self.vlAutoConfigEnable = 'vlAutoConfigEnable'
            self.vlStatus = 'vlStatus'
            self.vlType = 'vlType'
            self.vlIfIndex = 'vlIfIndex'

        def __call__(self):
            return 'VirtualLanEntry'

    class RsSESSIONSessionTuning:
        def __init__(self):
            self.rsSESSIONSessionEntries = 'rsSESSIONSessionEntries'
            self.rsSESSIONSessionEntriesAfterReset = 'rsSESSIONSessionEntriesAfterReset'

        def __call__(self):
            return 'RsSESSIONSessionTuning'

    class RsDeleteServerEntry:
        def __init__(self):
            self.update = 'update'
            self.name = 'name'

        def __call__(self):
            return 'RsDeleteServerEntry'

    class RsBWMServiceEntry:
        def __init__(self):
            self.tableType = 'tableType'
            self.type = 'type'
            self.name = 'name'

        def __call__(self):
            return 'RsBWMServiceEntry'

    class VrrpStatistics:
        def __init__(self):
            self.vrrpRouterChecksumErrors = 'vrrpRouterChecksumErrors'
            self.vrrpRouterVersionErrors = 'vrrpRouterVersionErrors'
            self.vrrpRouterVrIdErrors = 'vrrpRouterVrIdErrors'

        def __call__(self):
            return 'VrrpStatistics'

    class RsBWMChainTuning:
        def __init__(self):
            self.rsBWMMaxChainPolicies = 'rsBWMMaxChainPolicies'
            self.rsBWMMaxChainPoliciesAfterReset = 'rsBWMMaxChainPoliciesAfterReset'

        def __call__(self):
            return 'RsBWMChainTuning'

    class RsNetFloodQuotaEntry:
        def __init__(self):
            self.tcpQuota = 'tcpQuota'
            self.udpQuota = 'udpQuota'
            self.icmpQuota = 'icmpQuota'
            self.igmpQuota = 'igmpQuota'
            self.way = 'way'

        def __call__(self):
            return 'RsNetFloodQuotaEntry'

    class RndAlarmOptions:
        def __init__(self):
            self.rndAlarmEnabling = 'rndAlarmEnabling'
            self.rndAlarmInterval = 'rndAlarmInterval'

        def __call__(self):
            return 'RndAlarmOptions'

    class RsMLBVirtualIPEntry:
        def __init__(self):
            self.mode = 'mode'
            self.status = 'status'
            self.iPAddress = 'iPAddress'

        def __call__(self):
            return 'RsMLBVirtualIPEntry'

    class RsBWMNetworkTuning:
        def __init__(self):
            self.rsBWMNetworkEntries = 'rsBWMNetworkEntries'
            self.rsBWMNetworkEntriesAfterReset = 'rsBWMNetworkEntriesAfterReset'

        def __call__(self):
            return 'RsBWMNetworkTuning'

    class RsSignalingTotalUtilEntry:
        def __init__(self):
            self.rsSignalingTotalUtil = 'rsSignalingTotalUtil'
            self.utilTimestamp = 'utilTimestamp'

        def __call__(self):
            return 'RsSignalingTotalUtilEntry'

    class RsIDSMPLSRDParams:
        def __init__(self):
            self.rsIDSMPLSRDMechanismStatus = 'rsIDSMPLSRDMechanismStatus'
            self.rsIDSMPLSRDTableClean = 'rsIDSMPLSRDTableClean'

        def __call__(self):
            return 'RsIDSMPLSRDParams'

    class RdwrBgp:
        def __init__(self):
            self.rdwrBgpAdminStatus = 'rdwrBgpAdminStatus'
            self.rdwrBgpLocalAS = 'rdwrBgpLocalAS'
            self.rdwrBgpInitDelay = 'rdwrBgpInitDelay'
            self.rdwrBgpInternalLoopback = 'rdwrBgpInternalLoopback'

        def __call__(self):
            return 'RdwrBgp'
