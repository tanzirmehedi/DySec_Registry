"""
cord.types
~~~~~~~~~~~~~~

Typings for the Cord API

:copyright: (c) 2015-present VincentRPS
:license: MIT, see LICENSE for more details.

"""
