from .colorize import Colors
colors = Colors
