# Entry point
from coloring.cli import main

if __name__ == "__main__":
    main()
