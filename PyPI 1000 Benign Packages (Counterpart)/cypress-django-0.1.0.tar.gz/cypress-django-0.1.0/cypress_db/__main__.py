import sys
from .cmd import main

sys.exit(main())
