# coding=utf-8
# --------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
from .v2015_06_01_preview.models import *
from .v2017_08_01.models import *
from .v2017_08_01_preview.models import *
from .v2019_01_01.models import *
from .v2019_01_01_preview.models import *
from .v2019_08_01.models import *
from .v2020_01_01.models import *
from .v2020_01_01_preview.models import *
from .v2021_05_01_preview.models import *
from .v2021_06_01.models import *
from .v2021_07_01_preview.models import *
from .v2021_10_01_preview.models import *
from .v2022_01_01.models import *
from .v2022_01_01_preview.models import *
from .v2022_05_01.models import *
from .v2022_07_01_preview.models import *
from .v2022_11_20_preview.models import *
from .v2022_12_01_preview.models import *
from .v2023_01_01_preview.models import *
from .v2023_02_01_preview.models import *
from .v2023_02_15_preview.models import *
from .v2023_05_01.models import *
from .v2023_05_01_preview.models import *
from .v2023_10_01_preview.models import *
from .v2023_11_15.models import *
from .v2024_01_01.models import *
from .v2024_04_01.models import *
