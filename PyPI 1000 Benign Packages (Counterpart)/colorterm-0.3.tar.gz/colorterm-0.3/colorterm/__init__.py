from .colorterm import ColorTerm, formatter
from .table import Table

colorterm = colorterm.ColorTerm()
