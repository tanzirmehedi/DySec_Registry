colorterm's documentation!
##########################

colorterm is a package to write some formatted message in your terminal. It supports 16 colors. You can set:

    * formatting like underline, bold, ...
    * color
    * background color
    * table formatting

`Read the documentation <http://colorterm.readthedocs.org/en/latest/>`_
