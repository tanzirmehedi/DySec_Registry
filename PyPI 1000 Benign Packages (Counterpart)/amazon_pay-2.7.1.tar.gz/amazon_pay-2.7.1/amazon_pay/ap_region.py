regions = {'uk': 'mws-eu.amazonservices.com',
           'de': 'mws-eu.amazonservices.com',
           'eu': 'mws-eu.amazonservices.com',
           'us': 'mws.amazonservices.com',
           'na': 'mws.amazonservices.com',
           'jp': 'mws.amazonservices.jp'}
