from bytetracker.byte_tracker import BYTETracker

__version__ = "0.3.2"
