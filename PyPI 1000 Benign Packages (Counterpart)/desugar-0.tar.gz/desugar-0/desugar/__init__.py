"""Re-implement the parts of Python that allow removing its syntactic sugar."""
__version__ = "0"
