dpy
===================

[![PyPI version](https://badge.fury.io/py/dpy.svg)](http://badge.fury.io/py/dpy)

A tool that automatically generates quality documentation for Python projects.
dpy stands for Document Python.
