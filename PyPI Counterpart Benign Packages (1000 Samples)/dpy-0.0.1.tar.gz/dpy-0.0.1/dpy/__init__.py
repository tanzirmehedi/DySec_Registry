"""A tool that automatically generates quality documentation for Python projects."""

__version__ = "0.0.1"
