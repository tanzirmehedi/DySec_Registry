# Python DIscord RPC library

This library implements a class to connect to a local Discord RPC server and send rich presence data.