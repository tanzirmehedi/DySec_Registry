To use (with caution), simply do::

>>> from cvgtracker import Tracker

To visualize the live-updating plot while the tracker runs, one needs to install bokeh by

>>> easy_install bokeh

and uses "bokeh serve" option

There is a file called "trial.py" for testing. Please do the following 

>>> bokeh serve
>>> python trial.py

Your web-brower will open a new window or tab to illustrate the tracker
