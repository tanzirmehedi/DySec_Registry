try:
        from kfun_fake import kfunc
except:
        pass
