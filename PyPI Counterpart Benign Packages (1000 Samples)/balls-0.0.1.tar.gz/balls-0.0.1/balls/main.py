import requests

class Balls:
  def __init__(self, balls=0):
    self.balls = balls
  def ball(self):
    self.balls += 1