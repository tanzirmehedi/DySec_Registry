aio.http
=======

This package has been moved to aio.http.server_ (pypi_)

.. _aio.http.server: https://github.com/phlax/aio.http.server
.. _pypi: https://pypi.python.org/pypi/aio.http.server
