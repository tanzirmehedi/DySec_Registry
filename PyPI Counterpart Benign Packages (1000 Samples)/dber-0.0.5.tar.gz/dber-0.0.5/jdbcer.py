"""
组件dber的别名jdbcer
"""
from dber import *