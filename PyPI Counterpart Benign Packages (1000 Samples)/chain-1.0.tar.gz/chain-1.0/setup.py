from distutils.core import setup
setup(name='chain',
      version='1.0',
      description='A jQuery like list wrapper.',
      author='Hao Deng',
      author_email='denghao8888@gmail.com',
      py_modules=['chain'],
      )
