SLEEP_TIME = "sleep_time"
ERROR_SLEEP_TIME = "error_sleep_time"
LOG_LEVEL = "log_level"
UNHEALTHY_HANDLER = "unhealthy"
HEALTHY_HANDLER = "healthy"


