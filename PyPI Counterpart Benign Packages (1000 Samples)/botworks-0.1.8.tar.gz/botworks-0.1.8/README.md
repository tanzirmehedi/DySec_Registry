# Botworks

Easy to use slack bot

To start up the bot:

> Botworks("token", "botname", [list of channel definitions], {config: "map"}).listen()