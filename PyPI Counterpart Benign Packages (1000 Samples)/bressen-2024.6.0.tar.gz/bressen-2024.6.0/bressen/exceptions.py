class KeringNotFoundError(Exception):
    pass


class EmptyOffset(Exception):
    pass
