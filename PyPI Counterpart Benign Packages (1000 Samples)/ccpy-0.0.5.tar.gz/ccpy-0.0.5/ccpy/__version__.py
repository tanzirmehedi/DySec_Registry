# -*- coding:utf-8 -*-
"""
 ######   ######  ########  ##    ##
##    ## ##    ## ##     ##  ##  ##
##       ##       ##     ##   ####
##       ##       ########     ##
##       ##       ##           ##
##    ## ##    ## ##           ##
 ######   ######  ##           ##
"""

__title__ = 'ccpy'
__description__ = 'Python Free Currency Converter'
__url__ = 'https://github.com/chyi341152/ccpy'
__version__ = '0.0.5'
__build__ = 0x00001
__author__ = "Chyi's"
__author_email__ = 'chyiyaqing@gmail.com'
__license__ = 'MIT'
__copyright__ = "Copyright 2018 Chyi's"
__mascot__ = '\U0001f370 \U0001F41C \U0001f370'