from setuptools import setup, find_packages

setup(
    name='beautifish',
    version='2.2.1',
    packages=find_packages(),
    install_requires=[
        'pyfiglet>=1.0.2'
    ],
)
