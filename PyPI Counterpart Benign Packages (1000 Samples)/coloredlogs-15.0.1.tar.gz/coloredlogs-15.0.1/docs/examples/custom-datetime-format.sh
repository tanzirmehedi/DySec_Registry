export COLOREDLOGS_LOG_FORMAT='%(asctime)s - %(message)s'
export COLOREDLOGS_DATE_FORMAT='%H:%M:%S'
coloredlogs --demo
