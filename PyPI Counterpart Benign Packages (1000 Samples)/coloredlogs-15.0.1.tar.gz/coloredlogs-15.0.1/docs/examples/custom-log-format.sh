export COLOREDLOGS_LOG_FORMAT='[%(hostname)s] %(asctime)s %(message)s'
coloredlogs --demo
