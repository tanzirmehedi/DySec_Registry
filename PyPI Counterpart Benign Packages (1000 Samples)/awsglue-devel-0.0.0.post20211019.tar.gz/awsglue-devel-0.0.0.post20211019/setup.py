from setuptools import find_packages, setup

setup(
    name='awsglue-devel',
    version='0.0.0.post20211019',
    long_description=__doc__,
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
