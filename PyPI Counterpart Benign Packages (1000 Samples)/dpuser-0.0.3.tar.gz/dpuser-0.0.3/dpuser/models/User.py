from dpuser.model_bases import MyAbstractBaseUser

class User(MyAbstractBaseUser):
	pass
