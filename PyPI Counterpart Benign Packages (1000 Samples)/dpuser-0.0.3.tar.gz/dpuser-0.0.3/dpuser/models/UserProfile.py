from dpuser.model_bases import AbstractBaseUserProfile

class UserProfile(AbstractBaseUserProfile):
	pass
