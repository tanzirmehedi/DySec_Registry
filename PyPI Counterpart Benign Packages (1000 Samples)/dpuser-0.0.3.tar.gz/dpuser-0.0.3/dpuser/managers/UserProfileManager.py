from django.db import models

class UserProfileManager(models.Manager):
    pass
