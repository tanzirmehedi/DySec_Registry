from django.contrib import admin
from dpuser.models.User import User

admin.site.register(User)
