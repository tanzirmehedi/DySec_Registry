"""Compatibility helpers for the different Python versions."""

import sys

platform = sys.platform
