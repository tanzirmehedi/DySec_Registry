`compilers` is a namespace for language compilers (C, C++, Rust) on Python.
