============
Contributors
============

* Daniel Thonon - *Initial work* - https://framagit.org/dthonon
* Frédéric Cloitre - *Testing and bug fixing* - https://framagit.org/fred.perso

See also the list of contributors at https://framagit.org/lpo/Client_API_VN/.

Acknowledgments
---------------
* Gaëtan Delaloye, for providing examples and support during the development.

