===================
validate User Guide
===================