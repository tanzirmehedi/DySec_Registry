=========
Reference
=========

This is the class and function reference of pydirect. Please refer to
the :ref:`tutorial <tutorial>` for further details, as the class and
function raw specifications may not be enough to give full guidelines on their
uses.

.. autofunction:: DIRECT.solve

