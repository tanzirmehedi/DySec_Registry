.. pydirect documentation master file, created by
   sphinx-quickstart on Wed May 30 10:39:22 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pydirect's documentation!
====================================

:mod:`DIRECT` Package
---------------------

.. automodule:: DIRECT.__init__

Contents:

.. toctree::
   :maxdepth: 2

   install
   tutorial
   reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

