from namespace_package import top_level_function

top_level_function.do_something()
