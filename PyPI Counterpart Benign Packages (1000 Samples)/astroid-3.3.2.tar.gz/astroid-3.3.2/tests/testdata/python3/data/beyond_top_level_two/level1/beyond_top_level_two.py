def func(var, some_other_var):
    pass
