This submodule should have the same name as a directory in the root of the project that
is _NOT_ a python module. For this reason, it's currently called "doc".
