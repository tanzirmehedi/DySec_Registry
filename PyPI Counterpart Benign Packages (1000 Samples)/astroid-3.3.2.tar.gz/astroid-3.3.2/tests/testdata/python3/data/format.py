"""A multiline string
"""

function('aeozrijz\
earzer', hop)
# XXX write test
x = [i for i in range(5)
     if i % 4]

fonction(1,
         2,
         3,
         4)

def definition(a,
               b,
               c):
    return a + b + c

class debile(dict,
             object):
    pass

if aaaa: pass
else:
    aaaa,bbbb = 1,2
    aaaa,bbbb = bbbb,aaaa
# XXX write test
hop = \
    aaaa


__revision__.lower();

