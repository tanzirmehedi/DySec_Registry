# https://github.com/pylint-dev/astroid/issues/749
class OriginalClass:
    pass
