<p align="center">
  <img src=./images/demotron_logo.png alt="Demotron Logo" width="200">
</p>

# demotron

demotron is built for how I best want to solve problems as a Solutions Architect for dev tools: demos and teaching. 

I make many tweaks to the same motions when I demo live and when I teach people how to do something through simulations that reflect realistic problems worth solving. This is annoying and error prone, and forces me to do a lot of copy/paste and sanity checks before I do anything.

I'm going to start with SQLMesh as it's a tool I'm actively using and learning. 

And honestly, I'm here to have a truckload of fun.