We thank anyone who has contributed to this project, and welcome anyone to contribute further.

For a list of contributors, please see https://github.com/python-distro/distro/graphs/contributors