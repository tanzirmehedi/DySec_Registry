import logging

logger = logging.getLogger("clicky")
