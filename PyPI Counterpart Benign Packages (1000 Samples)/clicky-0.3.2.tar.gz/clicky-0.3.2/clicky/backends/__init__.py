"""
Backend implementations.

Backends are responsible for integrating with external services like Slack,
Discord, etc.
"""
