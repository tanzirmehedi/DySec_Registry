"""
Frontend implementations.

Frontends are responsible for integrating with libraries like Click and
argparse.
"""
