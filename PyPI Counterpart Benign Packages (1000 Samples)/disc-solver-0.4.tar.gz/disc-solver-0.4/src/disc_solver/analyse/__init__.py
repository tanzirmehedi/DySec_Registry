# -*- coding: utf-8 -*-
"""
Analysis component of Disc Solver
"""
