Code for solving non-ideal MHD wind solutions as part of my PhD

Email me for more details
