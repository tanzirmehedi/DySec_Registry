__version__ = "1.1.0"


class APP(object):
    name = "colorize"
    program = "python -m colorize"
    version = __version__
    description = "Command line utility to colorize other commands output"
