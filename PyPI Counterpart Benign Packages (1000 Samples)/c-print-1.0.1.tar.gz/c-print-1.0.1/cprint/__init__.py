from .cprint import cprint

'''
Small python package for printing text in different colours and typography.
'''