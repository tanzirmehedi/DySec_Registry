=====
Usage
=====

To use csvviz in a project::

    import csvviz
