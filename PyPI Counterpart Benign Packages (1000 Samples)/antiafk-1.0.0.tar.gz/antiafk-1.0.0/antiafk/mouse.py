from pynput.mouse import Mouse, Controller


class Mouse(object):
    def __init__(self, button):
        self.button = button

    def __repr__(self):
        return f''

    def __str__(self):
        return f''

    def trigger(self):
        try:
            pass
        except Exception as e:
            raise e
