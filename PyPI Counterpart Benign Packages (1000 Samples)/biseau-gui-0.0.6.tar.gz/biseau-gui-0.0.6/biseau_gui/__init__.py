__version__ = '0.0.6'
from .mainwindow import MainWindow
