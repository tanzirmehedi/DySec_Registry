__title__ = "clistyle"
__author__ = "Juan Bindez"
__license__ = "GPLv2 License"
__js__ = None
__js_url__ = None


from clistyle.__main__ import Color
from clistyle.version import __version__