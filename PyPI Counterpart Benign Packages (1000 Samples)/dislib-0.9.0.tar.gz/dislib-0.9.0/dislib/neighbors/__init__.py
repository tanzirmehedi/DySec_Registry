from dislib.neighbors.base import NearestNeighbors

__all__ = ['NearestNeighbors']
