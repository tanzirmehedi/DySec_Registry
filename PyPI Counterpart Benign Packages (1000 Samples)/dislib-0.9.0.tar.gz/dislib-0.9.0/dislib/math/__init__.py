from dislib.math.base import kron, svd

__all__ = ['kron', 'svd']
