from dislib.sorting.terasort.base import TeraSort

__all__ = ["TeraSort"]
