"""Top-level package for Curl with Arguments for Url."""

__author__ = """Valmiki Rao"""
__email__ = 'valmikirao@gmail.com'
__version__ = '0.1.4'
