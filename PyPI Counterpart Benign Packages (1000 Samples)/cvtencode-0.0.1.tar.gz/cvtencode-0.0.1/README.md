# cvtencode: tiny convert encode tool, just for convenience
