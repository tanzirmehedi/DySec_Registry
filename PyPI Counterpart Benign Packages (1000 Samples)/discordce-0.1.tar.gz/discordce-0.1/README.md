## Overview
Discord-Cache-Exporter(discordce) is a package for exporting cached data files as .png 
 
This project was written with the intention of learning how to package a project.


### Arguments
Argument  | Description  | Example
------------- | ------------- | -------------
-o, --output | Output directory | `Z:\Exported images`