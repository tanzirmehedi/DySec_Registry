Microsoft Azure CLI 'private-dns' Command Module
================================================

This package is for the 'private-dns' module.
i.e. 'az network private-dns'
