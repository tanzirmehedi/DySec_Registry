.. :changelog:

Release History
===============

1.0.2
+++++
* Minor fixes

1.0.1
+++++
* Minor fixes

1.0.0
+++++
* az network private-dns: CLI for Private DNS zones.
