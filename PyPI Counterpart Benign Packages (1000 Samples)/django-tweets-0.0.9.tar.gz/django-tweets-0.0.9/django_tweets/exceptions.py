class SettingError(Exception):
    pass
