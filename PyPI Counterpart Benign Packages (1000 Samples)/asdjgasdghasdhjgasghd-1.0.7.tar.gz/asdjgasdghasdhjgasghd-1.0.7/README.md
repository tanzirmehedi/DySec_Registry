# etcd-watcher

About Etcd watcher for PyCasbin.
