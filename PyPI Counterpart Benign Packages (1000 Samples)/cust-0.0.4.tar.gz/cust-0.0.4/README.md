# Cust

## Installing:
```bash
pip install cust
```

***
## Classes:

- `math_`
- `utils`

***
## How to use example:


```python
import cust

cust.math_.percentage(100, 10)

# Returns 10.0
```

***
Made by mi66mc

This is a simple library with utils commands!