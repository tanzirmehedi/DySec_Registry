# This file is required for some of the tests of Python 2
