# craw tool

Crawl tool for spider crawling.  
Include regex,xpath,session,csv operation.  
I use this tool for four years.Summary by my own experience. 

author email:
meng93914@gamil.com


