"""Decode bencoded binary files."""

from bencoding.core import decode

__all__ = ["decode"]
