# pylint: disable=unused-import,missing-docstring

from deepr.examples.movielens.macros.paths import Paths
