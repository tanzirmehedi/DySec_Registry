# pylint: disable=unused-import,missing-docstring

import deepr.examples.movielens.jobs
import deepr.examples.movielens.layers
import deepr.examples.movielens.prepros
import deepr.examples.movielens.readers
