# pylint: disable=unused-import,missing-docstring

from deepr.examples.movielens.readers.csv import TrainCSVReader, TestCSVReader
