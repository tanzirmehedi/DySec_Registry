# pylint: disable=unused-import,missing-docstring

from deepr.examples.multiply.jobs.build import Build
from deepr.examples.multiply.jobs.predict import PredictProto, PredictSavedModel
