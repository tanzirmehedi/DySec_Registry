# pylint: disable=unused-import,missing-docstring

import deepr.examples.multiply.jobs
import deepr.examples.multiply.layers
import deepr.examples.multiply.macros
import deepr.examples.multiply.prepros
