# pylint: disable=unused-import,missing-docstring

from deepr.examples.multiply.prepros.default import DefaultPrepro
from deepr.examples.multiply.prepros.inference import InferencePrepro
