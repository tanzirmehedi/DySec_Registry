# pylint: disable=unused-import,missing-docstring

from deepr.examples.multiply.layers.loss import SquaredL2
from deepr.examples.multiply.layers.model import Multiply
