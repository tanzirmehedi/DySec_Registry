# pylint: disable=unused-import,missing-docstring

from deepr.examples.multiply.macros.paths import Paths
