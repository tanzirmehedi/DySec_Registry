# pylint: disable=unused-import,missing-docstring

from deepr.predictors.base import Predictor
from deepr.predictors.proto import ProtoPredictor
from deepr.predictors.saved_model import SavedModelPredictor, get_latest_saved_model
