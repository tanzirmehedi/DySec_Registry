# pylint: disable=unused-import,missing-docstring

from deepr.writers.base import Writer
from deepr.writers.record import TFRecordWriter
