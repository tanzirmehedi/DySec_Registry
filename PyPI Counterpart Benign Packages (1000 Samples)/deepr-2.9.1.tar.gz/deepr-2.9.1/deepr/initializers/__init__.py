# pylint: disable=unused-import,missing-docstring

from deepr.initializers.checkpoint_initializer import CheckpointInitializer
