"""Dummy macro wrapper to mark macros as a dynamic macro."""


class Dynamic(dict):
    """Dummy macro wrapper to mark macros as a dynamic macro."""
