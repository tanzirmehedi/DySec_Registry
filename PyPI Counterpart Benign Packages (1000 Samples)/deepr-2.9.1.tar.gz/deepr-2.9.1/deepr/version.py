# pylint: disable=all

__version__ = "2.9.1"
__author__ = "Criteo"
