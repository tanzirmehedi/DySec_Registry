# pylint: disable=unused-import,missing-docstring

from deepr.vocab.base import size, read, write
