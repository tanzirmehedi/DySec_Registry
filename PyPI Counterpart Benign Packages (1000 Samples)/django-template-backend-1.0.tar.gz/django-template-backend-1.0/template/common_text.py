template_cannot_edit_property = 'You cannot edit the property "{}"'
template_date_out_of_range = 'The date "{}" is out of range of "{}" through "{}"'
