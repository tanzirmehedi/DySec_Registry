from os import path
from setuptools import setup, find_packages

here = path.abspath(path.dirname(__file__))

with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup_requires = [
    'setuptools_scm'
]

install_requires = [
    'django~=2.2',
    'djangorestframework~=3.11',
    'django-filter~=2.3',
    'celery~=5.0',
]

setup(
    name='django-template-backend',
    description='Django Template Backend',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/personal-server/django-template-backend',
    author='Sheldon Woodward',
    author_email='me@sheldonw.com',
    license='MIT',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Framework :: Django :: 2.2',
        'License :: OSI Approved :: MIT License',
        'Intended Audience :: Developers',
        'Topic :: Internet :: WWW/HTTP :: Session',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
    ],
    keywords='django backend',
    packages=find_packages(exclude=['template_project']),
    python_requires='~=3.8',
    setup_requires=setup_requires,
    install_requires=install_requires,
    use_scm_version=True
)
