import pytest


@pytest.fixture
def common_fixture():
    pass
