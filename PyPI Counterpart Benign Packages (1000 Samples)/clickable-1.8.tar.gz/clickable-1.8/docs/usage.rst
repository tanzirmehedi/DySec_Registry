=====
Usage
=====

To use clickable helper scripts in a project::

    import clickable
