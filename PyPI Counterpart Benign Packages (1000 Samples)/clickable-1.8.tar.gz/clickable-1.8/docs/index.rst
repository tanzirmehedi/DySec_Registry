Welcome to clickable helper scripts's documentation!
====================================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
