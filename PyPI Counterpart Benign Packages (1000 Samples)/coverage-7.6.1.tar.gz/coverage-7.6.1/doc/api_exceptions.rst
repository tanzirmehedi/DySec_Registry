.. Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
.. For details: https://github.com/nedbat/coveragepy/blob/master/NOTICE.txt

.. _api_exceptions:

Coverage exceptions
-------------------

.. module:: coverage.exceptions

.. autoclass:: CoverageException

.. automodule:: coverage.exceptions
    :noindex:
    :members:
    :exclude-members: CoverageException
