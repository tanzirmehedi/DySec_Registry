from __future__ import absolute_import
from .main import main

__all__ = ["main"]
__version__ = '0.0.2'
