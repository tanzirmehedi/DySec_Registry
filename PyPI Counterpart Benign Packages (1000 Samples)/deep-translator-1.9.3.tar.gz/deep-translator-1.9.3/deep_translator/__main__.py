
__copyright__ = "Copyright (C) 2020 Nidhal Baccouri"


from deep_translator.cli import CLI


def main():
    CLI().run()


if __name__ == "__main__":
    main()
