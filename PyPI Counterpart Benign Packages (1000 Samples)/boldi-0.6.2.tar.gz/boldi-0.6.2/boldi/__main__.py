import boldi.cli

if __name__ == "__main__":
    boldi.cli.main()
