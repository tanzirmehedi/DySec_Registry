**********************************
coverage-python-version Change Log
**********************************

.. contents:: Releases


0.2.0 (2019-12-23)
==================

* Added support for coverage v5.


0.1.0 (2018-02-11)
==================

* Initial public release.

