# authlib-httpx
Temporary location of full httpx support until authlib merges this upstream
