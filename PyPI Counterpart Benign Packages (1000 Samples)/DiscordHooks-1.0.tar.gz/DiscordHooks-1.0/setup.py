from setuptools import setup

setup(
    name='DiscordHooks',
    version='1.0',
    packages=['DiscordHooks'],
    url='https://github.com/MeitarR/DiscordHooks',
    license='',
    author='MeitarR',
    author_email='meitarr013@gmail.com',
    description='A python module for easily execute discord webhooks with embeds and more.'
)
