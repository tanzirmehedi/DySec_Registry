from setuptools import setup


setup(
    name="colormod",
    version="1.0.1",
    author="LiquidDevect",
    license="Do whatever you want",
    description="Makes the use of ANSI colors much easier. Its just a simplified version of colorama.Fore",
    keywords="colors",
    requires=["colorama"],
    packages=["colormod"]
)