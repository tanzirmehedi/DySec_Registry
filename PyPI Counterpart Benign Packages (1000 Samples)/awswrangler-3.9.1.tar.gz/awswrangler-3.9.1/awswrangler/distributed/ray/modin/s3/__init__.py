"""Ray Modin S3 Module."""
