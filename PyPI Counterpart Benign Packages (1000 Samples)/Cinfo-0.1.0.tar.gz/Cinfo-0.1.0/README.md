# cinfo
a CLI program to know about your written code for Unix ( linux / macOS ).

# Supported Languages
This program support these languages: Python, C++, JavaScript, HTML, CSS, TypeScript, React, C#, Assemblys, SQLs.