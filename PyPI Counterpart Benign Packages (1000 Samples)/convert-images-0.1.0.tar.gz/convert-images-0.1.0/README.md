# Convert-images

🚀 Simple CLI to convert images to JPEG and PNG format.

[![Supported Python versions](https://img.shields.io/badge/Python-%3E=3.6-blue.svg)](https://www.python.org/downloads/) [![PEP8](https://img.shields.io/badge/Code%20style-PEP%208-orange.svg)](https://www.python.org/dev/peps/pep-0008/) 


## Requirements
- 🐍 [python>=3.6](https://www.python.org/downloads/)


## ⬇️ Installation

```sh
pip install convert-images
```


## ⌨️ Usage

```
➜ convert-images --help


```


## 📕 Examples
