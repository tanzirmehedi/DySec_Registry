from setuptools_scm import get_version


def test_version():
    assert get_version()
