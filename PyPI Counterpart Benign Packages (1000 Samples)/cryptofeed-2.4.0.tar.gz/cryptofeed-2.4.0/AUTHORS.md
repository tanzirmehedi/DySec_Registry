Cryptofeed was originally created by Bryant Moscon, but many others have contributed greatly to its functionality, performance and stability. A list of those who have contributed follows (in no order). If you find your name omitted, or wish it removed, please contact the owner or open a PR.


* [Archie Norman](https://github.com/archienorman11) - <archie@mercuryassets.io>
* [Quantfiction](https://github.com/quantfiction)
* [Cody Jacques](https://github.com/PandaXcentric) - <jacques.co@northeastern.edu>
* [O. Libre](https://github.com/olibre) - <olibre@Lmap.org>
* [Ryan Tam](https://github.com/ryantam626) - <ryantam626@gmail.com>
* [Yoh Plala](https://github.com/yohplala) - <yoh.plala@gmail.com>
* [Alex](https://github.com/globophobe)
* [Michael Zhao](https://github.com/dynamikey) - <mr_michaelzhao@hotmail.com>
* [Tim Meggs](https://github.com/twmeggs) - <twmeggs@gmail.com>
* [James Lee](https://github.com/jinusean) - <atjameslee@gmail.com>
* [O. Janche](https://github.com/toyan) - <toyan@yandex.ru>
* [Bastien Enjalbert](https://github.com/bastienjalbert) - <bastienjalbert@gmail.com>
* [Jonggyun Kim](https://github.com/gyunt) - <truth0233@gmail.com>
