Changelog
=========

1.0.9 (2020-09-17)
------------------
- Setup general update and cleanup.

1.0.8 (2019-05-21)
------------------
- Update required setuptools version.
- Setup update and improvements.

1.0.7 (2018-11-08)
------------------
- Drop support for Python 2.6 and 3.0-3.3
- Update required setuptools version.

1.0.6 (2018-05-08)
------------------
- Update required setuptools version.
- Improve and simplify setup and packaging.

1.0.5 (2018-02-26)
------------------
- Improve and simplify setup and packaging.

1.0.4 (2018-01-28)
------------------
- Fix a bug and inconsistencies in tox.ini
- Update of README.rst.

1.0.1 (2018-01-24)
------------------
- Update required Sphinx version.
- Update doc Sphinx configuration files.

1.0.0 (2017-11-18)
------------------
- Setup improvements.
- Other minor improvements.

0.7.4 (2017-01-05)
------------------
- Minor setup improvements.

0.7.3 (2016-09-25)
------------------
- Fix bug in setup.py

0.7.1 (2016-09-25)
------------------
- More PEP8 compliant

0.6.7 (2016-09-24)
------------------
- Minor description suplement

0.6.4 (2016-09-23)
------------------
- Simplify package structure.

0.6.3 (2016-06-19)
------------------
- | Fix incompatibility for older versions of setuptools.
  | Add example.

0.6.0 (2015-08-17)
------------------
- Python3 support.

0.5.1 (2015-02-27)
------------------
- | Remove 'returns' as keyword argument for declare return type.
  | For now, the type of returned value should be declared by the
  | first positional argument.

0.3.3 (2014-09-15)
------------------
- Add wheels.

0.3.2 (2014-09-13)
------------------
- Standarize package.

0.3.0 (2014-09-06)
------------------
- Standarize package.
- Cosmetic changes.

0.2.6 (2014-06-10)
------------------
- Portable setup.py.

0.2.5 (2014-06-10)
------------------
- Cosmetic changes.

0.2.3 (2012-10-13)
------------------
- Initial release.
