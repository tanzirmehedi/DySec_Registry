annotate documentation
======================

.. include:: ../README.rst
.. include:: ../CHANGES.rst
