from distutils.core import setup

setup(
	name = 'cripto',
	version		= 	'1.0a',
	py_modules 	=	['cripto'],
	#author          =	'xXEdurjXx'
	#author_email    =	'lesxavier@outlook.com',
	#url             =	'',
	description     =	'Ferramentas para utilização em criptografia KRSA',
	)
