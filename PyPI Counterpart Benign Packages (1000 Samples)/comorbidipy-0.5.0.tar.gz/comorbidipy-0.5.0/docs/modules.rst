Modules
=======

.. automodule:: comorbidipy.calculator
   :members:
