__title__ = 'Django Om'
__version__ = '0.1.0-alpha9'

VERSION = __version__
