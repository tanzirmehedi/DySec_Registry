"""Unit test package for discord_advdb."""
