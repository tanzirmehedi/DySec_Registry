=======
History
=======

0.1.0 (2021-08-30)
------------------

* First release on PyPI.
