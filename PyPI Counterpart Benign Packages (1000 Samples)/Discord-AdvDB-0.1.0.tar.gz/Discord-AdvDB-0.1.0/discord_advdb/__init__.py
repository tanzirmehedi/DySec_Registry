"""Top-level package for Discord-AdvDB."""
from discord_advdb import discord_advdb

__all__ = [
    "discord_advdb",
]

__author__ = """Amit Yanay"""
__email__ = 'amityanay5@gmail.com'
__version__ = '0.1.0'
