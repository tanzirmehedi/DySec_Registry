=====
Usage
=====

To use Discord-AdvDB in a project::

    import discord_advdb
