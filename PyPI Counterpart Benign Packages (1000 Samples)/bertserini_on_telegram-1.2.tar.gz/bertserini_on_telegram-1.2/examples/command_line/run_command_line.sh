#!/bin/sh
python bert_command_line.py --config ./command_line_config.yaml
