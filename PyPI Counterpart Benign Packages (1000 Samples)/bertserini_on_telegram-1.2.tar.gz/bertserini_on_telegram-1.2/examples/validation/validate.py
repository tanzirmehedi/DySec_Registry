from bertserini_on_telegram.models import BERTModule
from bertserini_on_telegram.data import SQuADDataModule

from pytorch_lightning.utilities.cli import LightningCLI

if __name__ == "__main__":

    cli = LightningCLI()
