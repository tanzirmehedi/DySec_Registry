#!/bin/sh
python validate.py validate --config ./bert_validate.yaml