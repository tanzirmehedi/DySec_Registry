# Celery 工具包

## 说明
这是一个 Celery 工具包，主要用于快速开发 Celery 项目。

## 安装
```
pip install celery-tools
```
