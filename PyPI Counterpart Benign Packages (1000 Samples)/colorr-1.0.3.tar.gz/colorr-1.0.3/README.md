# Colorr Package

This is a package to do with colors like picking them or  
Storing colors you come across that you can then retreive later

---

You can email me here: [My email](mailto:spareafro@post.com)  
You can also check out my other package, Timerr: [timerr](https://github.com/ItzAfroBoy/timerr)

## Install

1. Install it by pip:

``` Plain Text
pip install colorr
```

Done!

## Change Log

``` Markdown
1.0.3
---
- Name Changes

1.0.2
---
- Actually wrote the python script
- Now it chooses colors
- Also can save them in a big list
- Can retreive the file

1.0.1  
---
- Uploaded the module  
```
