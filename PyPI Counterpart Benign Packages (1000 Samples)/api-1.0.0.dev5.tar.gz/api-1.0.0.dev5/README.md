# api

`Api lib for simple life.`
`让生活更简单`

[![Documentation Status](https://readthedocs.org/projects/api-cn/badge/?version=latest)](http://api-cn.readthedocs.io/zh_CN/latest/?badge=latest)

`Copyright © 2017 Rain. All Rights Reserved. `

[樱落清璃-Decalogue的CSDN博客](https://www.decalogue.cn)

