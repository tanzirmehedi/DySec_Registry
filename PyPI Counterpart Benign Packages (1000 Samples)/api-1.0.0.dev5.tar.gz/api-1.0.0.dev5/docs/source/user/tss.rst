.. _tss:

=====================
技术支持
=====================

Github
=====================

你可以在下列网址提问或加入Chat开发讨论:

Chat Google group
Chat Slack channel, 点击这里获得邀请.
你也可以在Github issues里提问或请求新特性。在提问之前请确保你阅读过我们的指导

FAQ
=====================

`英文版本 <http://api-cn.readthedocs.io/zh_CN/latest/user/tss.html>`_ .

你的贡献
=====================

贡献方式有很多种，比如提供应用、实现新的Api模块、回答 `GitHub`_ Issues 以及帮助完善文档等等。
每一点贡献都会署名，欢迎在 `GitHub`_ 上push。

