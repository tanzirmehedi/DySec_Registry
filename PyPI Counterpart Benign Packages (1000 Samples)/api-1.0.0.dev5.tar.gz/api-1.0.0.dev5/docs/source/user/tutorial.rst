.. _tutorial:

======================
快速开始
======================

对话
======================

.. code-block:: python

  from api import nlu_tuling
  
  answer = nlu_tuling(question="今天天气", loc="上海市")
  print(answer)
