.. _installation:

======================
安装 Installation
======================

.. code-block:: bash

    pip install api

Python3
======================

推荐Anaconda

Python依赖包
-------------------

* requests
