#!/usr/bin/env python
# -*- coding: utf-8 -*-

import setuptools

setuptools.setup(setup_requires=['pbr'], pbr=True)
