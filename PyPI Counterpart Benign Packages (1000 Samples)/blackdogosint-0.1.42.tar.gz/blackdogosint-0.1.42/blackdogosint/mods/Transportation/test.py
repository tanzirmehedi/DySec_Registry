# -*- coding: utf-8 -*-
class darkcode:
    pass

    def darkcode(self):
        pass
