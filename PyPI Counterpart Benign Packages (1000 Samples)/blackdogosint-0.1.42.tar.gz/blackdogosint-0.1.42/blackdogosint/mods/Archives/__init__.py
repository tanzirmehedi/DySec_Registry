# -*- coding: utf-8 -*-
class A:
    pass
