from blackdogosint.mods.IP_Address import HostPortDiscovery
from blackdogosint.mods.IP_Address import Geolocation
