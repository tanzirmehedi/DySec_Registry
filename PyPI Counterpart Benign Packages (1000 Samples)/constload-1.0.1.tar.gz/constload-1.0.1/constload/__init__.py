from .constant_loader import ConstantLoader

version = "1.0.1"