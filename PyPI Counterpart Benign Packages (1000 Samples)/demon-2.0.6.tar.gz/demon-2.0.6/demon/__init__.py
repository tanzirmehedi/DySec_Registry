from demon.alg.Demon import Demon
