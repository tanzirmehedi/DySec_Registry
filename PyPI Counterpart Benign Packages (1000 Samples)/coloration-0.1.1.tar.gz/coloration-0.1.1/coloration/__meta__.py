# Copyright (c) Jean-Charles Lefebvre
# SPDX-License-Identifier: MIT

__version__ = "0.1.1"
version_info = tuple(map(int, __version__.split(".")))
