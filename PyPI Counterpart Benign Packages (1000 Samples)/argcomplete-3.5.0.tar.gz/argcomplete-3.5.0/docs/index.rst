.. include:: ../README.rst

API documentation
=================

.. autofunction:: argcomplete.autocomplete

.. automodule:: argcomplete
   :members:
   :imported-members:
   :special-members:
   :exclude-members: __weakref__

Change log
==========

.. toctree::
   :maxdepth: 5

   changelog
