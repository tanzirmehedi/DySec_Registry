# Convertify by Ulises Himely

## A simple unit conversion CLI tool written in Python

```console
$ pip install convertify-py
$ convertify-py length --from in --to ft 24
24.0 in = 2.0 ft.
```
