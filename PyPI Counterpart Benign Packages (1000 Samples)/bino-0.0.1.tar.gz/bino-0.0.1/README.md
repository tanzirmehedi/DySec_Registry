A small package to convert decimal to binary.
## How to install

```
pip install bino
```

## How to use

Below example will help you

```
from bino import bino
x=2
print(bino.bino(x))	# returns the binary value


```
