#!/usr/bin/env python


class WorldDimension(object):
    NETHER = -1
    OVERWORLD = 0
    END = 1
