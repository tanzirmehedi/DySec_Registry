#!/usr/bin/env python


class WorldType(object):
    DEFAULT = u"default"
    FLAT = u"flat"
    LARGE_BIOMES = u"largeBiomes"
    AMPLIFIED = u"amplified"
    DEFAULT_1_1 = u"default_1_1"
