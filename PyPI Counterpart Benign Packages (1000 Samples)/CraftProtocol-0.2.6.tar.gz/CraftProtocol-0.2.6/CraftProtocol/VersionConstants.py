#!/usr/bin/env python


class VersionConstants(object):
    VERSION = "0.2.6"
