#!/usr/bin/env python


class Hand(object):
    LEFT = 0
    RIGHT = 1
