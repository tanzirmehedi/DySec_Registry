#!/usr/bin/env python


class HandType(object):
    MAIN = 0
    OFF = 1
