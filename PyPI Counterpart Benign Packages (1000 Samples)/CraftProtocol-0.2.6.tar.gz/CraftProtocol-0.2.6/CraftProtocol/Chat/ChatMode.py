#!/usr/bin/env python


class ChatMode(object):
    ENABLED = 0
    COMMANDS = 1
    HIDDEN = 2
