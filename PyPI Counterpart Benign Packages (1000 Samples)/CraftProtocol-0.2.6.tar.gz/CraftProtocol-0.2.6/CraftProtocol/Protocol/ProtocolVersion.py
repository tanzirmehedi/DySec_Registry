#!/usr/bin/env python


class ProtocolVersion(object):
    MC_1_8 = 47
    MC_1_10 = 210
    MC_1_12_2 = 340
