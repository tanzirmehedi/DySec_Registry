#!/usr/bin/env python


class PacketDirection(object):
    CLIENTBOUND = 0
    SERVERBOUND = 1
