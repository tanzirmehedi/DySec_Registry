#!/usr/bin/env python

__all__ = [
    "Packet"
]

import CraftProtocol.Protocol.v1_10.Packet
