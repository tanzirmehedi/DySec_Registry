from .css_3 import CSS_3

CSS_4 = dict(CSS_3, rebeccapurple='#663399')
