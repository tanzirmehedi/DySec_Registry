from .css_2 import CSS_2

CSS_2_1 = dict(CSS_2, orange='#ffa500')
