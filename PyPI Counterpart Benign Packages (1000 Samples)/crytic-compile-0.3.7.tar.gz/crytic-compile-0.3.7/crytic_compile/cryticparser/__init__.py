"""
Init module
"""
from .defaults import DEFAULTS_FLAG_IN_CONFIG
