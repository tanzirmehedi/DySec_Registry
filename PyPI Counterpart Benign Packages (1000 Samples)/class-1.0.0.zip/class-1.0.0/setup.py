from distutils.core import setup
setup(
		name = 'class',
		version = '1.0.0',
		py_modules = ['classPrac'],
		author = 'Wjq_python',
		author_email = '614754894@qq.com',
		url =   'http://user.qzone.qq.com/614754894/main',
		description =  'A simple class!'
	 )
