from dgaintel.predict import get_prob, get_prediction
from dgaintel.intel import Intel

__version__ = '2.3'
