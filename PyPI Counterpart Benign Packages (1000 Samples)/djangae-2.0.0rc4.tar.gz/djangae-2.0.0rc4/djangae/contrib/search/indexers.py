

def stemming(word, min_index_length, **options):
    raise NotImplementedError()
