from distutils.core import setup
setup(
        name = 'Calculator',
        version = '1.1.0',
        py_modules = ['Calculator'],
        author = 'Gopikrishna S',
        author_email = 'sandalblack19@gmail.com',
        url = 'http://gopikrishna.net78.net',
        description = 'Performs basic calculation operations',
        )
