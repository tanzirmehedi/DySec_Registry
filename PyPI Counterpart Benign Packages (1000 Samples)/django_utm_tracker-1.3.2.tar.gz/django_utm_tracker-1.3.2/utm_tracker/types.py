from typing import Dict

UtmParamsDict = Dict[str, str]
