from cvc import convert

if __name__ == '__main__':
    convert()
