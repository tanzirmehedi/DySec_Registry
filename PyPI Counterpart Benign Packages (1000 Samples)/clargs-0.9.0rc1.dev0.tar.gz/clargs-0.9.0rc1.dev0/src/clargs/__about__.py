# SPDX-FileCopyrightText: 2024-present Claude <github@claude.nl>
#
# SPDX-License-Identifier: MIT
__version__ = "0.9.0rc1.dev0"
