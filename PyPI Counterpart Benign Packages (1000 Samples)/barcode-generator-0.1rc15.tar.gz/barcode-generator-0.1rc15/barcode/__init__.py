import barcode.main

def execute_from_command_line(argv=None):
	main.run()
