# barcode
Simple lightweight python barcode EAN generator. Output format SVG and ASCII

Usage: 
python barcode.py
