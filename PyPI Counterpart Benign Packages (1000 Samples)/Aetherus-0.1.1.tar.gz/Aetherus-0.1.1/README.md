# Aetherus
A Monte Carlo radiative transport code, supporting complex geometry - written in Rust
