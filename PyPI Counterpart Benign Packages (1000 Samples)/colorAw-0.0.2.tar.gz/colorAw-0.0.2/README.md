
## colorAw

> colorAw


**Example:**
```python
from colorAw import Color


print(Color.red+"Test Red Text ")
```



### Installing

``` bash
pip3 install -U colorAw
```
