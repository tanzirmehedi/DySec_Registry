#!/usr/bin/env python
from bots import plugoutindex

if __name__ == '__main__':
    plugoutindex.start()
