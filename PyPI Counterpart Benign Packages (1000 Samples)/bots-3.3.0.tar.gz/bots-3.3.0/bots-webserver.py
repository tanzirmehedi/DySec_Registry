#!/usr/bin/env python
from bots import webserver

if __name__ == '__main__':
    webserver.start()
