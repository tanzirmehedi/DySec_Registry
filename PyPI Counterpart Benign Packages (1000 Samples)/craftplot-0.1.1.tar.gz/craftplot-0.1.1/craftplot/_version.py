# -*- coding: utf-8 -*-
"""
_version.py
===========

Version info for ``craftplot`` package.
"""

__version__ = "0.1.1"
