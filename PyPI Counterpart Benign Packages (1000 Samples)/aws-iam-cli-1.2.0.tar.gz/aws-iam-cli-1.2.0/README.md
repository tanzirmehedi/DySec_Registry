# IAM Stack Generator CLI

[![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/rlawoals2590/aws-iam-cli/python-publish.yml)](https://github.com/rlawoals2590/aws-iam-cli/actions/workflows/python-publish.yml)
[![PyPI](https://img.shields.io/pypi/v/aws-iam-cli)](https://pypi.org/project/aws-iam-cli/)
[![License](https://img.shields.io/github/license/rlawoals2590/aws-iam-cli)](https://github.com/rlawoals2590/aws-iam-cli/blob/main/LICENSE)

## How to use

``` shell
pip install aws-iam-cli

iam-cli --version

iam-cli student.csv & teacher.csv
```
