EXCHANGE_SESSION = ['0900', '1130', '1200', '1700']
BASE_CURRENCY = ['rm', 'fx']
PRODUCTS = ['money_market_operations', 'interbank', 'overall']
URL = 'https://api.bnm.gov.my/public'
