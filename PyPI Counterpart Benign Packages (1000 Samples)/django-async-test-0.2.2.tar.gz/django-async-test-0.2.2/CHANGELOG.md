# Release 0.2.2 - Tuesday 10 May  07:08:57 AEST 2016

- Updated asynctest to 0.7.1
- Removed requirements readme, not relevant.
- Added detox
- Ignoring direnv

# Release 0.2.1 - Thu Dec 17 08:15:44 AEDT 2015

- Fixed issue with setup.py entry points.

# Release 0.2.0 - Thu Dec 17 08:07:10 AEDT 2015

- Renamed DjangoAsyncTestCase to TestCase

# Release 0.1.7 - Wed Dec 16 22:48:33 AEDT 2015

- Changes to docs.

# Release 0.1.6 - Wed Dec 16 22:26:49 AEDT 2015

- Initial release

