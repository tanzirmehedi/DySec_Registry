from unittest import TestCase


class TestPackageOptionsParser(TestCase):
    pass
