from unittest import TestCase


class TestPublishOptionsParser(TestCase):
    pass
