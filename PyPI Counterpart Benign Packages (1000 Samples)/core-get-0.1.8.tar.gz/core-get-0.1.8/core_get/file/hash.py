import hashlib


Hash = hashlib.sha3_256
HashDigest = bytes
