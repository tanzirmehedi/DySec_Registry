# -*- coding: utf-8 -*-

from faq.urls.normal import *
# This serves as both backwords-compatability and a shortcut to the default.
