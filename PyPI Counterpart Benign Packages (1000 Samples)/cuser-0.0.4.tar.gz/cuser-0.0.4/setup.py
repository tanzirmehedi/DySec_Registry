# coding: utf-8

from setuptools import setup

setup(
    name='cuser',
    version='0.0.4',
    author='fyy',
    author_email='fengyangyang@hnu.edu.cn',
    packages=['cuser'],
    install_requires=['pyserial']
)