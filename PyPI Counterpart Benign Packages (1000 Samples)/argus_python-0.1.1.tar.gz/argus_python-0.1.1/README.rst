============
Argus-Python
============


.. .. image:: https://img.shields.io/pypi/v/argus_python.svg
..         :target: https://pypi.python.org/pypi/argus_python

.. .. image:: https://img.shields.io/travis/jayjaychukwu/argus_python.svg
..         :target: https://travis-ci.com/jayjaychukwu/argus_python

.. .. image:: https://readthedocs.org/projects/argus-python/badge/?version=latest
..         :target: https://argus-python.readthedocs.io/en/latest/?version=latest
..         :alt: Documentation Status




A Python Client for the Argus Engine


* Free software: BSD license
* Documentation: https://github.com/jayjaychukwu/argus-python/blob/main/README.md
