=====
Usage
=====

To use Argus-Python in a project::

    import argus_python
