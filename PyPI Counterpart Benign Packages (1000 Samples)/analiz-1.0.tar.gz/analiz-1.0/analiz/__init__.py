import pandas
from multiprocessing import Process

__doc__ = """ Bu kütüphane örnek bir yapıdır. """
