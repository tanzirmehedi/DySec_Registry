# `3`

`.gitignore`-aware tree tool written in Python.

Example:

```
3
```

Output:

![](examples/3.png)

## Install

```
pip3 install 3-py
```

### Compatibility

If you are on Windows, install `colorama` in order to watch some colors.
