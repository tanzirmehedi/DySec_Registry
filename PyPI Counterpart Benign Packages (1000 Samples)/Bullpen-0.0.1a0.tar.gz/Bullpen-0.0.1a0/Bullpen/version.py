#!/usr/bin/env python

# package version
__version__ = "0.0.1-alpha"
"""Installed version of Bullpen."""
