class Action:
    def on_perform(self):
        raise NotImplementedError
