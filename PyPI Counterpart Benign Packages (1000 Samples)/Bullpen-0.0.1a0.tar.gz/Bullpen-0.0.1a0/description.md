# `Bullpen`

`Bullpen` is a Python package for managing workflows and is designed to be as lightweight as possible.

## Installation

`Bullpen` is in the [Python Package Index (PyPI)](http://pypi.python.org/pypi/Bullpen/).
Installing with ``pip`` is recommended for all systems.

```sh
pip install Bullpen
```

## Contact

Tyler Porter

tyler.b.porter@gmail.com