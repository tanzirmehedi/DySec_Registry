import logging


__all__ = ['logger']


logger = logging.getLogger('aiolo')
