
__title__ = 'aiolo'
__version__ = '4.1.1'
__description__ = 'asyncio-friendly Python bindings for liblo'
__url__ = 'https://github.com/elijahr/aiolo'
__author__ = 'Elijah Shaw-Rutschman'
__author_email__ = 'elijahr+aiolo@gmail.com'
