"""A tool to analyze requirements with Libraries.io API"""
from importlib.metadata import version


__pkgname__ = "dependency-comb"
__version__ = version(__pkgname__)
