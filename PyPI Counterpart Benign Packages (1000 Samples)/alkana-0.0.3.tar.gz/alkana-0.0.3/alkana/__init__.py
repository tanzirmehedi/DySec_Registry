# coding: utf-8
#
# Licence GPLv2
# (c) 2019 cod


from .main import get_kana
from .external_data import add_external_data
