==========================
Oscar SagePay Integration
==========================

This package provides integration between django-oscar and the payment gateway SagePay UK


This project is a work in progress and still in development. It is intended for use with Django Oscar 0.6 or above.

Documentation
--------------

* Documentation_ - Read the Documentation

.. _Documentation: http://sagepay-payment-gateway-package-for-django-oscar.readthedocs.org