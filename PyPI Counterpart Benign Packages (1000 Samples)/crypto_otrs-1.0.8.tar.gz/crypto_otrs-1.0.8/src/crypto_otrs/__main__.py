# __main__.py
from ring import *

def main():
    # do nothing :)
    pass


if __name__ == "__main__":

    main()