from android_prober.utils.common import platform, Platform
