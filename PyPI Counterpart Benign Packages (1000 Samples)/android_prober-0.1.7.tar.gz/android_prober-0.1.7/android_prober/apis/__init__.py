from .bluetooth import Bluetooth

def register_all():
    return bluetooth.register_all()
