class Notification:    
    
    def notify(self, notification_info:dict) -> dict:
        pass