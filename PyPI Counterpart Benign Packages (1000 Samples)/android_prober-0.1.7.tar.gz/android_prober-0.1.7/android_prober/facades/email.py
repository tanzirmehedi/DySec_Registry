class Email:

    def send_mail(self) -> dict:
        pass