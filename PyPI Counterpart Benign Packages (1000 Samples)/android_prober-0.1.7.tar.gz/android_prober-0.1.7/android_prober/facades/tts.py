class TTS:

    def say(self, message: str):
        pass
