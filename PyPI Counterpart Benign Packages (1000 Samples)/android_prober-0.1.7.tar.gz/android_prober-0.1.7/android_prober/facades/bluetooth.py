class Bluetooth:

    def connect(self):
        pass

    def disconnect(self):
        pass

    def pair(self):
        pass

    def unpair(self):
        pass

    def enable(self)-> dict:
        pass

    def disable(self) -> dict:
        pass

    def status(self):
        pass