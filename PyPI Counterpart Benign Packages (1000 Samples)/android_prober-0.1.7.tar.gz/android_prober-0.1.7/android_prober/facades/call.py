class Call:
    
    def make_call(self, phone_number: int):
        pass

    def dial_call(self)-> bool:
        pass
