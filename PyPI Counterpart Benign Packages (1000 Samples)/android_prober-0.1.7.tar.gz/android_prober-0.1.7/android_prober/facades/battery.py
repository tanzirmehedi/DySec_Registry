class Battery:

    def status(self)->dict:
        pass
    
