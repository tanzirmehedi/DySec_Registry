from inspect import getmembers, ismethod
from typing import Any

class Flash:
    
    def flash_on(self)->dict:
        pass
    
    def flash_off(self) -> dict:
        pass

