class Service:
    """
    Background Service
    """
    def start_service(self)-> dict:
        pass
    
    def stop_service(self) -> dict:
        pass