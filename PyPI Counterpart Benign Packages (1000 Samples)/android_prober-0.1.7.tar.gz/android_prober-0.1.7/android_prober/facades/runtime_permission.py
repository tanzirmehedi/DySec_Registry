class RuntimePermission:

    def location_permission(self):
        pass

    def bluetooth_permission(self):
        pass
    
    def telephony_permission(self):
        pass
    
  
    