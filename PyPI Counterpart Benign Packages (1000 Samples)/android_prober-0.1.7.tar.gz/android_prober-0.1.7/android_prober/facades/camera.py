class Camera:
    
    def take_picture(self, filepath:str)-> dict:
        pass
    
    def take_video(self, filepath:str)->dict:
        pass