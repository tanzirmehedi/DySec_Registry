class FileChooser:
    
    def open_file(self):
        pass

    def save_file(self):
        pass
    
    def choose_dir(self):
        pass
