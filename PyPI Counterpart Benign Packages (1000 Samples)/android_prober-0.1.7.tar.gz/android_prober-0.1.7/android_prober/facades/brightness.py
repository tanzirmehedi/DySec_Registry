class Brightness:

    def brightness(self)->dict:
        raise NotImplementedError()

    def set_brightness(self)->dict:
        raise NotImplementedError()
