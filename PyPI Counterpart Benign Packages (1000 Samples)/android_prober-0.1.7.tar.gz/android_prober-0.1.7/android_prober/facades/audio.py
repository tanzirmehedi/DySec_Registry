class Audio:

    def stop_record(self) -> dict:
        pass

    def start_record(self) -> dict:
        pass

    def play_audio(self) -> dict:
        pass

    def record_state(self):
        pass