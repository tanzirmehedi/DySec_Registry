class GPS:

    def gps_stop(self) -> dict:
        pass
    
    def gps_start(self) -> dict:
        pass

    def location(self) -> dict:
        pass
    