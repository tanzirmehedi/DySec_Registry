PayPal Payments Standard
========================

.. toctree::
   :maxdepth: 2

   ipn
   pdt
   variables
   subscriptions
   encrypted_buttons
