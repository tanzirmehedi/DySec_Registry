Originally created by John Boxall <john@handimobility.ca>

For other contributors, see [https://github.com/spookylukey/django-paypal/graphs/contributors](https://github.com/spookylukey/django-paypal/graphs/contributors)
