from discorudo import hello

hello()
