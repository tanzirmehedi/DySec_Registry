__all__ = ("User", "Channel", "Mentionable")


class User:
    ...


class Channel:
    ...


class Mentionable:
    ...


# TODO: add functionality
