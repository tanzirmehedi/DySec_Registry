from setuptools import setup, find_packages


# Setting up
setup(
    version = "1.0.6",
    name="bloxflip_crash", 
    author="",
    author_email="",
    packages=find_packages(),
)