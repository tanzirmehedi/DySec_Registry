__version__ = '1.0.0'

from .amcheck import check_altermagnetism_orbit
from .amcheck import is_altermagnet
from .amcheck import label_matrix
from .amcheck import symmetrized_conductivity_tensor
