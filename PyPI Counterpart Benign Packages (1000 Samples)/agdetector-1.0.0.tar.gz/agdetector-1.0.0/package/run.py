from agricultural_field_detector import main

main()