import logging

bq_logger = logging.getLogger("bingqilin")
