# betterstar/__init__.py

from .betterstar import star
