# cct
SAXSCtrl revisited

## Introduction
cct stands for CREDO Control Tool: an instrument control, data acquisition and processing software for CREDO, a laboratory-based small-angle X-ray scattering instrument (http://credo.ttk.mta.hu).

## Derivative works
As this program is strongly tied to the instrument, it is not practical to use without it on its own. However, forking this project and adapting to other instruments is highly encouraged. Until we have a decent documentation, please contact the author of the project (András Wacha) directly, if you need help.

