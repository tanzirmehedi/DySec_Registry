# Booster


## Tree (Draft)


```
.
├── app
│   ├── utils
│   │   └── preprocessing
│   ├── 000_foo.ipynb
│   └── 001_bar.ipynb
├── config
├── data
│   └── rawdata
├── log
├── model
└── tmp
```
