from setuptools import setup
from setuptools import find_packages

setup(
    name='booster',
    version='0.0.1',
    description='Boost your project',
    author='Yusuke Sugomori',
    author_email='me@yusugomori.com',
    url='',
    download_url='',
    install_requires=[],
    classifiers=[
        'Development Status :: 1 - Planning'
    ],
    keywords='',
    packages=find_packages()
)
