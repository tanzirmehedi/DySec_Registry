### Morse

- A library focused on encryption and decryption in various ways (like morse, cesar cipher, binary etc)