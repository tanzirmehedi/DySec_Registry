from direnumerate.version import __version__

def show_banner():
    return print("direnumerate " + "v" + __version__ + "\n")