[![](https://img.shields.io/pypi/v/curlreq.svg)](https://pypi.python.org/pypi/curlreq)
[![](https://img.shields.io/pypi/pyversions/curlreq.svg)](https://pypi.python.org/pypi/curlreq)
[![](https://github.com/skiloop/curlreq/workflows/Pylint/badge.svg)](https://github.com/skiloop/curlreq/actions?query=workflow%3APylint)

CurlReq
========
a requests-like http client base on pycurl 



