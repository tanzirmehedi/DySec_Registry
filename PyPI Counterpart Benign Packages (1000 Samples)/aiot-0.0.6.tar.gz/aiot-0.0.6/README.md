## sdk python for mobifone aiot platform

this is an example project demonstrating how to publish a python module to PyPI.

## Installation

Run the followin gto install

```python
pip install aiot
```

## Developing aiot

To install Helloworld, along with the tools you need to develop and run tests, run the following in yout virtualenv:

```bash
$ pip install -e .[dev]
```
