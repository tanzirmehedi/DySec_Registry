Discription

==============================

This module for encrypt and decrypt some text



cryptrand.encrypt(text, key) -> return encrypt text
cryptrand.decrypt(text, key) -> return decrypt text


keys must match for the expected result.

https://github.com/BUS410/cryptorand