set -e
rm -rf build/resmoke-bisect
rm -rf build/tmp
