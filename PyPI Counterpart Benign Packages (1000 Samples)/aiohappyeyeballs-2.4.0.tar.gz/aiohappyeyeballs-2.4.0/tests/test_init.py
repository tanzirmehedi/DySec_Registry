from aiohappyeyeballs import start_connection


def test_init():
    assert start_connection is not None
