"""A module to loop on iterables, with convolutional style."""

from .conv import convolved, convolved_1d, convolved_2d
