"""Common library."""
