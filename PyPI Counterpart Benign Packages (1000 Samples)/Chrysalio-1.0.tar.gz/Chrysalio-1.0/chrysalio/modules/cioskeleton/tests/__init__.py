"""Unit, integration, and functional testing for Skeleton module."""

from os.path import join, dirname


ATTACHMENTS_DIR = join(dirname(__file__), 'Attachments')
