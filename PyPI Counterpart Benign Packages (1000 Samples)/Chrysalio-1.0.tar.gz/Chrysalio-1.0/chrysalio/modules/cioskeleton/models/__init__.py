"""WBSkeleton models."""
