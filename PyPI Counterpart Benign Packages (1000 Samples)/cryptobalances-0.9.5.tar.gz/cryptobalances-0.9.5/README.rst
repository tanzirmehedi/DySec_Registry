Description
===========
A module for getting the balance of wallet for various crypto currency.