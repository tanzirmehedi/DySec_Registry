Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:

.. toctree::
   :maxdepth: 1

   history

See the `workalendar docs <https://workalendar.github.io/workalendar>`_
for more details.

.. automodule:: calendra
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

