import logging
from decimal import Decimal

NUMBER_TYPES = (int, float, Decimal)

__version__ = "0.1.12"
__name__ = "calculation_test-mapilio"
__major__ = False
__minor__ = False
__patch__ = True


logger = logging.getLogger('calculation_test')

