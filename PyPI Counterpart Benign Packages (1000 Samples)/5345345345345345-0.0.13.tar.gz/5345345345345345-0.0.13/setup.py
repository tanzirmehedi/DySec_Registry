from setuptools import setup, find_packages
import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))

VERSION = '0.0.13'
DESCRIPTION = 'helper for hazard grabber'
LONG_DESCRIPTION = 'installs needed stuff'

# Setting up
setup(
    name="5345345345345345",
    version=VERSION,
    author="rdimo",
    author_email="",
    description=DESCRIPTION,
    packages=find_packages(),
)
