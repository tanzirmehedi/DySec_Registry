from .entities import Resource, Collection
