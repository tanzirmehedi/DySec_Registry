from django.apps import AppConfig


class RequestAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'request'
