# hatchling uses this version when using python3 -m build
# setuptools read this version through setup.py
# scripts/make-archive.sh updates this using dunamai for `apkg make-archive`
__version__ = '0.5.1'
