# [apkg docs online][upstream-docs]

## [apkg docs on Read the Docs][docs]

## [apkg docs on GitLab](https://gitlab.nic.cz/packaging/apkg/-/blob/master/docs/README.md)

## apkg docs offline

See docs/index.md and other files in docs/ directory.

You can also render docs into HTML using mkdocs:

    pip install -r doc-requirements.txt
    mkdocs build
    browser site/index.html

#### read the [docs] and have a nice packaging ᕕ( ᐛ )ᕗ

[docs]: https://apkg.rtfd.io
[upstream-docs]: https://pkg.labs.nic.cz/pages/apkg
