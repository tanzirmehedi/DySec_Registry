# coopmovers
 Library of tools for creating and controlling "entities that move"
