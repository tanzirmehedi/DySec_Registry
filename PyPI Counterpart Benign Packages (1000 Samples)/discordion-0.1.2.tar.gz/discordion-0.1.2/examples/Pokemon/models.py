from discordion.db.crud import Model


class Pokemon(Model):
    pass
