# Changelog

## [0.3] - 2019-03-29

### Changed

- Add another function that doesn't convert labels to EXIOBASE nomenclature

## [0.2] - 2019-03-29

### Changed

- Fixed a nasty bug where dict values were not unique

## [0.1.1] - 2019-03-29

### Changed

- Fixed some exiobase mappings which were incorrect

## [0.1.0] - 2019-03-29

Initial checkin
