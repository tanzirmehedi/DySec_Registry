# -*- coding: utf8 -*-

class Vendor:
	def __init__(self):
		pass