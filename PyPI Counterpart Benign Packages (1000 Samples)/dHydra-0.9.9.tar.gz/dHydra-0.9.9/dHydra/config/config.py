# -*- coding: utf8 -*-
"""
Config系统设置
Created on 02/22/2016
@description:	用于配置路径，数据库，帐号等参数
@author: 		Wen Gu
@contact: 		emptyset110@gmail.com
"""
