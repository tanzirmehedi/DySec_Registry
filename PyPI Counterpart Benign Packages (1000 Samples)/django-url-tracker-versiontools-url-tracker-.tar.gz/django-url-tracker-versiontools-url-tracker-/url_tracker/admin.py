from django.contrib import admin

from url_tracker.models import URLChangeRecord

admin.site.register(URLChangeRecord)
