#!/usr/bin/env bash
# Build package. For upload use upload.sh
python3 setup.py bdist_wheel
