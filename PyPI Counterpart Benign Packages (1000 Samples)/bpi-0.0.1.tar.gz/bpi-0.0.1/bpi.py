"""bot-programming-interface"""

__version__ = '0.0.1'