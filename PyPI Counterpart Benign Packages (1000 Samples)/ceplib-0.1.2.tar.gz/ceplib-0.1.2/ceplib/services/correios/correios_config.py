config = {}
config['URL'] = 'https://apps.correios.com.br/SigepMasterJPA/AtendeClienteService/AtendeCliente'