from setuptools import setup

setup(name='distri_py',
      version='1',
      description='Gaussian and Binomial distributions',
      packages=['distri_py'],
      zip_safe=False)
