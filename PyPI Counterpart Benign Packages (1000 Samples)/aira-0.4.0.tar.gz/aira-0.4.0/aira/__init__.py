from .cli import main

__version__ = '0.4.0'

__all__ = ['aira', 'main', '__version__']
