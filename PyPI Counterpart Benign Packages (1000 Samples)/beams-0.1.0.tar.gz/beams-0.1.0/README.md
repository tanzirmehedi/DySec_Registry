[![PyPI version](https://badge.fury.io/py/beams.svg)](https://badge.fury.io/py/beams)

# beams

Simple beam calculator.

## Installation

`pip install beams`

