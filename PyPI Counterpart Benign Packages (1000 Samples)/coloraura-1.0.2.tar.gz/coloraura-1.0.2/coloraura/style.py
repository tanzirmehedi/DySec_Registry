from .styler import Styler

gradient = Styler()
