from .color import color
from .gradient import gradient
from .style import style
