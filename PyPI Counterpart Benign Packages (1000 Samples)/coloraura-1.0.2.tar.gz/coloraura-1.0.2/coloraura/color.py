from .styler import Styler

color = Styler()
