# -*- coding: utf-8 -*-

'''A tiny WSGI web framework'''

__version__ = '0.1.6'
__title__ = 'bustard'
__author__ = 'mozillazg'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2016 mozillazg'
