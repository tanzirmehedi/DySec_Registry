Asyncit
====

[![PypI](http://img.shields.io/pypi/v/asyncit.svg)](http://img.shields.io/pypi/v/asyncit.svg)

A simple wrapper to asyncio
