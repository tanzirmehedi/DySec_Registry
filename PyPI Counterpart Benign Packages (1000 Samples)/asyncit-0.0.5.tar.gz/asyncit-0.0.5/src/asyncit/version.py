import pkg_resources

__version__ = pkg_resources.require("asyncit")[0].version
