from discotool import discotool
discotool.main()
