from . import discotool
discotool.main()
