from setuptools import setup, find_packages
from sys import version_info

setup(
    name="clientliblib",
    version="0.0.0.0",
)
